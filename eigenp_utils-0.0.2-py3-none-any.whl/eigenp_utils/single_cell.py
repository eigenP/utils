from __future__ import annotations
from typing import Iterable, List, Optional, Sequence, Tuple, Dict, Literal, Any, Union
import contextlib
import importlib
import warnings
from collections import defaultdict
from uuid import uuid4

import numpy as np
import pandas as pd
from sklearn.neighbors import NearestNeighbors
import scipy.sparse as sp
from scipy.cluster import hierarchy
from scipy.linalg import svd
from scipy.stats import norm
import matplotlib.pyplot as plt
from sklearn.metrics import adjusted_rand_score
import matplotlib.colors as mcolors
import matplotlib.patheffects as m_fx
import re
from .plotting_utils import get_nice_number
from .stats import robust_standardize



class _LazyModule:
    """Import a module on first attribute access.

    scanpy (via numba) has no WebAssembly build, so importing it eagerly would
    make the whole module unusable in Pyodide / marimo WASM, even for helpers
    that only need numpy/scipy (e.g. ``smooth_expression_on_graph``). Type
    annotations are not evaluated (``from __future__ import annotations``).
    """

    def __init__(self, name: str):
        self._name = name
        self._module = None

    def __getattr__(self, attr):
        if self._module is None:
            try:
                self._module = importlib.import_module(self._name)
            except ImportError as e:
                raise ImportError(
                    f"This function needs '{self._name}' (`pip install eigenp-utils[single-cell]`). "
                    "scanpy cannot be installed in the browser (WASM); run such notebooks "
                    "locally or on molab instead."
                ) from e
        return getattr(self._module, attr)


sc = _LazyModule("scanpy")
anndata = _LazyModule("anndata")

# Try importing third-party libraries that might be installed via the inline dependencies
try:
    from libpysal.weights import WSP
    from esda.moran import Moran
except ImportError:
    pass  # Allow import to succeed even if dependencies aren't immediately available in dev env



def _import_triku():
    """Import triku lazily; its import calls ``warnings.filterwarnings('ignore')``
    process-wide, so the global warning filters are restored afterwards."""
    with warnings.catch_warnings():
        try:
            import triku
        except ImportError:
            return None
    return triku

try:
    from adjustText import adjust_text
except ImportError:
    adjust_text = None

# ------------------------- Constants -------------------------

CELL_CYCLE_GENES = [
    "MCM5",
    "PCNA",
    "TYMS",
    "FEN1",
    "MCM2",
    "MCM4",
    "RRM1",
    "UNG",
    "GINS2",
    "MCM6",
    "CDCA7",
    "DTL",
    "PRIM1",
    "UHRF1",
    "MLF1IP",
    "HELLS",
    "RFC2",
    "RPA2",
    "NASP",
    "RAD51AP1",
    "GMNN",
    "WDR76",
    "SLBP",
    "CCNE2",
    "UBR7",
    "POLD3",
    "MSH2",
    "ATAD2",
    "RAD51",
    "RRM2",
    "CDC45",
    "CDC6",
    "EXO1",
    "TIPIN",
    "DSCC1",
    "BLM",
    "CASP8AP2",
    "USP1",
    "CLSPN",
    "POLA1",
    "CHAF1B",
    "BRIP1",
    "E2F8",
    "HMGB2",
    "CDK1",
    "NUSAP1",
    "UBE2C",
    "BIRC5",
    "TPX2",
    "TOP2A",
    "NDC80",
    "CKS2",
    "NUF2",
    "CKS1B",
    "MKI67",
    "TMPO",
    "CENPF",
    "TACC3",
    "FAM64A",
    "SMC4",
    "CCNB2",
    "CKAP2L",
    "CKAP2",
    "AURKB",
    "BUB1",
    "KIF11",
    "ANP32E",
    "TUBB4B",
    "GTSE1",
    "KIF20B",
    "HJURP",
    "CDCA3",
    "HN1",
    "CDC20",
    "TTK",
    "CDC25C",
    "KIF2C",
    "RANGAP1",
    "NCAPD2",
    "DLGAP5",
    "CDCA2",
    "CDCA8",
    "ECT2",
    "KIF23",
    "HMMR",
    "AURKA",
    "PSRC1",
    "ANLN",
    "LBR",
    "CKAP5",
    "CENPE",
    "CTCF",
    "NEK2",
    "G2E3",
    "GAS2L3",
    "CBX5",
    "CENPA",
]

# ------------------------- Preprocessing Tools -------------------------


def carry_palette(src_adata, dst_adata, key: str, fallback_color: str = "#BBBBBB"):
    """
    Copy colors for `key` from src -> dst, matching by category names.
    Keeps identical colors for categories present in both; unseen ones get `fallback_color`.
    """
    if key not in src_adata.obs or key not in dst_adata.obs:
        raise KeyError(f"'{key}' must be in .obs of both src and dst")

    # Ensure categoricals & drop unused in the subset
    src_c = src_adata.obs[key].astype("category")
    dst_c = dst_adata.obs[key].astype("category").cat.remove_unused_categories()
    dst_adata.obs[key] = dst_c  # write back (important)

    # Grab source palette
    pal_key = f"{key}_colors"
    if pal_key not in src_adata.uns:
        raise KeyError(f"Source palette '{pal_key}' not found in src_adata.uns")

    src_cats = list(src_c.cat.categories)
    src_cols = list(src_adata.uns[pal_key])
    cmap = dict(zip(src_cats, src_cols))

    # Build destination palette in the (possibly new) category order
    dst_cats = list(dst_c.cat.categories)
    dst_cols = [cmap.get(cat, fallback_color) for cat in dst_cats]
    dst_adata.uns[pal_key] = dst_cols

    # Optional sanity check: warn if any cats were missing in source
    missing = [cat for cat in dst_cats if cat not in cmap]
    if missing:
        warnings.warn(
            f"[carry_palette] No color found in source for: {missing}. Used fallback_color={fallback_color}."
        )

    return dst_adata


def pacmap_heuristic_n_neighbors(n_samples: int) -> int:
    """
    Returns the PaCMAP heuristic for the number of neighbors based on sample size.
    https://github.com/YingfanWang/PaCMAP/blob/master/pacmap/pacmap.py#L427
    """
    if n_samples <= 10000:
        return 10
    else:
        return int(round(10 + 15 * (np.log10(n_samples) - 4)))


def _has_integer_like_counts(X, n_check=200000):
    if sp.issparse(X):
        data = X.data
    else:
        data = np.ravel(X)
    if data.size > n_check:
        rng = np.random.default_rng(0)
        data = rng.choice(data, size=n_check, replace=False)
    return np.allclose(data, np.round(data))


def _raw_counts_for_vars(A):
    """Return ``A.raw.X`` restricted and ordered to ``A.var_names``.

    ``A.raw`` usually keeps every gene while ``A`` has been gene-filtered, so
    ``A.raw.X`` cannot be stored as a layer of ``A`` without alignment.
    """
    missing = A.var_names.difference(A.raw.var_names)
    if len(missing) > 0:
        raise KeyError(
            f"{len(missing)} genes of A.var_names are not in A.raw.var_names "
            f"(e.g. {list(missing[:5])}); cannot take counts from A.raw."
        )
    return A.raw[:, A.var_names].X.copy()


def _ensure_log1p_layer(
    A,
    *,
    target_layer: str = "log1p",
    counts_layer: str = "counts",
    total_count: float = 1e4,
    force_build: bool = False,
):
    """
    Create A.layers[target_layer] from RAW COUNTS via normalize_total + log1p.
    Counts source priority (STRICT):
      1) A.layers[counts_layer]
      2) A.raw.X
    No fallback to A.X to avoid double-log issues.
    """
    if target_layer in A.layers:
        return

    # choose counts source
    if counts_layer in A.layers:
        C = A.layers[counts_layer]
        src_name = f"layers['{counts_layer}']"
    elif A.raw is not None:
        # cache an aligned copy for future calls
        A.layers[counts_layer] = _raw_counts_for_vars(A)
        C = A.layers[counts_layer]
        src_name = "raw.X"
    else:
        raise KeyError(
            f"Cannot build '{target_layer}': need raw counts in A.layers['{counts_layer}'] or A.raw.X."
        )

    # sanity check: counts must look integer-like
    if not force_build and not _has_integer_like_counts(C):
        raise ValueError(
            f"{src_name} does not look like raw integer counts. "
            f"Refusing to create '{target_layer}' to avoid double log-transform. "
            f"Provide true counts or pass force_build=True if you are certain."
        )

    # build log1p from counts WITHOUT touching A.X
    # Bolt optimization: avoid copying full adata structure (which may be large)
    # just to normalize a matrix. Use a minimal AnnData object instead.
    tmp = anndata.AnnData(X=C.copy())
    sc.pp.normalize_total(tmp, target_sum=total_count)
    sc.pp.log1p(tmp)
    A.layers[target_layer] = tmp.X
    del tmp
    warnings.warn(
        f"[ensure_log1p_layer] Created A.layers['{target_layer}'] from {src_name}."
    )


def pflogpf(
    adata: sc.AnnData,
    target: str = "auto",
    key_added: str = "pflogpf",
    copy: bool = False,
    **kwargs,
) -> Optional[sc.AnnData]:
    """
    Computes the PFlogPF (shifted-CLR) normalization on raw single-cell counts.

    Single-cell count normalization should stabilize technical variance, remove
    sequencing-depth effects, and preserve within-cell gene ranks. PFlog addresses
    these requirements by applying an Anscombe-calibrated shifted logarithm followed
    by within-cell CLR centering. Equivalently, it is a shifted centered log-ratio
    (CLR) transform. Across hundreds of datasets, and in an adapted analysis of the
    benchmarks of Ahlmann-Eltze & Huber (2023), PFlog removes residual depth structure
    while preserving rank information and stabilizing technical variance.

    The shift is set by the delta method. For a negative-binomial mean-variance
    model var = μ + α·μ², the Anscombe-derived count-scale pseudocount is y₀ = 1/(4α).
    In software notation, for cell c with depth s_c, this is equivalent to the
    cell-specific normalized shifted-log scale K_c = 4·α·s_c. At a representative
    depth s_*, the corresponding plotted scale is K_* = 4·α·s_*.

    Citations:
        - Theory & Benchmarks: https://github.com/pachterlab/BHGP_2022
        - Fast Rust implementation (scclr): https://github.com/cleartools/scclr

    Install (dev):
        uv venv
        uv pip install -e ".[test]" maturin
        uv run maturin develop --release

    Quickstart Example:
        import scclr
        # scverse in-place (AnnData / MuData), shaped like scanpy:
        scclr.pp.pflog(adata, target="auto")      # -> adata.layers["pflog"] + obs center
        scclr.tl.pca(adata, n_comps=50)             # -> adata.obsm["X_pca"], varm["PCs"], uns["pca"]

        # downstream sc.pp.neighbors(adata) / sc.tl.umap(adata) work unchanged
        # This swaps in for sc.pp.normalize_total + sc.pp.log1p + sc.tl.pca.

    Parameters
    ----------
    adata
        Annotated data matrix containing raw counts in `.X`.
    target
        Target depth (e.g. "auto").
    key_added
        Key in `adata.layers` to store the resulting PFlogPF matrix. Defaults to "pflogpf".
    copy
        If True, return a new AnnData object instead of modifying in-place.
    **kwargs
        Additional arguments passed to `scclr.pp.pflog`.

    Returns
    -------
    Optional[sc.AnnData]
        If `copy` is True, returns a new AnnData object with PFlogPF values in `.layers[key_added]`.
        Otherwise, modifies `adata` in-place and returns `None`.
    """
    if not _has_integer_like_counts(adata.X):
        raise ValueError(
            "adata.X does not look like raw integer counts. "
            "The PFlogPF transform expects raw counts. "
            "Please provide true counts."
        )

    try:
        import scclr
    except ImportError:
        print(pflogpf.__doc__)
        raise ImportError(
            "The 'scclr' package is required for this function. "
            "Please install it using the instructions in the docstring above."
        )

    # Work on a copy if requested
    A = adata.copy() if copy else adata

    # call scclr.pp.pflog
    scclr.pp.pflog(A, target=target, **kwargs)

    # scclr.pp.pflog normally stores to "pflog" layer.
    # If the user provided a different key_added, we should move it.
    if key_added != "pflog" and "pflog" in A.layers:
        A.layers[key_added] = A.layers.pop("pflog")

    if copy:
        return A
    return None


def preprocess_subset(
    adata,
    *,
    counts_layer: str = "counts",
    n_top_genes: int = 2500,
    hvg_flavor: str = "seurat_v3",  # or "triku"
    batch_key: Optional[str] = None,
    subset_to_hvgs: bool = True,
    X_layer_for_pca: str = "log1p",
    scale_max_value: float = 10.0,
    n_comps: int = 32,
    svd_solver: str = "arpack",
    n_neighbors: Optional[int] = None,
    n_pcs: int = 30,
    use_rep: Optional[str] = None,
    cluster_key: str = "leiden",
    resolution: float = 1.0,
    random_state: int = 0,
    copy: bool = False,
    scale_data: bool = True,
):
    A = adata.copy() if copy else adata
    sc.pp.filter_genes(A, min_cells=3)

    # ---- Make sure counts/log1p exist BEFORE any var subsetting ----
    # (prevents shape-mismatch if we need to look at A.raw)

    # 1. Check/Get Counts
    has_counts = False
    if counts_layer in A.layers:
        has_counts = True
    elif A.raw is not None:
        # Auto-populate if possible (aligned: filter_genes above may have dropped genes)
        A.layers[counts_layer] = _raw_counts_for_vars(A)
        has_counts = True

    if hvg_flavor == "seurat_v3":
        # seurat_v3 STRICTLY requires raw counts
        if not has_counts:
            raise ValueError(
                f"flavor='seurat_v3' requires raw counts in A.layers['{counts_layer}'] or A.raw"
            )
        if not _has_integer_like_counts(A.layers[counts_layer]):
            raise ValueError(
                f"A.layers['{counts_layer}'] does not look like raw integer counts."
            )
    else:
        # For other flavors, we tolerate missing counts but warn
        if not has_counts:
            warnings.warn(
                f"Counts layer '{counts_layer}' not found. Some functionality (e.g. log1p generation) may be skipped."
            )

    # 2. Ensure log1p (if needed)
    # If the user explicitly asks for 'log1p' as the PCA layer, we MUST build it (or fail if counts missing).
    # If they ask for something else (e.g. 'scvi'), we try to build 'log1p' for convenience but don't crash if missing.
    try:
        if X_layer_for_pca == "log1p" or has_counts:
            _ensure_log1p_layer(
                A,
                target_layer="log1p",
                counts_layer=counts_layer,
                total_count=1e4,
                force_build=False,
            )
    except Exception as e:
        if X_layer_for_pca == "log1p":
            raise e  # Critical failure
        else:
            warnings.warn(
                f"Could not build 'log1p' layer: {e}. Proceeding with '{X_layer_for_pca}'..."
            )

    # ---------- HVG selection ----------
    if hvg_flavor == "triku":
        # Run Triku on specified layer (recommended log1p or scvi), then rely on its 'highly_variable' output
        run_triku(A, layer=X_layer_for_pca, n_features=n_top_genes)
        # Ensure 'highly_variable' column exists for subsetting
        if "triku_highly_variable" in A.var:
            A.var["highly_variable"] = A.var["triku_highly_variable"]
    else:
        if batch_key is None and "batch" in A.obs:
            batch_key = "batch"
        hvg_kwargs = dict(
            n_top_genes=n_top_genes, flavor=hvg_flavor, batch_key=batch_key
        )

        if hvg_flavor == "seurat_v3":
            hvg_kwargs["layer"] = counts_layer
        elif X_layer_for_pca is not None and X_layer_for_pca in A.layers:
            # Use the target PCA layer for HVG selection (e.g. scvi_normalized)
            # Standard seurat flavor works on log-normalized data.
            hvg_kwargs["layer"] = X_layer_for_pca

        sc.pp.highly_variable_genes(A, **hvg_kwargs)

    # ---------- subset HVGs (optional but common) ----------
    if subset_to_hvgs:
        A._inplace_subset_var(A.var["highly_variable"].values)

    # ---------- set working matrix ----------
    if X_layer_for_pca is None:
        warnings.warn("X_layer_for_pca is None. Using existing .X for PCA/Neighbors.")
    else:
        if X_layer_for_pca not in A.layers:
            raise KeyError(
                f"Layer '{X_layer_for_pca}' missing even after construction."
            )
        warnings.warn(f"Overwriting .X with layer '{X_layer_for_pca}'.")
        A.X = A.layers[X_layer_for_pca].copy()

    # ---------- scale / PCA on HVGs ----------
    if scale_data:
        sc.pp.scale(A, max_value=scale_max_value)

    # arpack needs n_comps < min(n_obs, n_features used by the PCA)
    has_hvg = "highly_variable" in A.var
    n_features = int(A.var["highly_variable"].sum()) if has_hvg else A.n_vars
    sc.tl.pca(
        A,
        n_comps=min(n_comps, n_features - 1, A.n_obs - 1),
        mask_var="highly_variable" if has_hvg else None,
        svd_solver=svd_solver,
        random_state=random_state,
    )

    # ---------- neighbors ----------

    if n_neighbors is None:
        n_neighbors = pacmap_heuristic_n_neighbors(A.n_obs)
    n_neighbors = min(n_neighbors, A.n_obs - 1)
    if use_rep is not None:
        sc.pp.neighbors(A, n_neighbors=n_neighbors, use_rep=use_rep)
    else:
        sc.pp.neighbors(
            A, n_neighbors=n_neighbors, n_pcs=min(n_pcs, A.obsm["X_pca"].shape[1])
        )

    # ---------- clustering ----------
    if cluster_key == "leiden":
        sc.tl.leiden(
            A, resolution=resolution, key_added="leiden", random_state=random_state, flavor='igraph', n_iterations=2, directed=False
        )
    else:
        if cluster_key not in A.obs:
            raise KeyError(f"cluster_key '{cluster_key}' not found in .obs.")

    return A


# ------------------------- General Utilities -------------------------


def find_cluster_keys(adata, pattern=r"leiden_[\d\.]+"):
    """
    Helper helper to find clustering columns in adata.obs that match a regex pattern.
    It automatically sorts them numerically by resolution if numbers are present.

    Args:
        adata: AnnData object
        pattern: Regex the whole column name must match (default: 'leiden_' followed by numbers)

    Returns:
        List of column names sorted by resolution.
    """
    # Find matching columns in .obs
    # fullmatch: annotation columns such as 'leiden_0.5_cell_type' are not clusterings
    keys = [c for c in adata.obs.columns if re.fullmatch(pattern, c)]

    # Helper to sort by the number inside the string (e.g., 0.5, 1.0, 2.0);
    # names without a number sort after, alphabetically (keys must be comparable)
    def natural_sort_key(text):
        # Find the first floating point number in the string
        match = re.search(r"(\d+\.?\d*)", text)
        if match:
            return (0, float(match.group(1)), text)
        return (1, 0.0, text)

    return sorted(keys, key=natural_sort_key)


def plot_clustering_tree(
    adata,
    cluster_keys,
    title="Clustering Resolution Tree",
    min_edge_weight=0.05,
    edge_color="darkgray",
    num_layout_iterations=20,
):
    """
    Generates a clustering tree plot showing how cluster assignments change across resolutions.

    Args:
        adata: The AnnData object (or an object with an .obs attribute).
        cluster_keys (list): List of column names in adata.obs corresponding to clustering
                             resolutions (ordered low to high).
        title (str): Title of the plot.
        min_edge_weight (float): Minimum proportion of cells to show an edge.
                                 Helps clean up the plot by removing tiny overlaps.
        edge_color (str): Color for the edges (arrows). Can be a single color string
                          (e.g., 'gray', 'black') or a matplotlib colormap name
                          (e.g., 'viridis') for a gradient based on proportion.
        num_layout_iterations (int): Number of iterations for the barycenter layout
                                     algorithm to stabilize node positions.

    Returns:
        matplotlib.figure.Figure: The figure (call ``plt.show()`` yourself in scripts).
    """

    # 0. Validate Keys
    # ----------------
    missing_keys = [k for k in cluster_keys if k not in adata.obs.columns]
    if missing_keys:
        raise KeyError(
            f"The following keys provided are not in adata.obs: {missing_keys}.\n"
            "Tip: Make sure you are passing the column names (e.g., 'leiden_1.0'), "
            "not the color keys from .uns (e.g., 'leiden_1.0_colors')."
        )

    # 1. Prepare Data and Node Metadata
    # ---------------------------------
    df = adata.obs[cluster_keys].copy()

    # Ensure all columns are categorical/strings for consistent labeling
    for col in cluster_keys:
        df[col] = df[col].astype(str)

    # Structure to hold node info: { (layer_idx, cluster_label): { 'count': int, 'x': float, 'y': float } }
    nodes = {}

    # Structure to hold edge info: [ { 'u': (l, c1), 'v': (l+1, c2), 'weight': count, 'in_prop': float } ]
    edges = []

    # Initialize nodes with counts and y-coordinates
    for i, key in enumerate(cluster_keys):
        unique_labels = sorted(df[key].unique(), key=lambda x: (len(x), x))
        for label in unique_labels:
            count = df[df[key] == label].shape[0]
            nodes[(i, label)] = {
                "count": count,
                "y": -i,
                "x": 0.0,
            }  # Initialize x to 0.0

    # Calculate edges (transitions)
    for i in range(len(cluster_keys) - 1):
        curr_key = cluster_keys[i]
        next_key = cluster_keys[i + 1]

        ct = pd.crosstab(df[curr_key], df[next_key])

        for parent_label in ct.index:
            for child_label in ct.columns:
                weight = ct.loc[parent_label, child_label]
                child_size = nodes[(i + 1, child_label)]["count"]
                in_prop = weight / child_size if child_size > 0 else 0

                if in_prop >= min_edge_weight:
                    edges.append(
                        {
                            "u": (i, parent_label),
                            "v": (i + 1, child_label),
                            "weight": weight,
                            "in_prop": in_prop,
                        }
                    )

    # 2. Calculate Layout (Iterative Barycenter Heuristic for vertical alignment)
    # -------------------------------------------------------------------------
    # Initial ordering: Sort first layer by label.
    layer_order = []
    for i, key in enumerate(cluster_keys):
        layer_order.append(
            sorted(
                [k for (lbl, k) in nodes.keys() if lbl == i], key=lambda x: (len(x), x)
            )
        )

    # Assign initial x-coordinates based on sorted order
    for layer_idx, labels in enumerate(layer_order):
        for x_idx, label in enumerate(labels):
            nodes[(layer_idx, label)]["x"] = float(x_idx)

    # Iterative barycenter method
    for _ in range(num_layout_iterations):
        # Top-down pass
        for i in range(len(cluster_keys) - 1):
            layer_order[i]
            next_layer_labels = layer_order[i + 1]

            # Calculate barycenter for children based on parents' positions
            new_child_x_positions = {label: [] for label in next_layer_labels}
            for edge in edges:
                if edge["u"][0] == i:
                    parent_node = nodes[edge["u"]]
                    child_label = edge["v"][1]
                    new_child_x_positions[child_label].append(
                        parent_node["x"] * edge["weight"]
                    )

            for label in next_layer_labels:
                if new_child_x_positions[label]:
                    # Sum weights of all incoming edges for this child
                    total_incoming_weight = sum(
                        e["weight"] for e in edges if e["v"] == (i + 1, label)
                    )
                    if total_incoming_weight > 0:
                        nodes[(i + 1, label)]["x"] = (
                            sum(new_child_x_positions[label]) / total_incoming_weight
                        )

        # Bottom-up pass
        for i in range(
            len(cluster_keys) - 1, 0, -1
        ):  # From second to last layer up to first
            layer_order[i]
            prev_layer_labels = layer_order[i - 1]

            # Calculate barycenter for parents based on children's positions
            new_parent_x_positions = {label: [] for label in prev_layer_labels}
            for edge in edges:
                if edge["v"][0] == i:
                    child_node = nodes[edge["v"]]
                    parent_label = edge["u"][1]
                    new_parent_x_positions[parent_label].append(
                        child_node["x"] * edge["weight"]
                    )

            for label in prev_layer_labels:
                if new_parent_x_positions[label]:
                    # Sum weights of all outgoing edges for this parent
                    total_outgoing_weight = sum(
                        e["weight"] for e in edges if e["u"] == (i - 1, label)
                    )
                    if total_outgoing_weight > 0:
                        nodes[(i - 1, label)]["x"] = (
                            sum(new_parent_x_positions[label]) / total_outgoing_weight
                        )

        # Re-sort nodes within each layer based on updated x-coordinates
        for layer_idx in range(len(cluster_keys)):
            layer_labels_with_x = [
                (label, nodes[(layer_idx, label)]["x"])
                for label in layer_order[layer_idx]
            ]
            layer_labels_with_x.sort(key=lambda x: x[1])
            layer_order[layer_idx] = [label for label, _ in layer_labels_with_x]

            # Re-assign discrete x-coords for plotting after sorting
            for x_idx, label in enumerate(layer_order[layer_idx]):
                nodes[(layer_idx, label)]["x"] = float(
                    x_idx
                )  # Ensure integer positions for stability

    # Normalize X coordinates to make plot symmetric/centered
    # Scale to desired width (e.g., -5 to 5 or 0 to max_clusters_in_a_row - 1)
    max_nodes_in_row = max(len(lbl) for lbl in layer_order)

    # Recalculate node positions based on the final sorted order and spread
    for layer_idx, labels in enumerate(layer_order):
        # Re-assign positions for the layer, spreading them evenly
        if len(labels) > 1:
            step = max_nodes_in_row / (len(labels) - 1) if len(labels) > 1 else 0
            for x_idx, label in enumerate(labels):
                nodes[(layer_idx, label)]["x"] = x_idx * step
        else:  # Single node in layer
            nodes[(layer_idx, labels[0])]["x"] = (
                max_nodes_in_row / 2.0
            )  # Center single node

        # Center the entire layer
        layer_min_x = (
            min(nodes[(layer_idx, lbl)]["x"] for lbl in labels) if labels else 0
        )
        layer_max_x = (
            max(nodes[(layer_idx, lbl)]["x"] for lbl in labels) if labels else 0
        )
        layer_width = layer_max_x - layer_min_x
        centering_offset = (max_nodes_in_row - layer_width) / 2.0 - layer_min_x

        for label in labels:
            nodes[(layer_idx, label)]["x"] += centering_offset

    # 3. Plotting
    # -----------
    fig, ax = plt.subplots(
        figsize=(12, len(cluster_keys) * 1.5 + 2)
    )  # Adjust figsize for better readability

    # -- Define Colors per Node based on adata.uns --
    fallback_cmap = plt.colormaps["Spectral"].resampled(len(cluster_keys))
    node_colors = {}

    for i, key in enumerate(cluster_keys):
        uns_key = f"{key}_colors"
        specific_colors_map = None

        if hasattr(adata, "uns") and uns_key in adata.uns:
            try:
                if hasattr(adata.obs[key], "cat"):
                    categories = adata.obs[key].cat.categories
                    colors_list = adata.uns[uns_key]

                    if len(categories) == len(colors_list):
                        # Node labels are strings (see above), so key the map by str
                        specific_colors_map = dict(zip(map(str, categories), colors_list))
            except Exception as e:
                print(f"Warning: Could not map colors for {key}: {e}")

        layer_labels = layer_order[i]
        fallback_color = mcolors.to_hex(fallback_cmap(i))

        for label in layer_labels:
            if specific_colors_map and label in specific_colors_map:
                node_colors[(i, label)] = specific_colors_map[label]
            else:
                node_colors[(i, label)] = fallback_color

    # -- Edge Color Logic --
    edge_cmap = None

    # Priority 1: If it's a valid color string (e.g., 'gray', '#333333'), create a gradient to it
    # This check must come BEFORE plt.colormaps check because 'gray' is both a color and a colormap.
    # Matplotlib's 'gray' colormap is black->white (0->1), which is the opposite of what we want
    # (we want 1.0 to be the strong color).
    if mcolors.is_color_like(edge_color):
        try:
            target_rgb = mcolors.to_rgb(edge_color)
            # Gradient: White (0.0) -> Target Color (1.0)
            cdict = {
                "red": [(0.0, 1.0, 1.0), (1.0, target_rgb[0], target_rgb[0])],
                "green": [(0.0, 1.0, 1.0), (1.0, target_rgb[1], target_rgb[1])],
                "blue": [(0.0, 1.0, 1.0), (1.0, target_rgb[2], target_rgb[2])],
            }
            edge_cmap = mcolors.LinearSegmentedColormap(
                "custom_edge", segmentdata=cdict
            )
        except ValueError:
            pass

    # Priority 2: If not handled as a color, check if it's a named colormap
    if (
        edge_cmap is None
        and isinstance(edge_color, str)
        and edge_color in plt.colormaps
    ):
        edge_cmap = plt.colormaps[edge_color]

    # Priority 3: Fallback
    if edge_cmap is None:
        edge_cmap = plt.cm.gray_r  # Inverted gray (white -> black)

    # -- Draw Edges --
    for edge in edges:
        u_node = nodes[edge["u"]]
        v_node = nodes[edge["v"]]

        alpha = max(0.2, edge["in_prop"])  # Minimum visibility
        width = 1 + (edge["in_prop"] * 4)  # Slightly thicker max width

        # Get color from map
        edge_line_color = edge_cmap(edge["in_prop"])

        ax.annotate(
            "",
            xy=(v_node["x"], v_node["y"] + 0.1),
            xytext=(u_node["x"], u_node["y"] - 0.1),
            arrowprops=dict(
                arrowstyle="->",
                color=edge_line_color,
                alpha=alpha,
                lw=width,
                shrinkA=5,
                shrinkB=5,
                connectionstyle="arc3,rad=0.0",
            ),
        )

    # -- Draw Nodes --
    all_counts = [n["count"] for n in nodes.values()]
    max_count = max(all_counts) if all_counts else 1
    size_scale = 1000

    for (layer_idx, label), data in nodes.items():
        x, y = data["x"], data["y"]
        s = (data["count"] / max_count) * size_scale

        c = node_colors.get((layer_idx, label), "gray")

        ax.scatter(x, y, s=s, c=c, zorder=10, edgecolor="black", linewidth=0.5)

        font_size = 8 if len(label) < 3 else 6
        ax.text(
            x,
            y,
            label,
            ha="center",
            va="center",
            fontsize=font_size,
            color="white",
            fontweight="bold",
            zorder=11,
            path_effects=[
                m_fx.Stroke(linewidth=1.5, foreground="black"),
                m_fx.Normal(),
            ],
        )

    # 4. Formatting and Legends
    # -------------------------

    ax.set_yticks([-i for i in range(len(cluster_keys))])
    ax.set_yticklabels(cluster_keys)
    ax.set_ylabel("Clustering Resolution / Layer")

    ax.set_xticks([])
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)
    ax.spines["bottom"].set_visible(False)
    ax.spines["left"].set_visible(False)

    ax.set_title(title)

    # -- Custom Legend for Sizes (Adaptive Rounding) --
    # Generate nice numbers: roughly 20%, 50%, 100%
    raw_sizes = [max_count * 0.2, max_count * 0.5, max_count]
    nice_sizes = sorted(list(set([get_nice_number(s) for s in raw_sizes if s > 0])))

    legend_handles = []
    for s_val in nice_sizes:
        # Calculate size in points for the scatter marker
        s_point = (s_val / max_count) * size_scale
        legend_handles.append(
            plt.scatter(
                [], [], s=s_point, c="gray", alpha=0.5, label=f"{s_val:,} cells"
            )
        )

    legend1 = ax.legend(
        handles=legend_handles,
        title="Cluster Size",
        bbox_to_anchor=(1.05, 1),
        loc="upper left",
        frameon=False,
        scatterpoints=1,
    )
    ax.add_artist(legend1)

    # -- Custom Legend for In-Proportion --
    props = [0.2, 0.5, 0.8, 1.0]
    prop_handles = []
    for p in props:
        line_color = edge_cmap(p)
        line = plt.Line2D(
            [0], [0], color=line_color, alpha=p, lw=1 + (p * 4), label=f"{p:.1f}"
        )
        prop_handles.append(line)

    ax.legend(
        handles=prop_handles,
        title="In-Proportion",
        bbox_to_anchor=(1.05, 0.6),
        loc="upper left",
        frameon=False,
    )

    ax.autoscale_view()
    fig.subplots_adjust(right=0.75)  # Adjust right margin
    return fig


def import_obs_to_adata_from_csv(
    path: str,
    adata: sc.AnnData,
    obs_key: str,
    color_key: Optional[str] = None,
    index_col: int | str = 0,
    index_name: str = "Cell_ID",
    sep: Optional[str] = None,
    engine: str = "python",
    overwrite_existing: bool = False,
    to_category: bool = True,
) -> None:
    """
    Import a specific observation column from a CSV/TSV file and join it to adata.obs, matching on index/barcode.
    Optionally extracts colors if available and populates adata.uns.

    Parameters
    ----------
    path
        Path to the CSV file.
    adata
        AnnData object to modify in-place.
    obs_key
        The observation key (column name) to extract from the CSV.
    color_key
        The key indicating the column that stores colors. If None, defaults to `{obs_key}_colors`.
    index_col
        Column in the CSV to use as the index (barcode). Default is 0.
    index_name
        The name to apply to the adata.obs index (e.g. "Cell_ID"). Default is "Cell_ID".
    sep
        Separator used in the file. If None, it is inferred (e.g. comma or tab).
    engine
        Parser engine to use. Default "python".
    overwrite_existing
        If True, the column in the CSV will overwrite if it already exists in adata.obs.
        If False, existing columns are preserved and the imported column is stored as
        '{obs_key}_imported' (or '{obs_key}_imported_2', ... if that name is taken too).
    to_category
        If True, convert object-type columns in the imported data to categorical.
    """
    # Read the table (auto-detects comma vs tab)
    df = pd.read_csv(path, index_col=index_col, sep=sep, engine=engine)

    # Tidy up index and columns
    df.index = df.index.astype(str).str.strip()
    df.columns = df.columns.str.strip()

    if obs_key not in df.columns:
        print("HEAD OF CSV:")
        print(df.head())
        print(f"\nAvailable columns in the CSV are: {df.columns.tolist()}")
        raise ValueError(f"Observation key '{obs_key}' not found in CSV. Available columns: {df.columns.tolist()}")

    # Check for colors
    if color_key is None:
        color_key = f"{obs_key}_colors"

    # Drop duplicates in the CSV index to ensure unique mapping
    if df.index.duplicated().any():
        n_dupes = df.index.duplicated().sum()
        warnings.warn(f"Dropping {n_dupes} duplicate barcodes from CSV.")
        df = df.loc[~df.index.duplicated(keep="first")]

    # Extract only the specified obs column to join
    df_join = df[[obs_key]].copy()

    # Identify overlapping columns
    overlapping_cols = [obs_key] if obs_key in adata.obs.columns else []

    target_col = obs_key
    if overwrite_existing:
        if overlapping_cols:
            print(f"Overwriting column in adata.obs: {obs_key}")
            adata.obs = adata.obs.drop(columns=overlapping_cols)

        # Join
        adata.obs = adata.obs.join(df_join, how="left")
    else:
        # If not overwriting, append suffix to new data if overlap
        suffix = "_imported"
        if overlapping_cols:
            # First free name: '<key>_imported', then '<key>_imported_2', ...
            target_col = f"{obs_key}{suffix}"
            n = 2
            while target_col in adata.obs.columns:
                target_col = f"{obs_key}{suffix}_{n}"
                n += 1
            print(f"Column {obs_key} exists. Storing the imported data as '{target_col}'.")
            df_join = df_join.rename(columns={obs_key: target_col})
        adata.obs = adata.obs.join(df_join, how="left")

    # Optional: make columns categorical to save memory
    if to_category:
        if target_col in adata.obs:
            # Convert object columns to categorical
            if pd.api.types.is_object_dtype(adata.obs[target_col]) or pd.api.types.is_string_dtype(adata.obs[target_col]):
                 adata.obs[target_col] = adata.obs[target_col].astype("category")

    # Set index name
    adata.obs.index.name = index_name

    # Check if colors are available in the CSV to import
    if color_key in df.columns:
        if hasattr(adata.obs[target_col], "cat"):
            # Create a dictionary mapping the categories to their colors
            cat_to_color = df.drop_duplicates(subset=[obs_key]).set_index(obs_key)[color_key].to_dict()
            categories = adata.obs[target_col].cat.categories

            colors_list = []
            for cat in categories:
                # Fill missing colors with grey if not found
                color = cat_to_color.get(cat, "#808080")
                colors_list.append(color)

            # Store the list of colors in adata.uns
            target_color_key = f"{target_col}_colors"
            adata.uns[target_color_key] = colors_list
            print(f"Imported colors for '{target_col}' into adata.uns['{target_color_key}'].")
        else:
            warnings.warn(f"'{target_col}' is not categorical. Colors from '{color_key}' not imported.")
    else:
        warnings.warn(f"Color key '{color_key}' not found in CSV. Colors not imported.")

    # Quick sanity check
    n_common = adata.obs_names.isin(df.index).sum()
    print(f"Annotated {n_common}/{adata.n_obs} cells from CSV.")


def plot_marker_genes_dict_on_embedding(
    adata,
    marker_genes: Dict[str, List[str] | str],
    negative_marker_genes: Optional[Dict[str, List[str] | str]] = None,
    basis: str = "X_umap",
    colormaps: Optional[List[str] | str | Any] = None,
    score_method: Union[
        Literal[
            "scanpy",
            "binned",
            "binned_weighted",
            "net_scanpy",
            "net_binned",
            "net_binned_weighted",
        ],
        List[
            Literal[
                "scanpy",
                "binned",
                "binned_weighted",
                "net_scanpy",
                "net_binned",
                "net_binned_weighted",
            ]
        ],
    ] = "scanpy",
    **pl_kwargs,
) -> List[plt.Axes]:
    """
    Plot marker genes defined in a dictionary {tissue: [genes]} on an embedding (e.g. UMAP).

    Parameters
    ----------
    adata
        Annotated data matrix.
    marker_genes
        Dictionary where keys are tissue names (or categories) and values are lists of positive gene names.
    negative_marker_genes
        Optional dictionary where keys are tissue names and values are lists of negative gene names.
        These are only used for calculating the module score, not plotted individually.
    basis
        The basis to plot on (e.g., 'X_umap', 'X_pca'). Defaults to 'X_umap'.
    colormaps
        List of colormap names (or objects) to cycle through for different tissues.
        Can also be a single colormap (string or object) which will be used for all.
    score_method
        Method for calculating the module score: "scanpy", "binned", or "binned_weighted".
        Can be a string or a list of strings to plot multiple score methods side-by-side.
    **pl_kwargs
        Additional keyword arguments passed to `sc.pl.embedding`.
        Defaults set: s=50, show=False, frameon=False.

    Returns
    -------
    List[plt.Axes]
        A list of matplotlib Axes objects containing the plots.

    Notes:
        Supports passing a list of `score_method`s to compute and dynamically append multiple
        types of cell type scores (e.g., standard vs. net scores) to the visualized embedding.
    """

    # 1. Validate Basis
    f"X_{basis}" if not basis.startswith("X_") else basis
    # Scanpy usually looks for 'X_basis' if 'basis' is passed as argument 'basis'.
    # e.g., sc.pl.embedding(..., basis='umap') looks for 'X_umap'.
    # Here we check if the relevant key exists in obsm.

    # Common behavior: user passes 'umap', expects 'X_umap'.
    # Or user passes 'X_umap', expects 'X_umap'.
    possible_keys = [basis, f"X_{basis}" if not basis.startswith("X_") else basis]

    # Actually, scanpy's sc.pl.embedding `basis` argument handles the X_ prefix automatically.
    # But for our explicit check as requested:
    # We check if the likely key exists.

    basis_key_exists = False
    for k in possible_keys:
        if k in adata.obsm:
            basis_key_exists = True
            break

    if not basis_key_exists:
        raise ValueError(
            f"Basis '{basis}' (checked {possible_keys}) not found in adata.obsm. "
            f"Please compute it and add in obsm, or choose from available keys: {list(adata.obsm.keys())}"
        )

    # 2. Check Genes
    # Genes are scored and plotted from adata.raw when it exists, unless the caller
    # passes use_raw=False or a layer (the same default as sc.pl.embedding).
    layer = pl_kwargs.get("layer")
    use_raw = pl_kwargs.get("use_raw")
    if use_raw is None:
        use_raw = adata.raw is not None and layer is None
    use_raw = bool(use_raw) and adata.raw is not None
    pl_kwargs["use_raw"] = use_raw

    # Updates the marker_genes dict to only include found genes
    marker_genes = check_gene_adata(adata, marker_genes, use_raw=use_raw)
    if negative_marker_genes is not None:
        negative_marker_genes = check_gene_adata(
            adata, negative_marker_genes, use_raw=use_raw
        )

    # 3. Setup Colormaps
    if colormaps is None:
        colormaps = [
            "Blues",
            "Reds",
            "Purples",
            "Oranges",
            "Greens",
            "Greens",
            "YlOrBr",
            "Greens",
            "RdPu",
            "Oranges",
            "PuRd",
            "YlOrBr",
        ]
    elif not isinstance(colormaps, (list, tuple)):
        # If a single colormap (str or object) is passed, wrap it in a list
        colormaps = [colormaps]

    # 4. Normalize score_method
    if isinstance(score_method, str):
        methods_to_run = [score_method]
    elif isinstance(score_method, (list, tuple)):
        methods_to_run = list(score_method)
    else:
        methods_to_run = ["scanpy"]

    # 5. Default Kwargs
    pl_kwargs.setdefault("s", 50)
    pl_kwargs.setdefault("show", False)
    pl_kwargs.setdefault("frameon", False)

    # 6. Plotting Loop
    axes_list = []

    for idx_i, (tissue, genes) in enumerate(marker_genes.items()):
        if not genes:
            print(f"Skipping {tissue}: No valid marker genes found.")
            continue

        current_cmap = colormaps[idx_i % len(colormaps)]

        # Prepare items to plot: expression of positive genes
        items_to_plot = list(genes)

        computed_score_names = []
        # Caller's columns that share a score name are restored after plotting
        saved_columns = {}

        for method in methods_to_run:
            score_name = f"{tissue}_score_{method}"
            try:
                # We use score_celltypes to leverage the new methods
                # It expects a dictionary of markers
                ct_dict = {tissue: genes}

                # Check for negative markers
                neg_dict = None
                if negative_marker_genes and tissue in negative_marker_genes:
                    neg_dict = {tissue: negative_marker_genes[tissue]}

                # score_celltypes calculates the score
                scores_df = score_celltypes(
                    adata,
                    cell_type_markers_dict=ct_dict,
                    cell_type_negative_markers_dict=neg_dict,
                    layer=layer,
                    use_raw=use_raw,
                    score_method=method,
                    min_markers=1,
                )

                # Extract the column
                if tissue in scores_df.columns:
                    score_col = scores_df[tissue]
                    if not score_col.isna().all():
                        if score_name in adata.obs and score_name not in saved_columns:
                            saved_columns[score_name] = adata.obs[score_name].copy()
                        adata.obs[score_name] = score_col.values
                        computed_score_names.append(score_name)
                    else:
                        print(
                            f"Could not compute score for {tissue} ({method}): Not enough markers found."
                        )
                else:
                    print(
                        f"Could not compute score for {tissue} ({method}): Tissue missing from results."
                    )

            except Exception as e:
                print(f"Could not compute score for {tissue} ({method}): {e}")

        # Add all computed scores to the plot list
        items_to_plot.extend(computed_score_names)

        # sc.pl.embedding returns a list of axes if show=False and multiple genes are plotted,
        # or a single axis if one gene. Or None if show=True.
        # Here 'color' is a list of genes.
        try:
            res = sc.pl.embedding(
                adata, basis=basis, color=items_to_plot, cmap=current_cmap, **pl_kwargs
            )
        finally:
            # Remove the temporary score columns from obs, restoring any column of
            # the same name that existed before the call
            for name in computed_score_names:
                if name in saved_columns:
                    adata.obs[name] = saved_columns[name]
                elif name in adata.obs:
                    del adata.obs[name]

        # Normalize result to a single axis or list of axes
        # Scanpy's embedding returns: Union[Axes, List[Axes], None]
        # If multiple genes, it returns List[Axes].

        # The user snippet logic:
        # ax = axes[0] if isinstance(axes, list) and axes else axes
        # This implies we want to grab the axis to modify it.
        # Warning: if multiple genes are passed, sc.pl.embedding creates multiple subplots (one per gene).
        # The user snippet seems to assume one plot or just modifies the first?
        # "Plotting UMAPs for each tissue type ... color=genes"
        # If 'genes' is a list, scanpy plots multiple panels.
        # The user's code: "ax = axes[0] ... ax.set_ylabel(tissue...)"
        # This puts the tissue label on the first panel.

        # If 'res' is a list, scanpy returned multiple subplots (one per gene).
        # If 'res' is a single Axes, scanpy returned one plot (one gene).

        ax = res[0] if isinstance(res, list) and res else res

        # We disabled axis drawing in UMAP to have plots without background and border
        # so we need to re-enable axis to plot the ylabel
        # We apply this to the first axis (where we put the ylabel), as per snippet logic.

        if ax:
            ax.axis("on")
            ax.tick_params(
                top="off",
                bottom="off",
                left="off",
                right="off",
                labelleft="on",
                labelbottom="off",
            )
            ax.set_ylabel(tissue + "\n", rotation=90, fontsize=14)
            ax.set_xlabel(" ", fontsize=1)
            ax.set(frame_on=False)

        # Collect axes.
        # Since we modified the first axis in place, 'res' (if list) or 'res' (if object) still holds it.
        # But wait: if res is a list, I appended 'ax' (res[0]) in my previous logic, then appended 'res' (the list).
        # This resulted in [ax, ax, ax2, ax3]. That's bad.

        if isinstance(res, list):
            axes_list.extend(res)
        else:
            axes_list.append(res)

    return axes_list


def check_gene_adata(adata, gene, use_raw: bool = False):
    """
    Checks if a gene or a collection of genes exist in the adata object.

    Parameters:
    - adata: The AnnData object containing gene information.
    - gene: A string, list, or dictionary of genes to check.
    - use_raw: Check against ``adata.raw.var_names`` (when ``adata.raw`` exists)
      instead of ``adata.var_names``.

    Returns:
    - A sanitized version of the input 'gene', containing only genes present in adata.
    """
    var_names = (
        adata.raw.var_names if use_raw and adata.raw is not None else adata.var_names
    )

    if isinstance(gene, str):
        if gene in var_names:
            return gene
        else:
            print(f"Gene '{gene}' not found in adata.")
            return None  # Or you could raise an exception here

    elif isinstance(gene, list):
        sanitized_genes = [g for g in gene if g in var_names]
        not_found_genes = [g for g in gene if g not in var_names]
        for g in not_found_genes:
            print(f"Gene '{g}' not found in adata.")
        return sanitized_genes

    elif isinstance(gene, dict):
        sanitized_dict = {}
        for key, genes in gene.items():
            if isinstance(genes, str):
                genes = [genes]  # Convert single gene string to a list
            sanitized_genes = [g for g in genes if g in var_names]
            not_found_genes = [g for g in genes if g not in var_names]
            for g in not_found_genes:
                print(f"Gene '{g}' not found in adata (key: '{key}').")
            sanitized_dict[key] = sanitized_genes
        return sanitized_dict

    else:
        raise TypeError("Input 'gene' must be a string, list, or dictionary.")


def _compute_neighbors_graph(adata, key: str = "connectivities", **neighbors_kwargs) -> None:
    """Run ``sc.pp.neighbors`` so that its connectivities end up in ``adata.obsp[key]``.

    scanpy stores graphs as ``'connectivities'`` (default) or
    ``'<key_added>_connectivities'``; any other key cannot be produced by it.
    """
    suffix = "_connectivities"
    if key == "connectivities":
        sc.pp.neighbors(adata, **neighbors_kwargs)
    elif key.endswith(suffix) and len(key) > len(suffix):
        sc.pp.neighbors(adata, key_added=key[: -len(suffix)], **neighbors_kwargs)
    else:
        raise ValueError(
            f"Graph '{key}' is not in adata.obsp and cannot be built here: sc.pp.neighbors "
            f"stores graphs as 'connectivities' or '<key_added>{suffix}'. Use one of those "
            f"names or compute the graph yourself."
        )


def ensure_neighbors(
    adata,
    n_neighbors: Optional[int] = None,
    use_rep: Optional[str] = "X_pca",
    key: str = "connectivities",
    n_pcs: Optional[int] = None,
) -> None:
    """
    Make sure adata.obsp[key] exists; builds neighbors in-place if missing.
    Supports both standard Scanpy usage (via use_rep) and Triku usage (via n_pcs).
    `key` must be 'connectivities' or '<name>_connectivities' (scanpy's `key_added` naming)
    for the graph to be buildable.
    """
    if n_neighbors is None:
        n_neighbors = pacmap_heuristic_n_neighbors(adata.n_obs)
    if key not in adata.obsp:
        if use_rep is None and n_pcs is not None:
            # Triku-style: use specific number of PCs without a named representation
            _compute_neighbors_graph(adata, key, n_neighbors=n_neighbors, n_pcs=n_pcs)
        else:
            # Standard style: use provided representation (default "X_pca")
            _compute_neighbors_graph(adata, key, n_neighbors=n_neighbors, use_rep=use_rep)


def _select_matrix_and_names(
    adata, source: Literal["X", "raw"] | str = "X"
) -> Tuple[sp.spmatrix | np.ndarray, np.ndarray]:
    """Return (matrix, var_names) according to `source` ('X', 'raw', or layer name)."""
    if source == "raw":
        if adata.raw is None:
            raise ValueError("source='raw' requested but adata.raw is None.")
        return adata.raw.X, np.array(adata.raw.var_names)
    if source == "X":
        return adata.X, np.array(adata.var_names)
    # otherwise assume a layer name
    if source not in adata.layers:
        raise KeyError(f"Layer '{source}' not found.")
    return adata.layers[source], np.array(adata.var_names)


def _match_gene_indices(
    var_names: np.ndarray, gene: str, case_insensitive: bool = True, upper=None
) -> np.ndarray:
    """
    Return the column indices of `gene`.

    An exact (case-sensitive) name always wins: if `gene` occurs exactly, only those
    columns are returned, so 'ACTB' never picks up a distinct 'Actb' feature. Only when
    there is no exact match and `case_insensitive` is True are all case variants
    returned (callers then combine them with their duplicate policy). `upper` may pass
    precomputed upper-cased names.
    """
    arr = np.asarray(var_names).astype(str)
    exact = np.flatnonzero(arr == str(gene))
    if exact.size or not case_insensitive:
        return exact
    if upper is None:
        upper = pd.Index(arr).str.upper().to_numpy()
    return np.flatnonzero(np.asarray(upper) == str(gene).upper())


def smooth_expression_on_graph(
    adata: sc.AnnData,
    X: Union[np.ndarray, sp.spmatrix],
    weights_key: str = "connectivities",
) -> np.ndarray:
    """
    Diffuses an expression matrix over a cell-cell graph by multiplying it
    with the row-standardized connectivities matrix. This acts as a smoothing
    filter, averaging a cell's expression with its neighbors.

    Args:
        adata: The annotated data matrix containing the graph in `.obsp`.
        X: The expression matrix to smooth (dense or sparse).
        weights_key: The key in `adata.obsp` containing the graph edges.
                     Defaults to "connectivities".

    Returns:
        A dense numpy array of the smoothed expression.
    """
    if weights_key not in adata.obsp:
        raise ValueError(f"Graph weights '{weights_key}' not found in adata.obsp.")

    W = adata.obsp[weights_key].tocsr().copy()

    # matth: Mathematically compute A + I.
    # This properly adds self-loops without overwriting existing diagonal data,
    # and avoids SciPy SparseEfficiencyWarnings caused by setdiag.
    # In graph signal processing, a proper low-pass filter (lazy random walk)
    # requires non-zero diagonal entries to prevent bipartite oscillations and
    # ensure the node retains a fraction of its original signal.
    W = W + sp.eye(W.shape[0], format="csr")

    # Row-standardize W to create a diffusion operator
    rs = np.asarray(W.sum(axis=1)).ravel()
    nz = rs > 0

    # matth: Dynamically inherit the dtype of the matrix (usually float32)
    # to prevent UFuncTypeError during the in-place multiplication below.
    inv = np.zeros_like(rs, dtype=W.dtype)
    inv[nz] = 1.0 / rs[nz]

    row_nnz = np.diff(W.indptr)
    if row_nnz.size > 0:
        W.data *= np.repeat(inv, row_nnz)

    # Apply diffusion
    if sp.issparse(X):
        # Result of sparse @ sparse or sparse @ dense is often dense or needs casting
        X_smooth = W.dot(X)
        if sp.issparse(X_smooth):
            X_smooth = X_smooth.toarray()
    else:
        X_smooth = W.dot(np.asarray(X))

    return np.asarray(X_smooth)


def _extract_gene_vector(
    adata,
    gene: str,
    *,
    source: Literal["X", "raw"] | str = "X",
    duplicate_policy: Literal["mean", "sum", "first", "last"] = "mean",
) -> np.ndarray:
    """
    Dense (n_cells,) float vector for `gene` from the chosen source.
    Handles duplicates deterministically via `duplicate_policy`.

    Matching follows `_match_gene_indices`: columns named exactly `gene` win; case
    variants (e.g. 'Actb' for 'ACTB') are used only when no exact name exists.
    """
    M, names = _select_matrix_and_names(adata, source)
    idx = _match_gene_indices(names, gene, case_insensitive=True)
    if idx.size == 0:
        raise KeyError(f"Gene '{gene}' not found in {source}.")
    if sp.issparse(M):
        if idx.size == 1 or duplicate_policy in ("first", "last"):
            j = idx[0] if duplicate_policy != "last" else idx[-1]
            x = M[:, j].toarray().ravel()
        elif duplicate_policy == "sum":
            x = M[:, idx].sum(axis=1)
            x = x.A1 if hasattr(x, "A1") else np.ravel(x)
        else:  # mean
            k = idx.size
            x = M[:, idx] @ np.full((k, 1), 1.0 / k, dtype=float)
            x = x.A1 if hasattr(x, "A1") else np.ravel(x)
    else:
        M = np.asarray(M)
        if idx.size == 1 or duplicate_policy in ("first", "last"):
            j = idx[0] if duplicate_policy != "last" else idx[-1]
            x = M[:, j].ravel()
        elif duplicate_policy == "sum":
            x = M[:, idx].sum(axis=1)
        else:
            x = M[:, idx].mean(axis=1)
    return np.asarray(x, dtype=float)


def _extract_gene_matrix(
    adata,
    genes: Sequence[str],
    *,
    source: Literal["X", "raw"] | str = "X",
) -> np.ndarray:
    """
    Dense (n_cells, len(genes)) float matrix: column j equals
    ``_extract_gene_vector(adata, genes[j], source=source, duplicate_policy="mean")``,
    but the matrix is sliced once for all genes instead of once per gene.
    """
    M, names = _select_matrix_and_names(adata, source)
    names = np.asarray(names).astype(str)
    upper = pd.Index(names).str.upper().to_numpy()
    cols, rows, vals = [], [], []
    for j, gene in enumerate(genes):
        idx = _match_gene_indices(names, gene, upper=upper)
        if idx.size == 0:
            raise KeyError(f"Gene '{gene}' not found in {source}.")
        cols.extend(idx)
        rows.extend([j] * idx.size)
        vals.extend([1.0 / idx.size] * idx.size)
    used, inv = np.unique(np.asarray(cols, dtype=np.int64), return_inverse=True)
    # (n_used, n_genes) averaging matrix: duplicates of a name are averaged
    G = sp.csr_matrix((vals, (inv, rows)), shape=(used.size, len(genes)))
    block = M[:, used]
    out = block @ G if sp.issparse(block) else np.asarray(block, dtype=float) @ G.toarray()
    out = out.toarray() if sp.issparse(out) else np.asarray(out)
    return np.asarray(out, dtype=float)


# ------------------------- Moran Tools -------------------------


def build_rowstd_connectivities(
    adata,
    *,
    key: str = "connectivities",
    recompute: bool = False,
    n_neighbors: Optional[int] = None,
    use_rep: Optional[str] = "X_pca",
) -> sp.csr_matrix:
    """
    Return row-standardized SciPy CSR (W) from Scanpy's neighbor graph.
    Suitable for fast block matmuls used in morans_i_all_fast.
    """
    if n_neighbors is None:
        n_neighbors = pacmap_heuristic_n_neighbors(adata.n_obs)
    if recompute or key not in adata.obsp:
        _compute_neighbors_graph(adata, key, n_neighbors=n_neighbors, use_rep=use_rep)
    W = adata.obsp[key].tocsr(copy=True)
    W.sort_indices()
    W = W.astype(np.float32, copy=False)
    rs = np.asarray(W.sum(axis=1)).ravel().astype(np.float32)
    nz = rs > 0
    inv = np.zeros_like(rs, dtype=np.float32)
    inv[nz] = 1.0 / rs[nz]

    # In-place row normalization to avoid allocating a new sparse matrix
    # W is CSR: W.data elements are ordered by row.
    # We repeat the inverse-sum for row i for all its non-zero elements.
    row_nnz = np.diff(W.indptr)
    if row_nnz.size > 0:
        scale_vector = np.repeat(inv, row_nnz)
        W.data *= scale_vector

    W.sum_cache = float(W.sum())  # cache S0
    return W


def build_pysal_weights(
    adata,
    key: str = "connectivities",
    *,
    recompute: bool = False,
    n_neighbors: Optional[int] = None,
    use_rep: str = "X_pca",
    method: str = "umap",
    random_state: int = 0,
):
    """
    Return a row-standardized PySAL weights object built from adata.obsp[key].
    """
    if n_neighbors is None:
        n_neighbors = pacmap_heuristic_n_neighbors(adata.n_obs)
    if recompute or (key not in adata.obsp):
        _compute_neighbors_graph(
            adata,
            key,
            n_neighbors=n_neighbors,
            use_rep=use_rep,
            method=method,
            random_state=random_state,
        )
    A = adata.obsp[key].tocsr().astype(float)
    w = WSP(A).to_W()  # <-- correct constructor
    w.transform = "R"  # row-standardize
    return w


def morans_i(
    adata,
    genes: Sequence[str],
    w=None,
    *,
    weights_key: str = "connectivities",
    source: Literal["X", "raw"] | str = "X",
    duplicate_policy: Literal["mean", "sum", "first", "last"] = "mean",
    permutations: int = 999,
    center: bool = True,
) -> pd.DataFrame:
    """
    Moran's I (with permutation p) for a set of genes. Deterministic if `w` is reused.
    """
    if w is None:
        w = build_pysal_weights(adata, key=weights_key)

    rows = []
    for g in genes:
        x = _extract_gene_vector(
            adata, g, source=source, duplicate_policy=duplicate_policy
        )
        if center:
            x = x - x.mean()
        mi = Moran(x, w, permutations=permutations)
        rows.append({"gene": g, "I": mi.I, "p_sim": mi.p_sim, "z_sim": mi.z_sim})
    df = pd.DataFrame(rows, columns=["gene", "I", "p_sim", "z_sim"])
    return df.sort_values("I", ascending=False).reset_index(drop=True)


def _ensure_csr_f32(A: sp.csr_matrix) -> sp.csr_matrix:
    A = A.tocsr(copy=False)
    A.sort_indices()
    return A.astype(np.float32, copy=False)


def _build_dedup_aggregator(
    var_names: np.ndarray,
    how: Literal["mean", "sum"] = "mean",
    case_insensitive: bool = False,
) -> Tuple[np.ndarray, sp.csr_matrix]:
    """
    Return (uniq_names, G) where X_uniq = X @ G collapses duplicate columns.

    By default only identical names are duplicates; names that differ only by case
    ('Actb', 'ACTB') are distinct features, consistent with `_match_gene_indices`
    and with the 'first'/'last' modes of `morans_i_all_fast`.
    """
    names = np.asarray(var_names).astype(str)
    keys = np.char.upper(names) if case_insensitive else names
    uniq_keys, idx, inv = np.unique(keys, return_index=True, return_inverse=True)
    uniq = names[idx]
    n, m = names.size, uniq.size
    data = np.ones(n, dtype=np.float32)
    rows = np.arange(n, dtype=np.int32)
    cols = inv.astype(np.int32)
    G = sp.csr_matrix((data, (rows, cols)), shape=(n, m))
    if how == "mean":
        col_counts = np.asarray(G.sum(axis=0)).ravel().astype(np.float32)
        G = G @ sp.diags(1.0 / np.maximum(col_counts, 1.0))
    return uniq, G


def _compute_moran_moments(W: sp.csr_matrix) -> Tuple[float, float, float]:
    """
    Compute S0, S1, S2 for variance of Moran's I.
    S0 = sum(wij)
    S1 = 0.5 * sum((wij + wji)^2)
    S2 = sum((sum_j wij + sum_j wji)^2)
    """
    # W is row-standardized, but not necessarily symmetric.
    # W should be float32/64.

    # S0
    S0 = float(W.sum())

    # S1: 0.5 * sum((W + W.T)^2)
    # Note: (W + W.T) is efficient for sparse
    Wt = W.transpose()
    T = W + Wt
    S1 = float(T.power(2).sum()) / 2.0

    # S2: sum((RowSum + ColSum)^2)
    # Row sums
    R = np.asarray(W.sum(axis=1)).flatten()
    # Col sums
    C = np.asarray(W.sum(axis=0)).flatten()
    S2 = float(np.sum((R + C) ** 2))

    return S0, S1, S2


def morans_i_all_fast(
    adata,
    *,
    W_rowstd: Optional[sp.csr_matrix] = None,  # row-standardized CSR
    weights_key: str = "connectivities",
    source: Literal["X", "raw"] | str = "X",
    deduplicate: Literal["none", "mean", "sum", "first", "last"] = "mean",
    block_genes: int = 1024,
    dtype=np.float32,
    center: bool = True,
) -> pd.DataFrame:
    """
    Fast Moran's I for all genes with analytical p-values (randomization null).
    Uses the identity I = (n/S0) * (x^T W x) / (x^T x).
    Returns DataFrame ['gene','I', 'pval_z', 'z_score'] sorted by I desc.

    `deduplicate` combines columns with identical names (all modes are
    case-sensitive: 'Actb' and 'ACTB' are reported separately).
    """
    if W_rowstd is None:
        W_rowstd = build_rowstd_connectivities(adata, key=weights_key)
    W = _ensure_csr_f32(W_rowstd)

    # pick matrix
    M, names = _select_matrix_and_names(adata, source)
    X = M.tocsr(copy=False) if sp.issparse(M) else np.asarray(M, dtype=dtype)

    # optional de-duplication (collapses columns once)
    if deduplicate == "none":
        out_names = np.asarray(names).astype(str)
    elif deduplicate in ("mean", "sum"):
        uniq, G = _build_dedup_aggregator(
            np.asarray(names).astype(str), how=deduplicate
        )
        X = (X @ G) if sp.issparse(X) else (np.asarray(X, dtype=dtype) @ G)
        out_names = uniq
    else:  # first / last
        df = pd.DataFrame({"name": np.asarray(names).astype(str)})
        keep_idx = (
            df[::-1].drop_duplicates("name").index[::-1]
            if deduplicate == "last"
            else df.drop_duplicates("name").index
        )
        X = X[:, keep_idx]
        out_names = np.asarray(names)[keep_idx].astype(str)

    # cast shapes/types for block ops
    if sp.issparse(X):
        X = X.tocsc(copy=False)
        if X.dtype != dtype:
            X = X.astype(dtype)
    else:
        X = np.asarray(X, dtype=dtype)

    n = X.shape[0]

    if n <= 3:
        # Variance formula requires n > 3. Return simple I without stats if n is too small.
        # Although I itself is defined, p-values are not.
        warnings.warn(
            "Number of observations n <= 3, cannot compute Moran's I statistics (z-score/p-value)."
        )
        # Just compute I without variance
        # (Fallthrough to simpler loop or handle gracefully? Since n is tiny, efficiency doesn't matter)
        # We can just run the loop and set stats to NaN.
        S0, S1, S2 = float(W.sum()), 0.0, 0.0
        var_denom = np.nan
        term_A = 0.0
        term_B_coeff = 0.0
        nfac = (n / S0) if S0 > 0 else 0.0
    else:
        # Precompute moments of W
        S0, S1, S2 = _compute_moran_moments(W)

        nfac = (n / S0) if S0 > 0 else 0.0

        # Denominator for Var(I)
        var_denom = (n - 1) * (n - 2) * (n - 3) * (S0**2)

        # Term A (independent of kurtosis)
        # A = n * ( (n^2 - 3n + 3) * S1 - n * S2 + 3 * S0^2 )
        term_A = n * ((n**2 - 3 * n + 3) * S1 - n * S2 + 3 * S0**2)

        # Term B coefficient (multiplies kurtosis b2)
        # B = (n^2 - n) * S1 - 2*n * S2 + 6 * S0^2
        term_B_coeff = (n**2 - n) * S1 - 2 * n * S2 + 6 * S0**2

    # precompute means if centering
    if center:
        if sp.issparse(X):
            # accumulate in float64 like the dense path: a float32 sum drifts, so a
            # constant gene would get a non-zero constant deviation and I = 1
            mu = (
                np.asarray(X.sum(axis=0, dtype=np.float64)).ravel() / float(n)
            ).astype(np.float32)
        else:
            mu = (X.sum(axis=0, dtype=np.float64) / float(n)).astype(np.float32)
    else:
        mu = np.zeros(X.shape[1], dtype=np.float32)

    G = X.shape[1]
    I_vals = np.empty(G, dtype=np.float32)
    # float64: p-values underflow to 0 in float32 once |z| exceeds ~13
    Z_vals = np.full(G, np.nan, dtype=np.float64)
    P_vals = np.full(G, np.nan, dtype=np.float64)

    # Constant for Expected I: E[I] = -1 / (N-1)
    if n > 1:
        E_I = -1.0 / (n - 1)
    else:
        E_I = np.nan

    for j0 in range(0, G, block_genes):
        j1 = min(G, j0 + block_genes)
        Xb_raw = X[:, j0:j1]

        # Ensure dense float32 for calculations
        Xb = (
            Xb_raw.toarray().astype(np.float32, copy=False)
            if sp.issparse(Xb_raw)
            else np.asarray(Xb_raw, dtype=np.float32)
        )

        mub = mu[j0:j1]

        if center:
            # matth: Operate directly on mean-centered variables to avoid catastrophic cancellation
            # and algebraic expansions. This naturally handles irregular weights without complex terms.
            if np.shares_memory(Xb, X):
                Xb_dev = Xb - mub[None, :]
            else:
                Xb_dev = Xb
                np.subtract(Xb_dev, mub[None, :], out=Xb_dev)

            WXb_dev = W @ Xb_dev

            num = np.einsum("ij,ij->j", Xb_dev, WXb_dev, dtype=np.float64)
            den = np.einsum("ij,ij->j", Xb_dev, Xb_dev, dtype=np.float64)

            # Bolt: Optimize memory. WXb_dev is no longer needed.
            del WXb_dev

            # Kurtosis calculation: sum((x-u)^4)
            # Optimize x^4 as (x^2)^2 using repeated multiplication in-place
            np.multiply(Xb_dev, Xb_dev, out=Xb_dev)
            np.multiply(Xb_dev, Xb_dev, out=Xb_dev)
            sum_fourth = np.sum(Xb_dev, axis=0, dtype=np.float64)

            if np.shares_memory(Xb, X):
                del Xb_dev
        else:
            WXb = W @ Xb
            num = np.einsum("ij,ij->j", Xb, WXb, dtype=np.float64)
            den = np.einsum("ij,ij->j", Xb, Xb, dtype=np.float64)
            del WXb

            # Kurtosis calculation: sum(x^4)
            if np.shares_memory(Xb, X):
                # Optimize x^4 as (x^2)^2 using repeated multiplication
                Xb_dev = np.multiply(Xb, Xb)
                np.multiply(Xb_dev, Xb_dev, out=Xb_dev)
                sum_fourth = np.sum(Xb_dev, axis=0, dtype=np.float64)
                del Xb_dev
            else:
                # Optimize x^4 as (x^2)^2 using repeated multiplication
                np.multiply(Xb, Xb, out=Xb)
                np.multiply(Xb, Xb, out=Xb)
                sum_fourth = np.sum(Xb, axis=0, dtype=np.float64)

        # Zero variance (NaN I): sum of squared deviations at or below float32
        # rounding of the mean, i.e. a constant gene.
        tol = n * (8 * np.finfo(np.float32).eps * np.abs(mub.astype(np.float64))) ** 2
        den = np.where(den > tol, den, np.nan)
        I_vals[j0:j1] = nfac * (num / den).astype(np.float32)

        # Variance Calculation
        if n > 3:
            # b2 = n * sum(z^4) / (sum(z^2))^2
            # den is sum(z^2)
            # handle den=0 case safely
            den_safe = np.where(den > 0, den, np.inf)  # avoid div by zero
            b2 = (n * sum_fourth) / (den_safe**2)

            # Var(I)
            var_I = (term_A - b2 * term_B_coeff) / var_denom - E_I**2

            # Clip negative variance (numerical noise)
            var_I = np.maximum(var_I, 0.0)

            sd_I = np.sqrt(var_I)

            # Avoid division by zero if variance is tiny (constant I)
            z = np.zeros(j1 - j0, dtype=np.float64)
            mask_sd = sd_I > 1e-12
            z[mask_sd] = (I_vals[j0:j1][mask_sd] - E_I) / sd_I[mask_sd]

            # P-value (two-sided)
            p = 2 * norm.sf(np.abs(z))

            Z_vals[j0:j1] = z
            P_vals[j0:j1] = p

    out = pd.DataFrame(
        {"gene": out_names, "I": I_vals, "pval_z": P_vals, "z_score": Z_vals}
    )
    out.sort_values("I", ascending=False, inplace=True, kind="mergesort")
    out.reset_index(drop=True, inplace=True)
    return out


# ------------------------- Archetype Tools -------------------------


def find_expression_archetypes(
    adata: sc.AnnData,
    gene_list: Sequence[str],
    num_clusters: int,
    *,
    source: Literal["X", "raw"] | str = "X",
) -> Dict[str, Any]:
    """
    Clusters genes based on expression data and finds gene archetypes.

    Re-implements the user's function to work with AnnData and a specified gene list.
    The clustering is hierarchical (Ward method) on the genes based on their
    expression profiles across all cells.

    Args:
        adata: The annotated data matrix.
        gene_list: A list of gene names to use for clustering (e.g., top Moran's I genes).
        num_clusters: The target number of gene clusters (archetypes).
        source: The data source in adata to use ('X', 'raw', or a layer name).

    Returns:
        A dictionary containing:
        - 'archetypes': (num_clusters, n_cells) array of archetype profiles, each with
                        mean 0 and unit standard deviation across cells (the scale of a
                        Z-scored gene), so archetypes can be compared with each other.
        - 'clusters': (n_genes,) array of cluster assignments (1-based) for each gene.
        - 'gene_corrs': (n_genes,) array of Pearson correlations for each gene
                          to its assigned archetype.
        - 'gene_list': The list of gene names used, in the same order as 'clusters'
                       and 'gene_corrs'.
        - 'linkage_matrix': The (n_genes-1, 4) linkage matrix from hierarchy.ward.
    """
    print("Finding gene archetypes ... ", flush=True, end="")

    gene_list = [str(g) for g in gene_list]  # accepts pd.Series / ndarray
    if len(gene_list) == 0:
        raise ValueError("`gene_list` cannot be empty.")

    if num_clusters < 1:
        raise ValueError("`num_clusters` must be at least 1.")

    # 1. Get the full (n_cells, n_all_genes) matrix and all gene names
    M, all_names = _select_matrix_and_names(adata, source=source)
    all_names_index = pd.Index(all_names)

    # 2. Find the integer indices for the requested gene_list
    # We use get_indexer to maintain the order of gene_list. get_indexer needs a
    # unique index, so duplicated names resolve to their first occurrence.
    first = ~all_names_index.duplicated(keep="first")
    pos = all_names_index[first].get_indexer(gene_list)
    var_idx = np.where(pos >= 0, np.flatnonzero(first)[pos], -1)

    # Check for missing genes
    missing_mask = var_idx == -1
    if missing_mask.any():
        missing_genes = np.array(gene_list)[missing_mask]
        warnings.warn(
            f"The following genes were not found in source '{source}' and will be skipped: "
            f"{list(missing_genes)}"
        )
        # Filter out missing genes and their indices
        var_idx = var_idx[~missing_mask]
        final_gene_list = list(np.array(gene_list)[~missing_mask])
        if not final_gene_list:
            raise ValueError("No requested genes were found in the data source.")
    else:
        final_gene_list = gene_list

    # 3. Create the (n_cells, n_genes) sub-matrix
    M_sub = M[:, var_idx]

    # 4. Transpose to (n_genes, n_cells) and ensure dense for clustering
    # This is the `sdge` matrix from the original function
    if sp.issparse(M_sub):
        sdge = M_sub.toarray().T
    else:
        sdge = np.asarray(M_sub).T

    if sdge.shape[0] <= 1:
        raise ValueError(
            f"Only {sdge.shape[0]} valid genes found. Cannot perform clustering."
        )

    # Ensure num_clusters is not more than the number of genes
    if num_clusters > sdge.shape[0]:
        warnings.warn(
            f"`num_clusters` ({num_clusters}) is greater than the number of "
            f"genes ({sdge.shape[0]}). Setting `num_clusters` to {sdge.shape[0]}."
        )
        num_clusters = sdge.shape[0]

    # 5. Perform hierarchical clustering on genes
    # hierarchy.ward computes the linkage matrix from the (n_genes, n_cells) matrix

    # matth: Standardize genes (rows) to have mean 0 and var 1.
    # This ensures that clustering is driven by expression PATTERN (correlation),
    # not magnitude. Ward's method on Z-scored data is equivalent to clustering
    # by Pearson correlation.

    # Calculate means and stds for rows (genes)
    gene_means = sdge.mean(axis=1, keepdims=True)
    gene_stds = sdge.std(axis=1, keepdims=True)

    # Avoid division by zero for constant genes
    gene_stds[gene_stds == 0] = 1.0

    sdge_z = (sdge - gene_means) / gene_stds

    linkage_matrix = hierarchy.ward(sdge_z)
    clusters = hierarchy.fcluster(linkage_matrix, num_clusters, criterion="maxclust")

    # 6. Calculate archetypes (PC1 of Z-scored profiles for each cluster)
    # matth: The "Mean Vector" is a heuristic archetype. The First Principal Component (PC1)
    # provides the mathematically optimal consensus direction (minimizing squared orthogonal distance).
    # This is more robust to variable gene loadings (correlation strengths) within a module.

    archetypes_list = []

    for i in range(1, num_clusters + 1):
        indices = np.where(clusters == i)[0]
        if indices.size == 0:
            # Should not happen with valid clustering, but handle gracefully
            archetypes_list.append(np.zeros(sdge_z.shape[1], dtype=sdge_z.dtype))
            continue

        cluster_data = sdge_z[indices]  # (n_genes_in_cluster, n_cells)

        if cluster_data.shape[0] == 1:
            # Only one gene, archetype is the gene itself (already unit std)
            arch = cluster_data[0]
        else:
            try:
                # SVD of (M, N) matrix X = U S Vt
                # The first right singular vector Vt[0] corresponds to the first Principal Component
                # (eigenvector of X.T @ X) in the cell space, representing the dominant expression pattern.
                _, _, Vt = svd(cluster_data, full_matrices=False, check_finite=False)
                # Vt[0] has unit norm (std 1/sqrt(n_cells)); rescale to unit std so
                # every archetype is on the scale of a Z-scored gene
                arch = Vt[0] * np.sqrt(cluster_data.shape[1])

                # Sign ambiguity: PC1 direction is arbitrary (+v or -v).
                # We align it with the mean vector so that it positively correlates
                # with the majority of the signal (assuming positive correlation cluster).
                mean_vec = np.mean(cluster_data, axis=0)
                # Use dot product to check alignment
                if np.dot(arch, mean_vec) < 0:
                    arch = -arch
            except Exception as e:
                warnings.warn(
                    f"SVD failed for gene cluster {i}: {e}. Falling back to mean archetype."
                )
                arch = np.mean(cluster_data, axis=0)
                arch_std = arch.std()
                if arch_std > 0:
                    arch = arch / arch_std

        archetypes_list.append(arch)

    archetypes = np.array(archetypes_list)

    # 7. Calculate Pearson correlations for each gene to its archetype
    # Optimized to use vectorized operations and avoid repeated allocations/computations.

    # We reuse sdge_z which is already Z-scored (mean 0, std 1 over cells).
    # Since sdge_z rows have mean 0, the archetype (mean of sdge_z rows) also has mean 0.
    # Therefore, we can compute correlation as dot(gene, arch) / (norm(gene) * norm(arch)).
    # norm(gene) = sqrt(n_cells) since gene is Z-scored.
    # norm(arch) = sqrt(sum(arch**2)).

    n_cells = sdge.shape[1]

    # 1. Compute dot products between all genes and all archetypes
    # Shape: (n_genes, n_clusters)
    # Using float32 for matrix multiplication to match input precision
    all_dots = np.dot(sdge_z, archetypes.T)

    # 2. Compute norms of archetypes
    # Shape: (n_clusters,)
    arch_sq_sums = np.sum(archetypes**2, axis=1)
    # The denominator for correlation is sqrt(sum(g^2) * sum(a^2))
    # sum(g^2) = n_cells (for Z-scored data)
    # So denom = sqrt(n_cells * sum(a^2))
    arch_norms = np.sqrt(n_cells * arch_sq_sums) + 1e-9

    # 3. Compute all correlations
    # Shape: (n_genes, n_clusters)
    all_corrs = all_dots / arch_norms[None, :]

    # 4. Select the specific correlation for each gene based on its cluster assignment
    # clusters is 1-based index from fcluster
    cluster_indices = clusters - 1
    gene_indices = np.arange(sdge.shape[0])

    # Extract relevant correlation for each gene
    gene_corrs = all_corrs[gene_indices, cluster_indices]
    gene_corrs = np.clip(gene_corrs, -1.0, 1.0).astype(np.float32)

    print("done")

    return {
        "archetypes": archetypes,
        "clusters": clusters,
        "gene_corrs": gene_corrs,
        "gene_list": final_gene_list,
        "linkage_matrix": linkage_matrix,  # <-- ADDED THIS
    }


@contextlib.contextmanager
def _temporary_obs_columns(adata, columns: Dict[str, np.ndarray]):
    """Set ``adata.obs`` columns for the duration of a plot, then restore any
    pre-existing columns of the same name (or remove the temporary ones)."""
    saved = {name: adata.obs[name].copy() for name in columns if name in adata.obs}
    try:
        for name, values in columns.items():
            adata.obs[name] = values
        yield
    finally:
        for name in columns:
            if name in saved:
                adata.obs[name] = saved[name]
            elif name in adata.obs:
                del adata.obs[name]


def plot_archetype_summary(
    adata: sc.AnnData,
    archetype_results: Dict[str, Any],
    archetype_id: int,
    *,
    k: int = 5,
    use_rep: str = "X_umap",
    cmap: Optional[str] = "Purples",
    archetype_cmap: str = "PiYG",
    **kwargs,
) -> None:
    """
    Plots an archetype's score and its top k genes on an embedding.

    Args:
        adata: The annotated data matrix.
        archetype_results: The dictionary output from `find_expression_archetypes`.
        archetype_id: The cluster ID (1-based) of the archetype to plot.
        k: The number of top correlated genes to plot.
        use_rep: The embedding to use (e.g., "X_umap", "X_pca").
        cmap: Colormap to use for the gene expression plots. Defaults to 'Purples'.
        archetype_cmap: Colormap to use for the archetype score plot. Defaults to 'PiYG'.
        **kwargs: Additional arguments passed to `sc.pl.embedding`.
    """
    # Extract results
    try:
        archetypes = archetype_results["archetypes"]
        clusters = archetype_results["clusters"]
        gene_corrs = archetype_results["gene_corrs"]
        gene_list = archetype_results["gene_list"]
    except KeyError:
        raise ValueError("`archetype_results` dictionary is missing required keys.")

    num_clusters = archetypes.shape[0]
    if not (1 <= archetype_id <= num_clusters):
        raise ValueError(f"`archetype_id` must be between 1 and {num_clusters}.")

    # 1. Get the archetype profile to plot
    arch_idx = archetype_id - 1  # Convert to 0-based index
    archetype_profile = archetypes[arch_idx, :]

    # Stored in adata.obs only while plotting (see below)
    profile_name = f"archetype_{archetype_id}_score"

    # 2. Find the top k genes for this archetype
    # Find indices (relative to gene_list) of genes in this cluster
    gene_indices_in_cluster = np.where(clusters == archetype_id)[0]

    if gene_indices_in_cluster.size == 0:
        warnings.warn(
            f"Archetype {archetype_id} has no assigned genes. Cannot plot top genes."
        )
        top_k_genes = []
    else:
        # Get their correlations
        corrs_in_cluster = gene_corrs[gene_indices_in_cluster]

        # Get the top k indices (relative to `gene_indices_in_cluster`)
        # Use min(k, ...) in case cluster has fewer than k genes
        num_top_genes = min(k, gene_indices_in_cluster.size)
        top_k_local_idx = np.argsort(corrs_in_cluster)[-num_top_genes:][::-1]

        # Get the original gene indices (relative to `gene_list`)
        top_k_global_idx = gene_indices_in_cluster[top_k_local_idx]

        # Get the gene names
        top_k_genes = [gene_list[i] for i in top_k_global_idx]

    # 3. Plotting
    basis = use_rep.replace("X_", "")  # sc.pl.embedding wants 'umap', not 'X_umap'

    print(f"Plotting Archetype {archetype_id} Score")
    with _temporary_obs_columns(adata, {profile_name: archetype_profile}):
        sc.pl.embedding(
            adata,
            basis=basis,
            color=profile_name,
            title=f"Archetype {archetype_id} Score",
            cmap=archetype_cmap,
            **kwargs,
        )

    if top_k_genes:
        print(f"Plotting Top {len(top_k_genes)} Genes for Archetype {archetype_id}")
        sc.pl.embedding(
            adata,
            basis=basis,
            color=top_k_genes,
            # title=f'Top {len(top_k_genes)} Genes for Archetype {archetype_id}',
            cmap=cmap,
            **kwargs,
        )


def plot_archetype_assignments(
    adata: sc.AnnData,
    archetype_results: Dict[str, Any],
    *,
    use_rep: str = "X_umap",
    **kwargs,
) -> None:
    """
    Plots each archetype's score on its own subplot on an embedding.

    This helps visualize the "spatial" or "latent space" distribution
    of all archetypes simultaneously.

    Args:
        adata: The annotated data matrix.
        archetype_results: The dictionary output from `find_expression_archetypes`.
        use_rep: The embedding to use (e.g., "X_umap", "X_pca").
        **kwargs: Additional arguments passed to `sc.pl.embedding`.
    """
    archetypes = archetype_results["archetypes"]  # (n_clusters, n_cells)
    num_clusters = archetypes.shape[0]

    # Each archetype score is stored in adata.obs only while plotting
    profiles = {f"archetype_{i + 1}_score": archetypes[i, :] for i in range(num_clusters)}
    obs_names = list(profiles)

    basis = use_rep.replace("X_", "")

    print(f"Plotting {num_clusters} Archetype Scores per Cell")

    # Set a default `cmap` if not provided, as it looks better for continuous values
    if "cmap" not in kwargs:
        kwargs["cmap"] = "viridis"

    # Plotting all archetypes as subplots
    with _temporary_obs_columns(adata, profiles):
        sc.pl.embedding(
            adata,
            basis=basis,
            color=obs_names,  # Pass the list of names
            title="Archetype Scores per Cell",  # Title will be adapted by scanpy
            **kwargs,
        )


def plot_archetype_hierarchy(
    archetype_results: Dict[str, Any],
    *,
    p: int = 0,
    truncate_mode: Optional[str] = None,
    **kwargs,
) -> plt.Figure:
    """
    Plots the dendrogram of the gene clustering hierarchy.

    Returns the figure (it is not shown or closed here; call `plt.show()` in scripts).

    Args:
        archetype_results: The dictionary output from `find_expression_archetypes`.
        p: Number of clusters to show in truncated mode.
           If 0, defaults to `num_clusters`.
        truncate_mode: 'lastp' (show p last merged clusters), 'level', etc.
                       If None, defaults to 'lastp'.
        **kwargs: Additional arguments passed to `plt.figure` or `hierarchy.dendrogram`.
    """
    try:
        Z = archetype_results["linkage_matrix"]
        gene_list = archetype_results["gene_list"]
        num_clusters = archetype_results["archetypes"].shape[0]
    except KeyError:
        raise ValueError(
            "`archetype_results` dictionary is missing required keys: "
            "'linkage_matrix', 'gene_list', 'archetypes'."
        )

    # --- Smart Defaults ---
    # If p is not set, set it to num_clusters.
    if p == 0:
        p = num_clusters
    # If truncate_mode is not set, set it to 'lastp'
    if truncate_mode is None:
        truncate_mode = "lastp"

    fig, ax = plt.subplots(figsize=kwargs.pop("figsize", (12, 6)))
    ax.set_title("Gene Clustering Hierarchy (Dendrogram)")
    ax.set_ylabel("Distance (Ward)")

    # --- Set color threshold ---
    # We set the threshold to color the `num_clusters`
    color_threshold = 0
    if num_clusters > 1 and num_clusters <= Z.shape[0]:
        # We find the distance of the merge that creates `num_clusters-1` clusters
        # and the merge that creates `num_clusters` clusters, and average them.
        # Z[-(k), 2] is the distance of the merge that results in k clusters.
        try:
            dist_k = Z[-(num_clusters), 2]
            dist_k_minus_1 = Z[-(num_clusters - 1), 2]
            color_threshold = (dist_k + dist_k_minus_1) / 2.0
        except IndexError:
            # This can happen if num_clusters is very close to n_genes
            warnings.warn("Could not determine optimal color threshold. Using default.")
            color_threshold = 0

    # Set gene labels
    labels = np.asarray(gene_list)

    hierarchy.dendrogram(
        Z,
        labels=labels,
        truncate_mode=truncate_mode,
        p=p,
        leaf_rotation=90.0,
        leaf_font_size=8.0,
        color_threshold=color_threshold,
        above_threshold_color="grey",  # Color for links above the threshold
        ax=ax,
        **kwargs,
    )

    if truncate_mode == "lastp":
        ax.set_xlabel(f"Genes / Gene Clusters (showing last {p} merged clusters)")
    else:
        ax.set_xlabel("Genes")

    fig.tight_layout()
    return fig


# ------------------------- Triku Tools -------------------------


def run_triku(
    adata,
    layer: Optional[str] = "log1p",  # <- run Triku on log1p by default
    use_raw: bool = False,
    n_features: int = 2000,
    n_neighbors: Optional[int] = None,
    n_pcs_for_knn: int = 30,
    max_genes_for_triku: int = 20000,
) -> pd.DataFrame:
    """
    Run Triku in-place and return a tidy DataFrame with scores.

    To avoid memory issues or warnings with large gene sets, this function:
      1. Creates a temporary subset of genes (filtering < 3 cells and keeping top
         `max_genes_for_triku` by total counts).
      2. Runs Triku on this subset (using a copy to protect the original adata).
      3. Maps the results back to `adata.var` (setting unselected genes to False/NaN).
    """
    if n_neighbors is None:
        n_neighbors = pacmap_heuristic_n_neighbors(adata.n_obs)
    tk = _import_triku()
    if tk is None:
        raise ImportError(
            "The 'triku' package is required for this function. Please install it."
        )

    # --- 1. Identify genes to process (Heuristic Filtering) ---

    # Calculate basic QC metrics if not present (to filter min_cells and sort by counts)
    # We do this manually to avoid modifying adata.var with sc.pp.calculate_qc_metrics
    if sp.issparse(adata.X):
        n_cells_per_gene = adata.X.getnnz(axis=0)
        total_counts_per_gene = np.asarray(adata.X.sum(axis=0)).ravel()
    else:
        n_cells_per_gene = np.count_nonzero(adata.X, axis=0)
        total_counts_per_gene = np.asarray(adata.X.sum(axis=0)).ravel()

    # Step A: Filter genes with < 3 cells (temporary)
    keep_mask = n_cells_per_gene >= 3

    # Step B: If still too many genes, keep top `max_genes_for_triku` by total counts
    n_remaining = np.sum(keep_mask)
    if n_remaining > max_genes_for_triku:
        print(
            f"Filtering genes for Triku: reducing from {n_remaining} to {max_genes_for_triku} by total counts."
        )
        # Get indices of genes that passed the first mask
        valid_indices = np.where(keep_mask)[0]
        # Get their counts
        valid_counts = total_counts_per_gene[valid_indices]
        # Sort indices by count descending
        sorted_local_indices = np.argsort(valid_counts)[::-1]
        # Keep top N
        top_local_indices = sorted_local_indices[:max_genes_for_triku]
        # Map back to global indices
        final_indices = valid_indices[top_local_indices]

        # Create final mask
        final_mask = np.zeros(adata.n_vars, dtype=bool)
        final_mask[final_indices] = True
        keep_mask = final_mask

    # --- 2. Create Temporary Adata for Triku ---

    # We create a copy of the subset to ensure Triku runs in isolation
    # (protecting original adata from inplace changes like PCA/Neighbors/filtering)
    adata_triku = adata[:, keep_mask].copy()

    # If a layer is specified (recommended: "log1p"), set it as active for selection/knn
    if layer is not None:
        if layer not in adata_triku.layers:
            # If layer is missing in copy, check original.
            # Note: slicing adata[:, mask] should preserve layers.
            raise KeyError(
                f"Requested layer '{layer}' not found. Build it before Triku."
            )
        adata_triku.X = adata_triku.layers[layer].copy()

    # Note: Triku works with both raw counts and log-transformed data.
    # We pass the data as-is from the specified layer.
    # If the user passed a log-transformed layer (e.g. 'log1p'), we use it directly.
    # If the user passed 'scvi_normalized' (floats), we use it directly.
    # We do NOT apply log1p here to avoid double-logging.

    # KNN graph for Triku on the current X (log1p); use PCA for stability/speed
    # This avoids the earlier "X_pca doesn't exist" issue.
    # Note: We run this on the *subset* (adata_triku), which is faster.
    sc.tl.pca(
        adata_triku,
        n_comps=min(50, adata_triku.n_vars - 1, adata_triku.n_obs - 1),
        random_state=0,
    )
    # Drop any graph inherited from `adata` (built on another representation, k, or
    # on more cells before slicing) so Triku sees the graph requested here.
    for graph_key in ("connectivities", "distances"):
        adata_triku.obsp.pop(graph_key, None)
    adata_triku.uns.pop("neighbors", None)
    ensure_neighbors(
        adata_triku,
        n_neighbors=n_neighbors,
        use_rep=None,
        n_pcs=min(n_pcs_for_knn, adata_triku.obsm["X_pca"].shape[1]),
    )

    # Run Triku on the subset
    with warnings.catch_warnings():
        tk.tl.triku(
            adata_triku,
            n_features=n_features,
            use_raw=use_raw,
        )

    # --- 3. Map Results Back to Original Adata ---

    # Initialize columns in original adata
    adata.var["triku_highly_variable"] = False
    adata.var["triku_distance"] = (
        np.nan
    )  # Or 0.0, but NaN distinguishes "not calculated" from "low score"

    # Map values from the subset back to the original using index (gene names)
    # adata_triku.var contains the results. We align by index.

    # Update boolean mask
    # We can rely on pandas index alignment
    adata.var.update(adata_triku.var[["triku_highly_variable"]])
    # Note: update works in place. "triku_highly_variable" in adata_triku is likely boolean.
    # We should ensure the column in adata is boolean (though NaNs might force object/float if not careful, but update handles overlap)
    # Actually, pandas update doesn't add new rows, it updates existing.

    # For safe updates:
    # 1. Extract the series
    hv_series = adata_triku.var["triku_highly_variable"]
    dist_series = adata_triku.var["triku_distance"]

    # 2. Assign to original adata at the specific gene locations
    # Using .loc to align by gene name
    adata.var.loc[hv_series.index, "triku_highly_variable"] = hv_series
    adata.var.loc[dist_series.index, "triku_distance"] = dist_series

    # Ensure boolean type for highly_variable (NaNs might have cast it to object/float if alignment failed, but we initialized with False)
    adata.var["triku_highly_variable"] = adata.var["triku_highly_variable"].astype(bool)

    # Construct the return DataFrame
    # Returning the subset of results (sorted) is usually most useful
    out = adata.var.loc[
        adata_triku.var_names, ["triku_highly_variable", "triku_distance"]
    ].copy()
    out.index.name = "gene"
    out.sort_values("triku_distance", ascending=False, inplace=True)

    return out


def triku_gene_set(adata, min_score: Optional[float] = None) -> set:
    """
    Return set of genes kept by Triku, optionally thresholded by triku_distance.
    """
    if "triku_highly_variable" not in adata.var or "triku_distance" not in adata.var:
        raise RuntimeError("Run `run_triku` first.")
    mask = adata.var["triku_highly_variable"].astype(bool)
    if min_score is not None:
        mask &= adata.var["triku_distance"] >= float(min_score)
    return set(adata.var_names[mask])


def filter_marker_dict_by_triku(
    adata,
    marker_dict: Dict[str, Iterable[str]],
    min_score: Optional[float] = None,
) -> Dict[str, List[str]]:
    """
    Keep only genes selected by Triku (case-insensitive against adata.var_names).
    Kept genes are returned with their adata.var_names spelling; a single gene may be
    given as a string.
    """
    keep = triku_gene_set(adata, min_score=min_score)
    # exact names win over case-insensitive matches
    canonical = {g.lower(): g for g in keep}
    canonical.update({g: g for g in keep})
    out = {}
    for t, genes in marker_dict.items():
        if isinstance(genes, str):
            genes = [genes]
        kept = []
        for g in genes:
            name = canonical.get(g, canonical.get(g.lower()))
            if name is not None:
                kept.append(name)
        out[t] = kept
    return out


# ------------------------- PaCMAP Tools -------------------------


def save_pacmap_model(model: Any, filepath: str) -> None:
    """
    Saves a fitted PaCMAP model to disk using joblib.
    """
    try:
        import joblib
    except ImportError:
        raise ImportError(
            "joblib is required to save models. Install it via `pip install joblib`."
        )

    joblib.dump(model, filepath)
    print(f"PaCMAP model saved to {filepath}")


def load_pacmap_model(filepath: str) -> Any:
    """
    Loads a saved PaCMAP model from disk using joblib.
    """
    try:
        import joblib
    except ImportError:
        raise ImportError(
            "joblib is required to load models. Install it via `pip install joblib`."
        )

    model = joblib.load(filepath)
    print(f"PaCMAP model loaded from {filepath}")
    return model


def tl_pacmap(
    adata: sc.AnnData,
    n_neighbors: Optional[int] = None,
    MN_ratio: float = 0.5,
    FP_ratio: float = 2.0,
    n_components: int = 2,
    use_rep: str = "X_pca",
    random_state: int = 42,
    init: Optional[Union[str, np.ndarray]] = None,
    **kwargs,
) -> None:
    """
    Compute PaCMAP embedding.

    Parameters
    ----------
    adata
        Annotated data matrix.
    n_neighbors
        Number of neighbors for PaCMAP. If None, PaCMAP's size heuristic is used
        (`pacmap_heuristic_n_neighbors`: 10 up to 10,000 cells, then 10 + 15*(log10(n) - 4)).
    MN_ratio
        Ratio of mid-near pairs to near pairs.
    FP_ratio
        Ratio of far pairs to near pairs.
    n_components
        The dimension of the embedding.
    use_rep
        Representation to use for computing the embedding.
        Default is 'X_pca'. If 'X_pca' is not present, it will fall back to .X.
    random_state
        Random seed for reproducibility.
    init
        How to initialize the embedding. Options are:
        - None (default): use 'pca' (PaCMAP's own default) and emit a warning that
          names the choice and the alternatives. With `distance='precomputed'` in
          `kwargs`, PaCMAP cannot do PCA, so 'random' is used instead. Pass `init`
          explicitly to silence the warning.
        - 'pca': the first `n_components` principal components of `use_rep`
          (PaCMAP normalises the input and scales the PCA coordinates by 0.01).
          Deterministic for a given `random_state`, and it starts the optimisation
          from the coarse global layout of the data, whatever its dimensionality.
        - 'paga': positions from `scanpy.pl.paga` (computed here if `sc.tl.paga` was run
          but PAGA was not plotted yet). Suits data with trajectories or many clusters,
          where PAGA's coarse graph is a better global layout than the first PCs.
          If the PAGA graph has no edges between groups (fully disconnected
          clusters), positions are undefined and the default initialisation is
          used, with a warning.
        - 'random': isotropic Gaussian noise (scale 1e-4). The global layout then
          comes from the optimisation alone; useful to check that the structure
          does not depend on the initialisation.
        - An `obsm` key (e.g., 'X_umap'), to start from (and stay close to) an
          existing layout. Columns are truncated or padded to `n_components`, and
          PaCMAP standardises each axis. If the key equals `use_rep`, 'pca' is used
          instead (with a warning), which keeps the relative variance of the axes.
        - A numpy array of initial embedding positions.
    **kwargs
        Additional arguments passed to pacmap.PaCMAP.

    Returns
    -------
    None
        Updates adata.obsm['X_pacmap'] with the embedding.
    """
    try:
        import pacmap
    except ImportError:
        raise ImportError(
            "PaCMAP is not installed. Please install it using: `uv pip install pacmap`"
        )

    # 1. Print Parameters
    print("Computing PaCMAP with parameters:")
    if n_neighbors is None:
        computed_n_neighbors = pacmap_heuristic_n_neighbors(adata.n_obs)
        print(f"  n_neighbors: {n_neighbors} (heuristic: {computed_n_neighbors})")
    else:
        print(f"  n_neighbors: {n_neighbors}")
    print(f"  MN_ratio: {MN_ratio}")
    print(f"  FP_ratio: {FP_ratio}")
    print(f"  n_components: {n_components}")
    print(f"  use_rep: {use_rep}")
    print(f"  random_state: {random_state}")
    if kwargs:
        print(f"  kwargs: {kwargs}")

    # 2. Extract Data
    if use_rep in adata.obsm:
        X_in = adata.obsm[use_rep]
        print(f"Using representation '{use_rep}' from adata.obsm.")
    elif use_rep == "X":
        X_in = adata.X
        print("Using adata.X directly.")
    else:
        warnings.warn(
            f"Representation '{use_rep}' not found in adata.obsm. Falling back to adata.X."
        )
        X_in = adata.X

    # PaCMAP's numba kernels need a dense numpy array
    if sp.issparse(X_in):
        print("Input is sparse, converting to dense array for PaCMAP...")
        X_in = X_in.toarray()

    # 3. Initialize and Fit
    # Filter out None values from kwargs to let defaults shine
    pmap_kwargs = {k: v for k, v in kwargs.items() if v is not None}

    # Extract 'init' if passed in kwargs for backwards compatibility
    if init is None:
        init = pmap_kwargs.pop("init", None)
    elif "init" in pmap_kwargs:
        del pmap_kwargs["init"]

    # PaCMAP's constructor default is a fixed 10, so pass the heuristic explicitly
    pmap_kwargs["n_neighbors"] = (
        n_neighbors if n_neighbors is not None else computed_n_neighbors
    )

    embedder = pacmap.PaCMAP(
        n_components=n_components,
        MN_ratio=MN_ratio,
        FP_ratio=FP_ratio,
        random_state=random_state,
        **pmap_kwargs,
    )

    paga_unusable = False
    if isinstance(init, str) and init == "paga":
        if "paga" not in adata.uns:
            raise ValueError("init='paga' needs `sc.tl.paga(adata, ...)` to be run first.")
        paga = adata.uns["paga"]
        if "pos" not in paga and sp.csr_matrix(paga["connectivities"]).count_nonzero() == 0:
            # Fully disconnected groups: PAGA positions are undefined, and scanpy's
            # layout (via igraph) fails on a graph without edges
            warnings.warn(
                "init='paga': the PAGA graph has no edges between groups (the groups are "
                "disconnected in the neighbour graph), so PAGA positions are undefined. "
                "Using the default initialisation instead."
            )
            init = None
            paga_unusable = True

    # Determine initialization method
    init_method = None
    if init is not None:
        if isinstance(init, str) and init == "paga":
            from scanpy.tools._utils import get_init_pos_from_paga

            if "pos" not in adata.uns["paga"]:
                # The node positions are only computed by plotting PAGA
                fig, ax = plt.subplots()
                sc.pl.paga(adata, ax=ax, show=False, random_state=random_state)
                plt.close(fig)
            init_coords = get_init_pos_from_paga(adata, random_state=random_state)
            init_method = init_coords
        elif (
            isinstance(init, str)
            and init == use_rep
            and use_rep in adata.obsm
            and pmap_kwargs.get("distance") != "precomputed"
        ):
            # Initialising from the input itself: PaCMAP standardises an array
            # init per axis, which would give PC2 the same spread as PC1. Its own
            # 'pca' init keeps the relative variances, and on PC scores (e.g.
            # X_pca) it returns the leading columns unchanged, so this is not a
            # second PCA on top of the first.
            warnings.warn(
                f"tl_pacmap: init='{init}' is the same representation as use_rep, so "
                "init='pca' is used instead: on PC scores it gives the same leading "
                "axes, keeping their relative variance (an array init would be "
                "standardised per axis by PaCMAP); on other representations it uses "
                f"their leading principal components rather than the first "
                f"{n_components} raw columns.",
                UserWarning,
                stacklevel=2,
            )
            init_method = "pca"
        elif isinstance(init, str) and init in adata.obsm:
            init_coords = adata.obsm[init]
            init_method = init_coords
        elif isinstance(init, np.ndarray):
            init_method = init
        elif isinstance(init, str) and init in ["pca", "random"]:
            init_method = init
        else:
            raise ValueError(
                f"Unknown initialization method or key not in adata.obsm: {init}"
            )

        if isinstance(init_method, np.ndarray):
            # Ensure shape matches (n_samples, n_components)
            if init_method.shape[1] < n_components:
                # Pad with small random noise or zeros to reach n_components
                padding = np.random.default_rng(random_state).normal(
                    scale=1e-4,
                    size=(init_method.shape[0], n_components - init_method.shape[1]),
                )
                init_method = np.hstack([init_method, padding])
            elif init_method.shape[1] > n_components:
                init_method = init_method[:, :n_components]
    else:
        # Default: PaCMAP's own PCA initialisation, which is deterministic and
        # starts from the data's coarse global layout. It works for any feature
        # count (<= 100 features: a PCA fit on the normalised input; > 100: the
        # leading components of PaCMAP's TruncatedSVD preprocessing). On PC scores
        # such as X_pca, PaCMAP's global rescaling and PCA return the first
        # n_components columns unchanged (up to sign), so there is no PCA on PCA.
        if pmap_kwargs.get("distance") == "precomputed":
            init_method = "random"
            reason = "distance='precomputed' has no feature space to run PCA on"
        else:
            init_method = "pca"
            reason = (
                "PaCMAP's own default: deterministic for a given random_state and it "
                "starts from the coarse global layout of the data"
            )
        hints = [
            "init='paga' when cells form trajectories or many clusters "
            + (
                "(PAGA results are already in adata.uns)"
                if "paga" in adata.uns
                else "(run sc.tl.paga first)"
            ),
            "init='<obsm key>' (e.g. 'X_umap') to stay close to an existing layout",
            "init='random' to check that the structure does not depend on the initialisation",
        ]
        if init_method == "random":
            hints = [h for h in hints if not h.startswith("init='random'")]
        if paga_unusable:
            hints = [h for h in hints if not h.startswith("init='paga'")]
        warnings.warn(
            f"tl_pacmap: init not given, using init='{init_method}' ({reason}). "
            "Alternatives that may suit your data better: "
            + "; ".join(hints)
            + ". Pass init explicitly to silence this warning.",
            UserWarning,
            stacklevel=2,
        )

    if isinstance(init_method, np.ndarray):
        print(
            f"Fitting PaCMAP using user-provided {init_method.shape} array for init..."
        )
    else:
        print(f"Fitting PaCMAP using init='{init_method}'...")

    X_embedded = embedder.fit_transform(X_in, init=init_method)

    # 4. Store Result
    key_added = "X_pacmap"
    if n_components >= 3:
        key_added = f"X_pacmap_{n_components}"

    adata.obsm[key_added] = X_embedded
    print(f"PaCMAP embedding finished. Result stored in `adata.obsm['{key_added}']`.")


# ------------------------- Lineage -------------------------


def calculate_lineage_coupling(
    adata, label_key="cell_type", clone_key="CloneID", method="hypergeometric", n_permutations=1000
):
    """
    Calculates lineage coupling statistics.

    Parameters
    ----------
    adata : AnnData
        Annotated data matrix.
    label_key : str
        Key in `adata.obs` representing the cell type or cluster labels.
    clone_key : str
        Key in `adata.obs` representing the clonal identities.
    method : str
        Method to calculate expectations and p-values. Either 'hypergeometric' (default, analytical, fast)
        or 'permutation' (stochastic, slow).
    n_permutations : int
        Number of permutations to use if method='permutation'.

    Notes
    -----
    The 'hypergeometric' variance treats clones as independent and ignores the
    negative covariance between clones that compete for the same fixed pool of
    cells. Its z-scores are therefore smaller than the permutation z-scores
    (most visibly on the diagonal) and its p-values are conservative. Use
    'permutation' when calibrated p-values matter.

    Returns
    -------
    observed_counts : pd.DataFrame
        Observed co-occurrence matrix.
    z_scores : pd.DataFrame
        Z-scores of co-occurrence.
    p_values : pd.DataFrame
        Right-tailed P-values of co-occurrence.
    """
    # 1. Prepare Data
    # Create a binary matrix: Clones (rows) x Cell Types (columns)
    # Value is 1 if the clone exists in that cell type, 0 otherwise.
    df = adata.obs[[label_key, clone_key]].dropna()
    # Efficient way to create the binary matrix
    # Group by clone and get unique labels, then get dummies
    # Pivot: Index=Clone_ID, Columns=Cell_Type, Values=1 (if present)
    binary_matrix = pd.crosstab(df[clone_key], df[label_key]).clip(upper=1)
    
    # 2. Calculate Observed Intersections
    # Matrix Multiplication: (Types x Clones) @ (Clones x Types) = (Types x Types)
    # The result [i, j] is the number of clones shared between Type i and Type j
    observed_counts = binary_matrix.T @ binary_matrix

    if method == "permutation":
        null_matrices = []

        # We shuffle the labels array to break the link between clone and cell type.
        # Keep the original label values (not str): the shuffled crosstab columns must
        # match binary_matrix.columns, or every null matrix is all zeros.
        labels_array = np.array(df[label_key].to_numpy(dtype=object))

        print(f"Running {n_permutations} permutations...")
        for _ in range(n_permutations):
            np.random.shuffle(labels_array)
            shuffled_df = pd.DataFrame(
                {clone_key: df[clone_key].values, label_key: labels_array}
            )
            shuffled_binary = pd.crosstab(
                shuffled_df[clone_key], shuffled_df[label_key]
            ).clip(upper=1)
            shuffled_binary = shuffled_binary.reindex(
                columns=binary_matrix.columns, fill_value=0
            )
            null_matrices.append((shuffled_binary.T @ shuffled_binary).values)

        null_matrices = np.array(null_matrices)  # Shape: (n_perms, n_types, n_types)

        null_mean = null_matrices.mean(axis=0)
        null_std = null_matrices.std(axis=0)
        null_std[null_std == 0] = 1.0

        z_scores_vals = (observed_counts.values - null_mean) / null_std
        # +1 correction (Phipson & Smyth 2010): a permutation p-value is never exactly 0
        p_values_vals = (
            (null_matrices >= observed_counts.values).sum(axis=0) + 1
        ) / (n_permutations + 1)

        z_scores = pd.DataFrame(z_scores_vals, index=observed_counts.index, columns=observed_counts.columns)
        p_values = pd.DataFrame(p_values_vals, index=observed_counts.index, columns=observed_counts.columns)

        return observed_counts, z_scores, p_values

    elif method == "hypergeometric":
        import scipy.special
        from scipy.stats import norm
        N = len(df)

        # Get exact cell counts per clone and per type. The per-clone probabilities
        # depend only on the clone size, so they are computed once per distinct size
        # and weighted by how many clones have that size.
        cell_counts_per_clone = df[clone_key].value_counts().values
        clone_sizes, clones_per_size = np.unique(cell_counts_per_clone, return_counts=True)
        cell_counts_per_type = df[label_key].value_counts().loc[binary_matrix.columns].values

        n_types = len(cell_counts_per_type)

        K_i = cell_counts_per_type[:, None]
        k_c = clone_sizes[None, :]

        def prob_zero(K, k_c):
            """
            Probability that a clone with k_c cells has 0 cells of a type with K total cells.
            Computed efficiently via log-gamma formulation of the hypergeometric distribution.
            """
            K, k_c = np.broadcast_arrays(K, k_c)
            valid = (N - K) >= k_c
            p = np.zeros_like(K, dtype=float)

            K_val = K[valid]
            k_c_val = k_c[valid]

            log_p = (scipy.special.gammaln(N - K_val + 1) - scipy.special.gammaln(N - K_val - k_c_val + 1)
                     - scipy.special.gammaln(N + 1) + scipy.special.gammaln(N - k_c_val + 1))
            p[valid] = np.exp(log_p)
            return p

        # P_i: Probability that type i is absent from clone c
        P_i = prob_zero(K_i, k_c)

        # P_ij: Probability that both type i and type j are absent from clone c
        K_ij = cell_counts_per_type[:, None, None] + cell_counts_per_type[None, :, None]
        P_ij = prob_zero(K_ij, k_c[None, :, :])

        # Inclusion-exclusion: Probability that BOTH type i and type j are present in clone c
        # P(i AND j) = 1 - P(not i) - P(not j) + P(not i AND not j)
        p_c_ij = 1.0 - P_i[:, None, :] - P_i[None, :, :] + P_ij

        # For diagonal elements (i=j), the probability is just 1 - P(not i)
        diag_idx = np.arange(n_types)
        p_c_ij[diag_idx, diag_idx, :] = 1.0 - P_i

        # Analytical Expectations and Variance
        expected_counts = np.sum(p_c_ij * clones_per_size, axis=-1)

        var_counts = np.sum(p_c_ij * (1.0 - p_c_ij) * clones_per_size, axis=-1)
        var_counts = np.maximum(var_counts, 0) # Clamp for numerical stability

        std_counts = np.sqrt(var_counts)
        std_counts[std_counts == 0] = 1.0 # Avoid division by zero

        # 4. Calculate Statistics
        z_scores_vals = (observed_counts.values - expected_counts) / std_counts

        # Calculate analytical P-values (Right-tailed test for enrichment)
        p_values_vals = norm.sf(z_scores_vals)

        # Format to DataFrames
        z_scores = pd.DataFrame(
            z_scores_vals, index=observed_counts.index, columns=observed_counts.columns
        )
        p_values = pd.DataFrame(
            p_values_vals, index=observed_counts.index, columns=observed_counts.columns
        )

        return observed_counts, z_scores, p_values
    else:
        raise ValueError(f"Unknown method '{method}'. Choose 'hypergeometric' or 'permutation'.")


def plot_coupling_heatmap(observed, z_scores, p_values, title="Lineage Coupling"):
    """
    Plots the lower-triangular clustermap matching the provided image style.
    """
    import seaborn as sns
    from matplotlib.patches import Rectangle
    from matplotlib.lines import Line2D

    # 1. Setup Mask for Upper Triangle
    mask = np.triu(np.ones_like(z_scores, dtype=bool), k=1)

    # 2. Setup Figure
    plt.figure(figsize=(10, 8))

    # 3. Plot Heatmap (Z-scores)
    # Using 'vlag' or 'RdBu_r' to match the Blue-White-Red scheme
    # vmin/vmax set to -10/10 to match the scale in your image
    ax = sns.heatmap(
        z_scores,
        mask=mask,
        cmap="RdBu_r",
        center=0,
        vmin=-5,
        vmax=5,
        square=True,
        cbar_kws={"label": "Z-score", "shrink": 0.5},
        linewidths=1,
        linecolor="white",  # Optional grid lines
    )

    # 4. Overlay Numbers (Observed Counts)
    # We iterate manually to place text only where unmasked
    for i in range(observed.shape[0]):
        for j in range(observed.shape[1]):
            if i >= j:  # Lower triangle including diagonal
                count = observed.iloc[i, j]
                # Choose text color based on background intensity (simple heuristic)
                z_val = z_scores.iloc[i, j]
                text_color = "white" if abs(z_val) > 5 else "black"

                ax.text(
                    j + 0.5,
                    i + 0.5,
                    f"{int(count)}",
                    ha="center",
                    va="center",
                    color=text_color,
                    fontsize=12,
                )

    # 5. Add Significance Borders
    # Loop again to add rectangles
    # Note: Rectangle(xy, width, height). xy is (col_idx, row_idx) -> (j, i)
    # Adjustment: The border needs to be inset slightly to look like the image
    for i in range(observed.shape[0]):
        for j in range(observed.shape[1]):
            if i >= j:
                p_val = p_values.iloc[i, j]

                if p_val <= 0.001:
                    # Black Border (High Significance)
                    rect = Rectangle(
                        (j + 0.05, i + 0.05),
                        0.9,
                        0.9,
                        fill=False,
                        edgecolor="black",
                        lw=2.5,
                    )
                    ax.add_patch(rect)
                elif p_val <= 0.01:
                    # Orange Border (Medium Significance)
                    rect = Rectangle(
                        (j + 0.05, i + 0.05),
                        0.9,
                        0.9,
                        fill=False,
                        edgecolor="orange",
                        lw=2.5,
                    )
                    ax.add_patch(rect)

    # 6. Formatting
    plt.title(title)
    plt.xticks(rotation=45, ha="right")
    plt.yticks(rotation=0)

    # Custom Legend for P-values
    legend_elements = [
        Line2D([0], [0], color="orange", lw=2.5, label="p ≤ 0.01"),
        Line2D([0], [0], color="black", lw=2.5, label="p ≤ 0.001"),
    ]
    # Add legend outside the plot
    plt.legend(handles=legend_elements, loc="upper left", bbox_to_anchor=(1.2, 1))

    return plt.gcf()


# ------------------------- Multiscale Coarsening -------------------------


def _to_h5ad_safe(obj):
    """Recursively convert `obj` into types AnnData can write to `.uns`."""
    if isinstance(obj, dict):
        return {
            ("->".join(map(str, k)) if isinstance(k, tuple) else str(k)): _to_h5ad_safe(v)
            for k, v in obj.items()
        }
    if isinstance(obj, pd.Series):
        return obj.astype(str).to_numpy()
    if isinstance(obj, pd.DataFrame):
        out = obj.copy()
        out.columns = out.columns.map(str)
        out.index = out.index.map(str)
        for col in out.columns:
            if out[col].dtype == object:
                out[col] = out[col].astype(str)
        return out
    if isinstance(obj, (list, tuple)):
        return np.asarray(obj)
    return obj


def multiscale_coarsening(
    adata: sc.AnnData,
    resolutions: Optional[List[float]] = None,
    use_rep: str = "X_pca",
    store_in_uns: bool = False,
    uns_key: str = "multiscale_hierarchy",
    return_output: bool = True,
    random_state: int = 0,
) -> Optional[Dict[str, Any]]:
    """
    Perform multiscale Leiden clustering and establish a hierarchy between resolutions.

    Clusters the data at multiple resolutions (independent Leiden runs) and links clusters
    across scales based on overlap (majority vote). Also calculates centroids and checks for
    lineage inconsistencies.

    Args:
        adata: Annotated data matrix.
        resolutions: List of resolutions for Leiden clustering.
                     Defaults to [0.5, 1.0, 10.0, 100.0].
        use_rep: Representation to use for clustering and centroid calculation (e.g., 'X_pca').
                 If 'X', uses adata.X.
        store_in_uns: Whether to store the results in `adata.uns[uns_key]`. The stored copy is
                      converted so `write_h5ad` can save it: dict keys become strings
                      (resolution pairs as "fine->coarse") and label Series become string arrays.
        uns_key: Key under which to store results in `adata.uns`.
        return_output: Whether to return the results dictionary.
        random_state: Random seed for Leiden clustering.

    Returns:
        A dictionary containing:
        - 'clustering': Dict of {resolution: pandas.Series of cluster labels}.
        - 'centroids': Dict of {resolution: pandas.DataFrame of centroids}.
        - 'hierarchy': Dict containing:
            - 'tree': Mapping of {(fine_res, coarse_res): {fine_cluster: coarse_cluster}}.
            - 'purity': Mapping of {(fine_res, coarse_res): {fine_cluster: purity_score}}.
              Purity is the fraction of cells in the fine cluster that belong to the assigned coarse cluster.
        - 'consistency': DataFrame flagging clusters with lineage inconsistencies (direct vs indirect parent mismatch).
    """

    # 1. Validation & Setup
    if resolutions is None:
        resolutions = [0.5, 1.0, 10.0, 100.0]

    # Sort resolutions: Low (coarse) -> High (fine)
    resolutions = sorted(list(set(resolutions)))

    if use_rep != "X" and use_rep not in adata.obsm:
        warnings.warn(
            f"Representation '{use_rep}' not found in adata.obsm. Using 'X' (data matrix)."
        )
        use_rep = "X"

    # Leiden runs on a graph built from `use_rep`. The default graph is reused when it
    # was built from the same representation (scanpy records use_rep=None for X_pca);
    # otherwise a dedicated graph is built under 'multiscale_neighbors'.
    neighbors_key = None
    if "connectivities" not in adata.obsp:
        print("Computing neighbors for Leiden clustering...")
        sc.pp.neighbors(adata, use_rep=use_rep)
    else:
        graph_rep = adata.uns.get("neighbors", {}).get("params", {}).get("use_rep")
        if (graph_rep or "X_pca") != use_rep:
            warnings.warn(
                f"adata.obsp['connectivities'] was built from '{graph_rep or 'X_pca'}', not "
                f"'{use_rep}'; clustering on a graph built from '{use_rep}' "
                "(stored as 'multiscale_neighbors')."
            )
            neighbors_key = "multiscale_neighbors"
            sc.pp.neighbors(adata, use_rep=use_rep, key_added=neighbors_key)

    # 2. Run Clustering
    clustering_results = {}
    obs_keys = []

    print(f"Running multiscale clustering on resolutions: {resolutions}")
    for res in resolutions:
        key = f"leiden_res_{res}"
        sc.tl.leiden(adata, resolution=res, key_added=key, random_state=random_state, flavor='igraph', n_iterations=2, directed=False, neighbors_key=neighbors_key)
        clustering_results[res] = adata.obs[key].copy()
        obs_keys.append(key)

    # 3. Calculate Centroids
    centroids = {}

    # Get the data matrix for centroids
    if use_rep == "X":
        if sp.issparse(adata.X):
            data_matrix = adata.X.toarray()
        else:
            data_matrix = adata.X
    else:
        data_matrix = adata.obsm[use_rep]

    for res in resolutions:
        clusters = clustering_results[res]
        unique_clusters = (
            clusters.unique().sort_values()
        )  # Categories are usually strings '0', '1'...

        # We need to ensure we iterate in a stable order corresponding to the cluster labels
        # Leiden labels are categorical strings.

        res_centroids = []
        for cluster_id in unique_clusters:
            mask = (clusters == cluster_id).to_numpy()
            if mask.any():
                centroid = data_matrix[mask].mean(axis=0)
                res_centroids.append(centroid)
            else:
                # Should not happen for existing clusters
                res_centroids.append(np.zeros(data_matrix.shape[1]))

        # Store as DataFrame for better labeling, or just array?
        # Array is cleaner for pure math, but DataFrame keeps indices.
        # Let's return a DataFrame indexed by cluster ID.
        centroids[res] = pd.DataFrame(
            np.array(res_centroids),
            index=unique_clusters,
            columns=[f"dim_{i}" for i in range(data_matrix.shape[1])],
        )

    # 4. Build Hierarchy & Linkage (All-to-All)
    hierarchy_tree = {}
    purity_scores = {}

    # Compare every fine resolution to every coarser resolution
    for i, res_fine in enumerate(resolutions):
        for j in range(i):  # 0 to i-1 are coarser
            res_coarse = resolutions[j]

            fine_labels = clustering_results[res_fine]
            coarse_labels = clustering_results[res_coarse]

            # Confusion Matrix: Rows = Fine, Cols = Coarse
            confusion = pd.crosstab(fine_labels, coarse_labels)

            # For each fine cluster, find the coarse cluster with max overlap
            mapping = {}
            purity = {}

            for f_clust in confusion.index:
                # Row for this fine cluster
                counts = confusion.loc[f_clust]
                if counts.sum() == 0:
                    continue

                # Dominant parent
                best_parent = counts.idxmax()
                max_count = counts.max()
                total_count = counts.sum()

                mapping[f_clust] = best_parent
                purity[f_clust] = max_count / total_count

            hierarchy_tree[(res_fine, res_coarse)] = mapping
            purity_scores[(res_fine, res_coarse)] = purity

    # 5. Consistency Check (Lineage Analysis)
    # We check triplets: Fine -> Mid -> Coarse
    # Direct: Fine -> Coarse (mapped directly)
    # Indirect: Fine -> Mid (mapped) -> Coarse (mapped)

    inconsistencies = []

    for i in range(2, len(resolutions)):
        res_fine = resolutions[i]
        for j in range(1, i):
            res_mid = resolutions[j]
            for k in range(j):
                res_coarse = resolutions[k]

                # Maps
                map_fine_mid = hierarchy_tree.get((res_fine, res_mid), {})
                map_mid_coarse = hierarchy_tree.get((res_mid, res_coarse), {})
                map_fine_coarse_direct = hierarchy_tree.get((res_fine, res_coarse), {})

                for f_clust, mid_parent in map_fine_mid.items():
                    # Indirect path
                    if mid_parent in map_mid_coarse:
                        indirect_grandparent = map_mid_coarse[mid_parent]
                    else:
                        continue  # Should not happen if maps are complete

                    # Direct path
                    direct_grandparent = map_fine_coarse_direct.get(f_clust)

                    if direct_grandparent != indirect_grandparent:
                        inconsistencies.append(
                            {
                                "fine_res": res_fine,
                                "mid_res": res_mid,
                                "coarse_res": res_coarse,
                                "fine_cluster": f_clust,
                                "mid_parent": mid_parent,
                                "direct_grandparent": direct_grandparent,
                                "indirect_grandparent": indirect_grandparent,
                                "purity_fine_mid": purity_scores[
                                    (res_fine, res_mid)
                                ].get(f_clust, 0),
                                "purity_mid_coarse": purity_scores[
                                    (res_mid, res_coarse)
                                ].get(mid_parent, 0),
                                "purity_fine_coarse": purity_scores[
                                    (res_fine, res_coarse)
                                ].get(f_clust, 0),
                            }
                        )

    consistency_df = pd.DataFrame(inconsistencies)

    results = {
        "clustering": clustering_results,
        "centroids": centroids,
        "hierarchy": {"tree": hierarchy_tree, "purity": purity_scores},
        "consistency": consistency_df,
        "resolutions": resolutions,
    }

    if store_in_uns:
        adata.uns[uns_key] = _to_h5ad_safe(results)

    if return_output:
        return results
    return None


# ------------------------- Cell Type Annotation -------------------------


def _normalize_symbol(s: str) -> str:
    """Robust normalization for matching gene symbols."""
    return str(s).strip().upper().replace("_", "-")


def _dedupe_preserve_order(seq: Iterable) -> List:
    """Deduplicate sequence while preserving original order."""
    seen = set()
    out = []
    for x in seq:
        if x not in seen:
            out.append(x)
            seen.add(x)
    return out


def _build_norm_map(
    adata: sc.AnnData, extra_cols: Optional[List[str]] = None
) -> Dict[str, str]:
    """
    Build a mapping from normalized symbol -> actual var_name in `adata`.
    Includes var_names and (if present) selected alternate symbol columns.
    """
    if extra_cols is None:
        extra_cols = [
            "gene_symbol",
            "gene_symbols",
            "gene_name",
            "Gene",
            "Symbol",
            "feature_name",
            "features",
            "name",
        ]
    norm_map = {}

    # 1) alternate columns (row-aligned); the first row with a symbol wins
    for col in extra_cols:
        if col in adata.var.columns:
            col_series = adata.var[col]
            # tolerate non-string / NaN
            for idx, val in col_series.items():
                if val is None:
                    continue
                sval = str(val).strip()
                if sval == "" or sval.lower() == "nan":
                    continue
                norm_map.setdefault(
                    _normalize_symbol(sval), str(idx)
                )  # idx is var_name for that row

    # 2) var_names / index, last so an exact var_name always maps to itself
    for var_name in adata.var_names:
        norm_map[_normalize_symbol(var_name)] = var_name

    return norm_map


def filter_markers_to_adata(
    marker_genes: Dict[str, List[str]],
    adata: sc.AnnData,
    extra_cols: Optional[List[str]] = None,
    verbose: bool = True,
) -> Tuple[Dict[str, List[str]], Dict[str, List[str]], Dict[str, Dict[str, str]]]:
    """
    Filter marker genes to those present in `adata`.

    Parameters
    ----------
    marker_genes
        Dictionary of {cell_type: [gene_list]}.
    adata
        Annotated data matrix.
    extra_cols
        List of column names in `adata.var` to check for alternative gene symbols.
    verbose
        Whether to print a summary of removed/replaced markers.

    Returns
    -------
    cleaned
        Filtered marker dictionary with valid gene names.
    removed
        Dictionary of {cell_type: [removed_genes]}.
    replacements
        Dictionary of {cell_type: {original_gene: matched_var_name}}.
    """
    norm_map = _build_norm_map(adata, extra_cols=extra_cols)

    cleaned = {}
    removed = defaultdict(list)
    replacements = defaultdict(dict)  # original -> matched var_name (if case/alias fix)

    for tissue, genes in marker_genes.items():
        keep = []
        for g in genes:
            key = _normalize_symbol(g)
            hit = norm_map.get(key, None)
            if hit is not None:
                keep.append(hit)
                if hit != g:
                    replacements[tissue][g] = hit
            else:
                removed[tissue].append(g)

        cleaned[tissue] = _dedupe_preserve_order(keep)

    # prune empties from reporting dicts
    removed = {k: v for k, v in removed.items() if len(v) > 0}
    replacements = {k: v for k, v in replacements.items() if len(v) > 0}

    if verbose:
        total_removed = sum(len(v) for v in removed.values())
        print(
            f"[marker filter] {total_removed} markers removed across {len(removed)} categories."
        )
        if replacements:
            print(
                "[marker filter] Case/alias replacements (original -> adata var_name):"
            )
            for k, m in replacements.items():
                print(f"  - {k}: {m}")
        if removed:
            print("[marker filter] Removed (not found in adata):")
            for k, lost in removed.items():
                print(f"  - {k} ({len(lost)}): {lost}")

    return cleaned, removed, replacements


def filter_markers_by_moran(
    filtered: Dict[str, List[str]],
    df_top_dict: pd.DataFrame,
    *,
    gene_col: str = "gene",
    score_col: str = "I",
    threshold: float = 0.10,
    top_k: int = 5,
    min_k: int = 3,
    fallback_to_min_k: bool = True,
    case_insensitive: bool = True,
    verbose: bool = True,
) -> Tuple[Dict[str, List[str]], Dict[str, Any]]:
    """
    From `filtered` (category -> [genes]) keep only genes found in `df_top_dict`
    with Moran's I >= `threshold`, then return top_k by Moran's I (desc).
    If fewer than `min_k` pass the threshold and `fallback_to_min_k` is True,
    backfill with the best-scoring genes (even if below threshold) until min_k.

    A gene's score is taken from its exact (case-sensitive) row in `df_top_dict` when
    one exists; with `case_insensitive=True` case variants are used only otherwise.

    Returns
    -------
    filtered_by_moran : dict
        {category: [genes]}
    report : dict
        Per-category details: missing_in_df, below_threshold, used_fallback
    """

    # Build score lookup
    # If the DF has duplicates, keep the maximum score per gene.
    df = df_top_dict[[gene_col, score_col]].copy()

    # normalize gene key
    def norm(x):
        return str(x).upper() if case_insensitive else str(x)

    df["_key"] = df[gene_col].map(norm)
    # best score per gene
    ranked = df.sort_values(score_col, ascending=False)
    best = ranked.drop_duplicates("_key")
    score_map = dict(zip(best["_key"], best[score_col]))
    # also map canonical name to return (use the 'gene' from DF if case differs)
    canon_map = dict(zip(best["_key"], best[gene_col]))
    # an exact (case-sensitive) name wins over its case variants
    exact = ranked.assign(_exact=ranked[gene_col].map(str)).drop_duplicates("_exact")
    exact_score_map = dict(zip(exact["_exact"], exact[score_col]))

    filtered_by_moran = {}
    report = {}

    for cat, genes in filtered.items():
        # normalize and gather scores
        present = []
        missing_in_df = []
        for g in genes:
            key = norm(g)
            if str(g) in exact_score_map and pd.notna(exact_score_map[str(g)]):
                present.append((g, float(exact_score_map[str(g)])))
            elif key in score_map and pd.notna(score_map[key]):
                # keep original symbol from filtered if it matches canon ignoring case,
                # otherwise use DF's canon (helps unify case/alias differences)
                out_name = g if norm(g) == norm(canon_map[key]) else canon_map[key]
                present.append((out_name, float(score_map[key])))
            else:
                missing_in_df.append(g)

        # sort by Moran's I desc
        present.sort(key=lambda x: (x[1], x[0]), reverse=True)

        # apply threshold
        above = [(g, s) for (g, s) in present if s >= threshold]
        below = [(g, s) for (g, s) in present if s < threshold]

        picked = above[:top_k]
        used_fallback = False
        if len(picked) < min_k and fallback_to_min_k:
            need = min_k - len(picked)
            # take the next best to reach min_k: remaining above-threshold genes
            # (when top_k < min_k) before any below-threshold gene; avoid duplicates
            for g, s in above[top_k:] + below:
                if g not in [x[0] for x in picked]:
                    picked.append((g, s))
                    need -= 1
                    if need == 0:
                        break
            used_fallback = any(s < threshold for _, s in picked)

        # store only gene names
        filtered_by_moran[cat] = [g for g, _ in picked]

        report[cat] = {
            "n_input": len(genes),
            "n_present_in_df": len(present),
            "n_above_threshold": len(above),
            "missing_in_df": missing_in_df,
            "below_threshold": [g for g, _ in below],
            "used_fallback": used_fallback,
        }

    if verbose:
        total_missing = sum(len(r["missing_in_df"]) for r in report.values())
        total_below = sum(len(r["below_threshold"]) for r in report.values())
        print(f"[moran filter] threshold={threshold}, top_k={top_k}, min_k={min_k}")
        print(
            f"[moran filter] Missing in df_top_dict: {total_missing} genes across categories."
        )
        print(f"[moran filter] Below threshold: {total_below} genes across categories.")
        fb_cats = [k for k, r in report.items() if r["used_fallback"]]
        if fb_cats:
            print(f"[moran filter] Fallback to min_k used for: {fb_cats}")

    return filtered_by_moran, report


# ------------------------- Annotation Core -------------------------


def score_celltypes(
    adata: sc.AnnData,
    cell_type_markers_dict: Dict[str, Sequence[str]],
    cell_type_negative_markers_dict: Optional[Dict[str, Sequence[str]]] = None,
    layer: Optional[str] = None,
    use_raw: bool = True,
    min_markers: int = 1,
    score_method: Literal[
        "scanpy",
        "binned",
        "binned_weighted",
        "net_scanpy",
        "net_binned",
        "net_binned_weighted",
    ] = "scanpy",
) -> pd.DataFrame:
    """
    Compute per-cell scores for each cell type.

    score_method options:
      - "scanpy": Uses `sc.tl.score_genes` and robustly standardizes scores (Median/MAD).
      - "binned": Converts gene expression to "Low" (0), "Mid" (0.5), "High" (1.0) using
        median of non-zero values, then averages across markers. Normalization is skipped.
      - "binned_weighted": Same as "binned", but multiplies the average by the fraction
        of markers detected (>0) per cell.
      - "net_scanpy", "net_binned", "net_binned_weighted": Same as above, but subtracts
        the score of negative markers if `cell_type_negative_markers_dict` is provided.

    Supports negative selection:
      - Computes positive and negative scores per cell type.
      - If a "net_" method is selected, returns Net Score = pos - neg.
      - Otherwise, returns the positive score only.

    Notes:
      - If fewer than `min_markers` genes are present, that cell type's score is NaN.
      - Expression source: `layer` if given, else `adata.raw` if `use_raw` and it exists,
        else `adata.X`. All score methods and the marker presence check use the same source.
      - Side effect: `adata.uns['marker_missing_report']` is a DataFrame with one row per
        cell type and marker set ('pos'/'neg'): `cell_type`, `marker_set`, and the
        comma-joined `missing_genes`. Rows from earlier calls are kept and updated.
    """

    # A layer takes precedence over raw (as scanpy's use_raw=None does), and
    # use_raw is ignored when there is no adata.raw.
    use_raw = bool(use_raw) and adata.raw is not None and layer is None

    # Determine gene universe for presence/missing checks
    if use_raw:
        gene_universe = set(map(str, adata.raw.var_names))
    else:
        gene_universe = set(map(str, adata.var_names))

    missing_report = {}
    tmp_cols = []

    # --- 1. Batch Gene Sets ---

    # We want to uniquely identify sets of genes to avoid redundant score_genes calls
    # for identical gene sets used in different cell types.
    unique_pos_sets = {}  # hash -> list of present genes
    unique_neg_sets = {}  # hash -> list of present genes

    ct_to_pos_hash = {}
    ct_to_neg_hash = {}

    for ct, markers in cell_type_markers_dict.items():
        markers = [str(g) for g in markers]
        present = [g for g in markers if g in gene_universe]
        missing = [g for g in markers if g not in gene_universe]
        missing_report[(str(ct), "pos")] = missing

        if len(present) < min_markers:
            ct_to_pos_hash[ct] = None
        else:
            genes_tuple = tuple(sorted(present))
            h = hash(genes_tuple)
            unique_pos_sets[h] = present
            ct_to_pos_hash[ct] = h

        if cell_type_negative_markers_dict and ct in cell_type_negative_markers_dict:
            neg_markers = [str(g) for g in cell_type_negative_markers_dict[ct]]
            neg_present = [g for g in neg_markers if g in gene_universe]
            neg_missing = [g for g in neg_markers if g not in gene_universe]
            missing_report[(str(ct), "neg")] = neg_missing

            if len(neg_present) > 0:
                neg_tuple = tuple(sorted(neg_present))
                neg_h = hash(neg_tuple)
                unique_neg_sets[neg_h] = neg_present
                ct_to_neg_hash[ct] = neg_h
            else:
                ct_to_neg_hash[ct] = None
        else:
            ct_to_neg_hash[ct] = None

    # --- 2. Compute Raw Scores ---

    raw_pos_scores = {}  # hash -> numpy array of scores
    raw_neg_scores = {}  # hash -> numpy array of scores

    def _compute_binned_scores(genes: List[str]) -> np.ndarray:
        if not genes:
            return np.zeros(adata.n_obs, dtype=float)

        binned_matrix = np.zeros((adata.n_obs, len(genes)), dtype=float)
        detected_mask = np.zeros((adata.n_obs, len(genes)), dtype=bool)

        # One slice for all marker genes (slicing a CSR matrix per gene is ~90x slower)
        expr = _extract_gene_matrix(
            adata, genes, source="raw" if use_raw else layer if layer else "X"
        )
        for i in range(len(genes)):
            x = expr[:, i]
            # Find non-zero values
            nz_mask = x > 0
            if not np.any(nz_mask):
                continue

            nz_vals = x[nz_mask]
            med = np.median(nz_vals)

            # Map to 0.5 (Mid) and 1.0 (High)
            binned = np.zeros_like(x)
            binned[nz_mask & (x <= med)] = 0.5
            binned[x > med] = 1.0

            binned_matrix[:, i] = binned
            detected_mask[:, i] = nz_mask

        # Average across genes
        avg_scores = binned_matrix.mean(axis=1)

        if score_method in ("binned_weighted", "net_binned_weighted"):
            # Fraction of markers detected
            frac_detected = detected_mask.sum(axis=1) / len(genes)
            return avg_scores * frac_detected

        return avg_scores

    if score_method in (
        "binned",
        "binned_weighted",
        "net_binned",
        "net_binned_weighted",
    ):
        # Binned execution path
        for h, genes in unique_pos_sets.items():
            raw_pos_scores[h] = _compute_binned_scores(genes)

        for h, genes in unique_neg_sets.items():
            raw_neg_scores[h] = _compute_binned_scores(genes)
    else:
        # Scanpy execution path
        for h, genes in unique_pos_sets.items():
            tmp_name = f"__ctscore_pos_{h}_{uuid4().hex[:8]}"
            sc.tl.score_genes(
                adata,
                gene_list=genes,
                score_name=tmp_name,
                use_raw=use_raw,
                layer=layer,
            )
            raw_pos_scores[h] = adata.obs[tmp_name].to_numpy()
            tmp_cols.append(tmp_name)

        for h, genes in unique_neg_sets.items():
            tmp_name = f"__ctscore_neg_{h}_{uuid4().hex[:8]}"
            sc.tl.score_genes(
                adata,
                gene_list=genes,
                score_name=tmp_name,
                use_raw=use_raw,
                layer=layer,
            )
            raw_neg_scores[h] = adata.obs[tmp_name].to_numpy()
            tmp_cols.append(tmp_name)

    # --- 3. Robust Independent Standardization & Integration ---

    final_scores = {}

    def robust_scale(x):
        return robust_standardize(x)

    for ct in cell_type_markers_dict.keys():
        pos_h = ct_to_pos_hash[ct]
        if pos_h is None:
            final_scores[ct] = np.full(adata.n_obs, np.nan, dtype=float)
            continue

        x_pos = raw_pos_scores[pos_h]

        if score_method in ("scanpy", "net_scanpy"):
            z_pos = robust_scale(x_pos)
        else:
            z_pos = x_pos  # Already 0 to 1 bounded

        neg_h = ct_to_neg_hash[ct]
        is_net_method = score_method.startswith("net_")

        if is_net_method and neg_h is not None:
            x_neg = raw_neg_scores[neg_h]
            if score_method == "net_scanpy":
                z_neg = robust_scale(x_neg)
                final_scores[ct] = z_pos - z_neg
            else:
                z_neg = x_neg  # Already 0 to 1 bounded
                # For binned methods, bounded between 0 and 1
                final_scores[ct] = np.clip(z_pos - z_neg, 0.0, 1.0)
        else:
            final_scores[ct] = z_pos

    # Assemble result DF and clean up temp columns
    df = pd.DataFrame(final_scores, index=adata.obs_names)
    if tmp_cols:
        adata.obs.drop(
            columns=[c for c in tmp_cols if c in adata.obs.columns],
            inplace=True,
            errors="ignore",
        )

    # Merge missing-gene report into .uns. A table, not a dict keyed by cell type:
    # names such as 'NK/T' are not valid h5ad keys and broke write_h5ad.
    report = pd.DataFrame(
        [
            {"cell_type": ct, "marker_set": kind, "missing_genes": ",".join(genes)}
            for (ct, kind), genes in missing_report.items()
        ],
        columns=["cell_type", "marker_set", "missing_genes"],
    )
    previous = adata.uns.get("marker_missing_report")
    if isinstance(previous, pd.DataFrame) and list(previous.columns) == list(report.columns):
        report = pd.concat([previous, report], ignore_index=True).drop_duplicates(
            subset=["cell_type", "marker_set"], keep="last"
        )
    adata.uns["marker_missing_report"] = report.reset_index(drop=True)

    return df


def annotate_clusters_by_markers(
    adata: sc.AnnData,
    cluster_key: str,
    cell_type_markers_dict: Optional[Dict[str, Sequence[str]]] = None,
    cell_type_negative_markers_dict: Optional[Dict[str, Sequence[str]]] = None,
    layer: Optional[str] = None,
    use_raw: bool = True,
    beta: float = None,  # Deprecated
    min_markers: int = 1,
    normalize_scores: bool = True,
    write_to_obs: bool = True,
    obs_prefix: Optional[str] = None,
    scores: Optional[pd.DataFrame] = None,
    score_method: Literal[
        "scanpy",
        "binned",
        "binned_weighted",
        "net_scanpy",
        "net_binned",
        "net_binned_weighted",
    ] = "scanpy",
) -> pd.DataFrame:
    """
    Annotate clusters based on cell type scores using a probabilistic confidence metric.

    Uses the Probability of Superiority (Common Language Effect Size) to estimate
    the confidence that the top assigned cell type is truly separated from the runner-up,
    accounting for the local variance of scores within the cluster.

    If `scores` is provided, it must be a DataFrame with index == adata.obs_names
    and columns == cell types. Otherwise, scores are computed once here.

    Parameters:
    - normalize_scores: Whether to robustly standardize each cell type's scores across cells
      (only for score_method='scanpy'). Default is True. Uses `stats.robust_standardize`:
      (x - median) / (1.4826 * MAD); where the MAD is 0 it falls back to the mean and
      sqrt(pi/2) * mean absolute deviation, then to the standard deviation; constant
      columns become 0.

    Notes:
        The assigned type is the one with the highest median score in the cluster.
        `softmax_p` (name kept for compatibility) is the empirical Probability of
        Superiority of the top type over the runner-up within the cluster: the fraction
        of cells whose score for the top type exceeds their score for the runner-up, with
        ties counted as 0.5 (the common-language effect size, not a normal approximation).
        It is 1.0 when only one type has a finite score and 0.5 when fewer than two cells
        have finite differences. `uncertainty = 1 - softmax_p * consensus_frac`, where
        `consensus_frac` is the fraction of the cluster's cells whose own best type is the
        assigned type.
    """
    if beta is not None:
        warnings.warn(
            "The `beta` parameter is deprecated and ignored. `annotate_clusters_by_markers` now uses a parameter-free probabilistic confidence score.",
            DeprecationWarning,
            stacklevel=2,
        )

    # Get per-cell scores S only if not provided
    if scores is None:
        if cell_type_markers_dict is None:
            raise ValueError("Provide `cell_type_markers_dict` when `scores` is None.")
        S = score_celltypes(
            adata,
            cell_type_markers_dict,
            cell_type_negative_markers_dict=cell_type_negative_markers_dict,
            layer=layer,
            use_raw=use_raw,
            min_markers=min_markers,
            score_method=score_method,
        )
    else:
        S = scores
        # Align/validate
        if not S.index.equals(adata.obs_names):
            S = S.reindex(adata.obs_names)

    if normalize_scores and score_method == "scanpy":
        if scores is not None:
            warnings.warn(
                "Scores provided and normalize_scores=True. This may result in double normalization."
            )
        # NORMALIZE SCORES (Robust Median/MAD)
        # Bolt optimization: Vectorized across columns instead of Pandas .apply
        arr = S.to_numpy()
        S = pd.DataFrame(
            robust_standardize(arr, axis=0), index=S.index, columns=S.columns
        )

    cts = list(S.columns)
    clabs = adata.obs[cluster_key].astype(str)

    # Compute per-cluster medians for all cell types in one shot
    med_by_cluster = S.groupby(clabs).median()  # rows=clusters, cols=cell types

    # Per-cell best type once (used for consensus_frac)
    arr = S.to_numpy()
    all_nan = np.all(np.isnan(arr), axis=1)
    # nanargmax fails on all-NaN rows, so safe compute:
    argmax = np.zeros(arr.shape[0], dtype=int)
    argmax[~all_nan] = np.nanargmax(arr[~all_nan], axis=1)
    argmax[all_nan] = -1
    cell_best = np.array([cts[j] if j >= 0 else None for j in argmax], dtype=object)

    rows = []
    per_cluster_label, per_cluster_softmaxp, per_cluster_unc = {}, {}, {}

    for g, med in med_by_cluster.iterrows():
        order = med.sort_values(ascending=False)

        if order.size == 0 or np.all(~np.isfinite(order.values)):
            top1_ct, top1, top2 = None, np.nan, np.nan
            margin = np.nan
            consensus_frac = np.nan
            softmax_p = np.nan
            uncertainty = np.nan
        else:
            top1_ct = order.index[0]
            top1 = order.iloc[0]
            top2 = order.iloc[1] if order.size > 1 else np.nan

            # matth: Calculate separation metrics using local distribution
            mask = (clabs == g).values
            winners = cell_best[mask]

            # consensus among cell-wise winners within the cluster
            consensus_frac = np.mean(winners == top1_ct) if winners.size else np.nan

            if (
                top1_ct is not None
                and top2 is not None
                and np.isfinite(top2)
                and np.isfinite(top1)
            ):
                # We have at least two valid candidates to compare

                # Extract scores for this cluster
                # We use the S dataframe (which might be normalized or raw, doesn't matter for t-stat logic as long as linear)
                cluster_scores = S.loc[mask]

                s1 = cluster_scores[top1_ct].values
                # Use the name of the second best median
                top2_ct = order.index[1]
                s2 = cluster_scores[top2_ct].values

                # Pairwise difference per cell (handles correlation)
                # s1 and s2 are aligned (same cells)
                diff = s1 - s2

                # Remove NaNs if any (score_genes shouldn't produce mixed NaNs usually, but safe to check)
                valid_diff = diff[np.isfinite(diff)]

                if valid_diff.size > 1:
                    # matth: Robust Probability of Superiority (Empirical)
                    # Instead of assuming normality (P = Phi(mu/std)), we compute the
                    # fraction of cells where Top1 > Top2 directly. This is robust to outliers
                    # and multimodal distributions (e.g. doublets) which would otherwise skew the mean.
                    # This is the non-parametric estimator of P(X > Y).

                    # Count ties as 0.5 (standard practice for CLES / Mann-Whitney)
                    n_total = valid_diff.size
                    n_pos = np.sum(valid_diff > 0)
                    n_ties = np.sum(valid_diff == 0)

                    softmax_p = (n_pos + 0.5 * n_ties) / n_total
                else:
                    softmax_p = 0.5  # Not enough data

                margin = top1 - top2
            else:
                # Only one valid type or no valid comparison
                margin = np.nan
                if top1_ct is not None and np.isfinite(top1):
                    softmax_p = 1.0  # Only one candidate
                else:
                    softmax_p = np.nan

            # Uncertainty combines ambiguity (softmax_p) and heterogeneity (consensus_frac)
            # softmax_p here is "Confidence of Superiority"
            uncertainty = (
                1.0 - (softmax_p * consensus_frac)
                if (np.isfinite(softmax_p) and np.isfinite(consensus_frac))
                else np.nan
            )

        rows.append(
            {
                "cluster": g,
                "assigned_cell_type": top1_ct,
                "top1_score": top1,
                "top2_score": top2,
                "margin": margin,
                "consensus_frac": consensus_frac,
                "softmax_p": softmax_p,  # Kept name for compatibility, but represents P(Superiority)
                "uncertainty": uncertainty,
                **{f"median_{ct}": med.get(ct, np.nan) for ct in cts},
            }
        )
        per_cluster_label[g] = top1_ct
        per_cluster_softmaxp[g] = softmax_p
        per_cluster_unc[g] = uncertainty

    cluster_df = pd.DataFrame(rows).set_index("cluster").sort_index()

    if write_to_obs:
        prefix = obs_prefix or cluster_key
        adata.obs[f"{prefix}_cell_type"] = clabs.map(per_cluster_label).astype(
            "category"
        )
        adata.obs[f"{prefix}_ctype_softmaxp"] = clabs.map(per_cluster_softmaxp).astype(
            float
        )
        adata.obs[f"{prefix}_ctype_uncertainty"] = clabs.map(per_cluster_unc).astype(
            float
        )

    return cluster_df


def sweep_leiden_and_annotate(
    adata: sc.AnnData,
    cell_type_markers_dict: Dict[str, Sequence[str]],
    cell_type_negative_markers_dict: Optional[Dict[str, Sequence[str]]] = None,
    resolutions: Sequence[float] = (0.2, 0.5, 1.0, 2.0, 5.0),
    neighbors_already_computed: bool = True,
    random_state: int = 0,
    layer: Optional[str] = None,
    use_raw: bool = True,
    normalize_scores: bool = True,
    min_markers: int = 1,
    beta: float = None,  # Deprecated
    leiden_key_prefix: str = "leiden",
    score_method: Literal[
        "scanpy",
        "binned",
        "binned_weighted",
        "net_scanpy",
        "net_binned",
        "net_binned_weighted",
    ] = "scanpy",
) -> Dict[str, Any]:
    """
    For a fixed graph (recommended), run Leiden at multiple `resolutions`,
    annotate clusters at each resolution, and compute agreement between
    per-cell assigned cell types across adjacent resolutions.

    Scores are computed ONCE and reused across all resolutions.
    """
    if not neighbors_already_computed and "connectivities" not in adata.obsp:
        raise ValueError(
            "Please compute neighbors once (sc.pp.neighbors) before sweeping or ensure they exist."
        )

    # --- compute once ---
    S = score_celltypes(
        adata,
        cell_type_markers_dict,
        cell_type_negative_markers_dict=cell_type_negative_markers_dict,
        layer=layer,
        use_raw=use_raw,
        min_markers=min_markers,
        score_method=score_method,
    )

    if normalize_scores and score_method == "scanpy":
        # Bolt optimization: Vectorized across columns instead of Pandas .apply
        arr = S.to_numpy()
        S = pd.DataFrame(
            robust_standardize(arr, axis=0), index=S.index, columns=S.columns
        )

    res_list = [float(r) for r in resolutions]
    cluster_annotations = {}
    celltype_labels = {}

    # One decimal for resolutions that have one (leiden_0.5, leiden_1.0); full
    # precision otherwise, so 0.96 and 1.04 do not share a 'leiden_1.0' column.
    def _res_key(r):
        return f"{leiden_key_prefix}_{r:.1f}" if round(r, 1) == r else f"{leiden_key_prefix}_{r!r}"

    res_keys = [_res_key(r) for r in res_list]
    if len(set(res_keys)) != len(res_keys):
        raise ValueError(f"Duplicate resolutions in {list(resolutions)}.")

    for r, key in zip(res_list, res_keys):
        # We check if leiden key exists or compute it if missing?
        # The user snippet raised ValueError. I will modify to compute if missing for convenience, or match intent.
        # "sweep_leiden" implies it might run it.
        # The user's snippet raised: "Please compute leiden before sweeping." if key missing.
        # But earlier "multiscale_coarsening" computes it.
        # Let's compute it if missing, as it is helpful.
        if key not in adata.obs:
            print(f"Computing Leiden resolution {r:g}...")
            sc.tl.leiden(adata, resolution=r, key_added=key, random_state=random_state, flavor='igraph', n_iterations=2, directed=False)

        cdf = annotate_clusters_by_markers(
            adata,
            cluster_key=key,
            cell_type_markers_dict=None,  # not needed since we pass scores
            layer=layer,
            use_raw=use_raw,
            normalize_scores=False,  # Already normalized if requested
            min_markers=min_markers,
            beta=beta,
            write_to_obs=True,
            obs_prefix=key,
            scores=S,  # <- reuse
            score_method=score_method,
        )
        cluster_annotations[r] = cdf
        celltype_labels[r] = adata.obs[f"{key}_cell_type"].astype(str).copy()

    # ARI across resolutions for per-cell TYPE labels (not cluster IDs)
    R = np.zeros((len(res_list), len(res_list)))
    for i, ri in enumerate(res_list):
        for j, rj in enumerate(res_list):
            R[i, j] = adjusted_rand_score(celltype_labels[ri], celltype_labels[rj])

    all_pair_ARI = pd.DataFrame(R, index=res_list, columns=res_list)

    # Adjacent pairs
    rows = []
    for i in range(len(res_list) - 1):
        ri, rj = res_list[i], res_list[i + 1]
        ari = adjusted_rand_score(celltype_labels[ri], celltype_labels[rj])
        rows.append({"res_i": ri, "res_j": rj, "ARI": ari})
    adjacent_ARI = pd.DataFrame(rows)

    return {
        "cluster_annotations": cluster_annotations,
        "celltype_labels": celltype_labels,
        "adjacent_ARI": adjacent_ARI,
        "all_pair_ARI": all_pair_ARI,
    }


# ------------------------- Visualization & Export -------------------------


def plot_celltype_ari(all_pair_ARI: pd.DataFrame) -> Tuple[plt.Figure, plt.Axes]:
    """
    Plot ARI heatmap using standard matplotlib.
    """
    fig, ax = plt.subplots(figsize=(6, 5))
    im = ax.imshow(all_pair_ARI, cmap="viridis", vmin=0, vmax=1)

    # We want to show the ticks as the resolutions
    res_labels = [str(r) for r in all_pair_ARI.index]

    ax.set_xticks(np.arange(len(res_labels)))
    ax.set_yticks(np.arange(len(res_labels)))
    ax.set_xticklabels(res_labels)
    ax.set_yticklabels(res_labels)

    ax.set_xlabel("resolution")
    ax.set_ylabel("resolution")
    ax.set_title("ARI of per-cell TYPE labels across resolutions")

    # Add colorbar
    fig.colorbar(im, ax=ax)

    plt.tight_layout()
    return fig, ax


def barplot_cluster_uncertainty(
    cluster_df: pd.DataFrame, top_k: int = 25
) -> Tuple[plt.Figure, plt.Axes]:
    """
    Bar plot of cluster uncertainty.
    """
    df = cluster_df.sort_values("uncertainty").head(top_k)
    fig, ax = plt.subplots(figsize=(7, 3 + 0.25 * len(df)))
    ax.barh(df.index.astype(str), df["uncertainty"], color="#4444aa")
    ax.invert_yaxis()
    ax.set_xlabel("Uncertainty (lower is better)")
    ax.set_ylabel("Cluster")
    ax.set_title("Cluster annotation uncertainty")
    plt.tight_layout()
    return fig, ax


def export_obs_from_adata_to_csv(
    adata: sc.AnnData,
    obs_key: str,
    output_path: Optional[str] = None,
    color_key: Optional[str] = None,
    index_name: str = "Cell_ID"
) -> None:
    """
    Export a single adata.obs column (e.g. cell type annotations) to CSV, optionally including its colors.
    """
    from pathlib import Path

    # 1. Define your column names
    if color_key is None:
        color_key = f"{obs_key}_colors"

    if obs_key not in adata.obs:
         raise ValueError(f"Observation key '{obs_key}' not found in adata.obs")

    # 2. Create a temporary dataframe
    df_export = adata.obs[[obs_key]].copy()

    # 3. Map the colors from adata.uns to the individual cells
    # (Scanpy stores colors in .uns in the same order as the categories)
    if color_key in adata.uns:
        # Create a dictionary: { 'T-cell': '#1f77b4', 'B-cell': '#ff7f0e', ... }
        if hasattr(adata.obs[obs_key], "cat"):
            categories = adata.obs[obs_key].cat.categories
            colors = adata.uns[color_key]
            if len(categories) == len(colors):
                category_map = dict(zip(categories, colors))
                # Map this to a new column in the dataframe
                df_export[color_key] = df_export[obs_key].map(category_map)
            else:
                warnings.warn(f"Number of colors in '{color_key}' does not match categories in '{obs_key}'. Colors not exported.")
        else:
            warnings.warn(f"'{obs_key}' is not categorical. Colors not exported.")
    else:
        warnings.warn(f"'{color_key}' not found in adata.uns. Colors not exported.")

    # 4. Rename the index for clarity
    df_export.index.name = index_name

    # 5. Export to CSV
    if output_path is None:
        out_file = Path(f'{obs_key}_export.csv')
    else:
        out_file = Path(output_path)
        if out_file.is_dir():
            out_file = out_file / f"{obs_key}_export.csv"
        elif out_file.suffix.lower() != ".csv":
            # append, not replace: 'run_2024.10' must not become 'run_2024.csv'
            out_file = out_file.with_name(out_file.name + ".csv")

    print(f"Saving at {out_file.resolve()}")
    df_export.to_csv(out_file)

    # Verify the output
    print(df_export.head())


def plot_volcano_adata(
    adata: sc.AnnData,
    rank_genes_key: str,
    group: str,
    pval_cutoff: float = 0.05,
    logfc_cutoff: Union[float, Tuple[float, float]] = 1.0,
    label_top_n: int = 20,
    plot_positive_only: bool = False,
    figsize: tuple = (6, 5),
    title: str = None,
    ax=None,
    **kwargs,
) -> plt.Axes:
    """
    Generates a volcano plot from differential gene expression results
    stored by scanpy's rank_genes_groups.

    Args:
        adata (AnnData): The annotated data matrix.
        rank_genes_key (str): The key in `adata.uns` where the rank_genes_groups results are stored.
        group (str): The name of the group to plot from the rank_genes_groups results.
        pval_cutoff (float, optional): The adjusted p-value cutoff for significance. Defaults to 0.05.
        logfc_cutoff (Union[float, Tuple[float, float]], optional): The log2 fold change cutoff for significance.
                                     Can be a single value (applied as -val and +val) or a tuple (min_val, max_val). Defaults to 1.0.
        label_top_n (int, optional): The number of top genes to label based on p-value AND log-fold change.
                                     The final number of labels can be up to 2 * label_top_n. Defaults to 20.
        plot_positive_only (bool, optional): If True, highlights and labels only genes with positive
                                             log-fold change (upregulated). If False, highlights
                                             both up- and down-regulated significant genes. Defaults to False.
        figsize (tuple, optional): The size of the figure. Defaults to (6, 5).
        title (str, optional): The title for the plot. If None, a default title is generated. Defaults to None.
        ax (matplotlib.axes.Axes, optional): An existing matplotlib axes object to plot on.
                                             If None, a new figure and axes are created. Defaults to None.
        **kwargs: Additional keyword arguments passed to `adjust_text`.

    Returns:
        matplotlib.axes.Axes: The matplotlib axes object containing the plot.

    Notes:
        This function requires the 'adjustText' library to be installed
        (`pip install adjustText`) for non-overlapping gene labels.
    """
    if adjust_text is None:
        raise ImportError(
            "The 'adjustText' library is required for this function. "
            "Please install it using `pip install adjustText`."
        )

    # Handle group being a list (e.g. ['0']) which can happen if passed from other scanpy tools
    if isinstance(group, (list, tuple)):
        if len(group) == 1:
            group = group[0]
        else:
            raise ValueError(
                f"plot_volcano_adata only supports plotting a single group. "
                f"Got {len(group)} groups: {group}"
            )

    if isinstance(logfc_cutoff, (tuple, list)):
        if len(logfc_cutoff) != 2:
            raise ValueError(
                "logfc_cutoff must be a single value or a tuple of length 2"
            )
        logfc_min, logfc_max = logfc_cutoff
    else:
        logfc_min, logfc_max = -logfc_cutoff, logfc_cutoff

    # --- 1. Data Extraction ---
    try:
        comparison_uns = adata.uns[rank_genes_key]
        logfoldchanges = comparison_uns["logfoldchanges"][group]
        pvals_adj = comparison_uns["pvals_adj"][group]
        names = comparison_uns["names"][group]
    except KeyError:
        print(
            f"Error: Could not find rank_genes_key='{rank_genes_key}' or group='{group}' in adata.uns."
        )
        return

    # --- 2. Data Preparation ---
    # Calculate -log10 of p-values, handling p-values of 0
    with np.errstate(divide="ignore"):
        neg_log10_pvals = -np.log10(pvals_adj)
    # Replace infinite values (p = 0) with a value slightly larger than the max finite
    # value, or with -log10 of the smallest positive float when nothing else is finite
    inf_mask = np.isinf(neg_log10_pvals)
    if inf_mask.any():
        finite = neg_log10_pvals[np.isfinite(neg_log10_pvals)]
        cap = np.max(finite) * 1.1 if finite.size and np.max(finite) > 0 else 0.0
        if cap <= 0:
            cap = -np.log10(np.finfo(float).tiny)
        neg_log10_pvals[inf_mask] = cap

    # --- 3. Plotting ---
    if ax is None:
        fig, ax = plt.subplots(figsize=figsize)

    # Scatter plot for all genes (non-significant)
    ax.scatter(
        logfoldchanges, neg_log10_pvals, c="gray", alpha=0.5, label="Non-significant"
    )

    # --- 4. Highlight Significant Genes ---
    if plot_positive_only:
        significant_idx = (pvals_adj < pval_cutoff) & (logfoldchanges > logfc_max)
    else:
        significant_idx = (pvals_adj < pval_cutoff) & (
            (logfoldchanges < logfc_min) | (logfoldchanges > logfc_max)
        )

    # Scatter plot for significant genes
    ax.scatter(
        logfoldchanges[significant_idx],
        neg_log10_pvals[significant_idx],
        c="red",
        alpha=0.8,
        label="Significant",
    )

    # --- 5. Add Threshold Lines ---
    ax.axhline(-np.log10(pval_cutoff), color="black", linestyle="--", linewidth=0.8)
    ax.axvline(logfc_max, color="black", linestyle="--", linewidth=0.8)
    if not plot_positive_only:
        ax.axvline(logfc_min, color="black", linestyle="--", linewidth=0.8)

    # --- 6. Annotate Top Genes ---
    # Get significant genes' data
    significant_names = names[significant_idx]
    significant_lfc = logfoldchanges[significant_idx]
    significant_pvals = neg_log10_pvals[significant_idx]

    # Get top n by p-value
    top_by_pval_indices = np.argsort(-significant_pvals)[:label_top_n]

    # Get top n by absolute log fold change
    top_by_lfc_indices = np.argsort(-np.abs(significant_lfc))[:label_top_n]

    # Combine indices and remove duplicates
    top_indices = np.union1d(top_by_pval_indices, top_by_lfc_indices)

    # Create text labels, adjusting horizontal alignment based on position
    texts = []
    for i in top_indices:
        ha = "left" if significant_lfc[i] > 0 else "right"
        texts.append(
            ax.text(
                significant_lfc[i],
                significant_pvals[i],
                significant_names[i],
                fontsize=8,
                ha=ha,
            )
        )

    # Use adjust_text to prevent labels from overlapping
    # Default values for adjust_text. adjustText >= 1.0 renamed the parameters, and
    # passes unknown keywords on to the arrows, so pick the names it understands.
    import inspect

    arrowprops = dict(
        arrowstyle="-",
        color="gray",
        lw=0.5,
        alpha=0.8,  # Make arrows slightly transparent
    )
    if "force_static" in inspect.signature(adjust_text).parameters:  # adjustText >= 1.0
        adjust_text_kwargs = dict(
            force_text=(0.1, 0.5),  # stronger vertical push
            force_static=(0.1, 0.2),
            expand=(1.2, 1.6),
            arrowprops=arrowprops,
        )
    else:  # adjustText < 1.0
        adjust_text_kwargs = dict(
            force_text=(0.5, 10.0),  # stonger vertical push
            force_points=(0.2, 0.2),
            expand_text=(1.5, 5.5),
            expand_points=(1.0, 1.0),
            lim=100_000,
            arrowprops=arrowprops,
        )
    # Update with any user-provided kwargs
    adjust_text_kwargs.update(kwargs)

    adjust_text(texts, ax=ax, **adjust_text_kwargs)

    # --- 7. Final Touches ---
    ax.set_xlabel("Log2 Fold Change")
    ax.set_ylabel("-Log10 Adjusted P-value")
    if title is None:
        ax.set_title(f"Volcano Plot: {group} vs. All")
    else:
        ax.set_title(title)
    ax.legend()
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)

    plt.tight_layout()
    return ax


def _kknn_distance_weights(dist: np.ndarray) -> np.ndarray:
    """Normalised inverse-distance weights with a median-distance bandwidth.

    Using the median neighbourhood distance as a bandwidth makes the weighting
    scale-invariant without letting a coincident cell (dist=0) take all the weight.
    """
    epsilon = 1e-6
    median_dist = np.median(dist[dist > 0]) if np.any(dist > 0) else 0.0
    weights = 1.0 / (dist + median_dist + epsilon)
    return weights / np.sum(weights)


def kknn_classifier(
    adata: sc.AnnData,
    obs_key: str,
    use_rep: str = "X_pacmap",
    n_neighbors: Optional[int] = None,
    min_neighbors: Optional[int] = None,
    max_neighbors: Optional[int] = None,
    quantile_bins: int = 10,
    mask: Optional[Union[np.ndarray, pd.Series]] = None,
    inplace: bool = True,
) -> Optional[np.ndarray]:
    """
    Smooth or classify an observation column based on the adaptive k-nearest neighbors (kkNN) backbone.

    This function utilizes the local manifold curvature proxy from `compute_kknn_neighbors`
    to weight and average labels or numeric values from `adata.obs`.

    For categorical (discrete) and boolean observations, it performs a distance-weighted majority vote.
    For continuous (numeric) observations, it performs a distance-weighted average.

    Args:
        adata: The AnnData object.
        obs_key: The column name in `adata.obs` to smooth.
        use_rep: The representation key in `.obsm` to compute neighbors (e.g., 'X_pacmap').
        n_neighbors: The base number of neighbors P.
        min_neighbors: Minimum neighbors to keep.
        max_neighbors: Maximum neighbors to keep.
        quantile_bins: Number of bins to quantize curvature scores.
        mask: Boolean mask indicating which cells to smooth. Only cells where mask is True are
              reclassified, others keep their original values. Must be a boolean array/Series.
        inplace: If True, adds the smoothed values as a new column `{obs_key}_kknn` to `adata.obs`.
                 If False, returns the smoothed values as an array.

    Returns:
        If inplace is False, returns a NumPy array or Pandas Categorical of smoothed values.
    """
    if obs_key not in adata.obs:
        raise KeyError(f"Observation key '{obs_key}' not found in adata.obs")

    # 1. Compute kkNN neighborhoods using the backbone function
    # Passing the same dataset as both query and reference means each cell queries its neighbors
    pruned_distances, pruned_indices = compute_kknn_neighbors(
        adata_query=adata,
        adata_ref=adata,
        use_rep=use_rep,
        query_use_rep=use_rep,
        n_neighbors=n_neighbors,
        min_neighbors=min_neighbors,
        max_neighbors=max_neighbors,
        quantile_bins=quantile_bins,
    )

    labels = adata.obs[obs_key].values
    N = adata.n_obs

    if mask is not None:
        if isinstance(mask, pd.Series):
            mask = mask.values
        if len(mask) != N:
            raise ValueError(
                f"Mask length ({len(mask)}) does not match number of observations ({N})"
            )
        mask = np.asarray(mask, dtype=bool)

    # Booleans are voted on (as labels), not averaged into fractions
    col = adata.obs[obs_key]
    is_bool = pd.api.types.is_bool_dtype(col)
    is_categorical = is_bool or not pd.api.types.is_numeric_dtype(col)

    smoothed = []

    for i in range(N):
        if mask is not None and not mask[i]:
            smoothed.append(labels[i])
            continue

        idx = pruned_indices[i]
        dist = pruned_distances[i]

        neighbors_labels = labels[idx]

        # Distance weighting: smaller distance = larger weight
        weights = _kknn_distance_weights(dist)

        if is_categorical:
            # Tally weighted votes
            vote_tally = {}
            for lbl, w in zip(neighbors_labels, weights):
                # Ignore NaNs
                if pd.isna(lbl):
                    continue
                vote_tally[lbl] = vote_tally.get(lbl, 0.0) + w

            if vote_tally:
                # Find the winner
                winner = max(vote_tally.items(), key=lambda x: x[1])[0]
                smoothed.append(winner)
            else:
                # Failsafe if all neighbors were NaN
                smoothed.append(np.nan)

        else:
            # Continuous: Distance-weighted average
            valid_mask = ~pd.isna(neighbors_labels)
            if np.any(valid_mask):
                valid_labels = neighbors_labels[valid_mask]
                valid_weights = weights[valid_mask]
                # Re-normalize valid weights
                sum_weights = np.sum(valid_weights)
                if sum_weights > 0:
                    valid_weights /= sum_weights
                    val = np.sum(valid_labels * valid_weights)
                    smoothed.append(val)
                else:
                    smoothed.append(np.nan)
            else:
                smoothed.append(np.nan)

    # Cast back to original categorical type if necessary
    if is_bool and not any(pd.isna(v) for v in smoothed):
        smoothed = np.array(smoothed, dtype=bool)
    elif is_categorical:
        if isinstance(adata.obs[obs_key].dtype, pd.CategoricalDtype):
            cat_dtype = adata.obs[obs_key].dtype
            smoothed = pd.Categorical(smoothed, categories=cat_dtype.categories)
        else:
            smoothed = np.array(smoothed, dtype=object)
    else:
        smoothed = np.array(smoothed, dtype=float)

    if inplace:
        adata.obs[f"{obs_key}_kknn"] = smoothed
        return None
    else:
        return smoothed


def _compute_kknn_curvatures(
    X: np.ndarray, indices: np.ndarray, max_neighbors: int, chunk_size: int = 50000
) -> np.ndarray:
    """
    Computes local curvature (Participation Ratio) using exact matrix invariants.
    Dynamically switches between Covariance and Gram matrix formulations to prevent OOM.
    """
    N = indices.shape[0]
    curvatures = np.ones(N)  # Default to 1.0 (min possible PR)

    for i in range(0, N, chunk_size):
        end_i = min(i + chunk_size, N)
        chunk_indices = indices[i:end_i]

        # neigh_data shape: (chunk_size, k, d)
        neigh_data = X[chunk_indices]
        k = neigh_data.shape[1]
        d = neigh_data.shape[2]

        # Mean-center the data per neighborhood
        neigh_mean = neigh_data.mean(axis=1, keepdims=True)
        centered = neigh_data - neigh_mean

        # matth: Compute Participation Ratios directly using exact matrix invariants.

        # OPTIMIZATION 1: Tr(X^T X) == ||X||_F^2.
        # We bypass matrix multiplication entirely for the numerator.
        total_var = np.sum(centered**2, axis=(1, 2))

        # OPTIMIZATION 2: Memory-aware Frobenius norm.
        # X^T X and X X^T share the same non-zero eigenvalues, hence the same squared Frobenius norm.
        if k < d:
            # Compute Gram matrix (chunk_size, k, k) - Cheaper when neighbors < dimensions
            matrices = np.einsum("nij,nlj->nil", centered, centered)
        else:
            # Compute Covariance matrix (chunk_size, d, d) - Cheaper when dimensions < neighbors
            matrices = np.einsum("nij,nil->njl", centered, centered)

        # OPTIMIZATION 3: No scaling factor.
        # The 1/(k-1) factor cancels out in the PR ratio, so we ignore it.
        sq_var = np.sum(matrices**2, axis=(1, 2))

        # Apply PR formula where variance exists to prevent division by zero
        mask = total_var > 0
        curvatures[i:end_i][mask] = (total_var[mask] ** 2) / sq_var[mask]

    return curvatures


def _embedding_fingerprint(X: np.ndarray) -> np.ndarray:
    """Cheap fingerprint (shape and moments of a row subsample) of an embedding."""
    X = np.asarray(X)
    sub = X[:: max(1, X.shape[0] // 512)].astype(np.float64)
    return np.array([X.shape[0], X.shape[1], sub.sum(), np.square(sub).sum()])


def compute_kknn_neighbors(
    adata_query: sc.AnnData,
    adata_ref: sc.AnnData,
    use_rep: str = "X_pca",
    query_use_rep: Optional[str] = None,
    n_neighbors: Optional[int] = None,
    min_neighbors: Optional[int] = None,
    max_neighbors: Optional[int] = None,
    quantile_bins: int = 10,
) -> Tuple[List[np.ndarray], List[np.ndarray]]:
    """
    Compute adaptive k-nearest neighbors (kkNN) for a query dataset against a reference.

    The number of neighbors kept for each query cell scales with the local curvature of the
    reference manifold around the query cell. Flat regions retain more neighbors (up to max_neighbors),
    while highly curved regions retain fewer (down to min_neighbors).

    Args:
        adata_query: The query AnnData object.
        adata_ref: The reference AnnData object.
        use_rep: The representation key in .obsm to use (e.g., 'X_pca').
        n_neighbors: The base number of neighbors P (heuristic used if None).
        min_neighbors: Minimum neighbors to keep (defaults to max(3, P // 2)).
        max_neighbors: Maximum neighbors to keep (defaults to max(10, 2 * P)).
        quantile_bins: Number of bins to quantize curvature scores.

    Returns:
        A tuple of (pruned_distances, pruned_indices) where each element is a list of arrays
        (one array per query cell).
    """
    if query_use_rep is None:
        query_use_rep = use_rep

    if query_use_rep not in adata_query.obsm:
        raise ValueError(f"Query dataset must have '{query_use_rep}' in .obsm.")
    if use_rep not in adata_ref.obsm:
        raise ValueError(f"Reference dataset must have '{use_rep}' in .obsm.")

    X_query = adata_query.obsm[query_use_rep]
    X_ref = adata_ref.obsm[use_rep]

    N_ref = X_ref.shape[0]
    N_query = X_query.shape[0]

    if n_neighbors is None:
        P = pacmap_heuristic_n_neighbors(N_ref)
    else:
        P = n_neighbors

    if min_neighbors is None:
        min_neighbors = max(3, P // 2)
    if max_neighbors is None:
        max_neighbors = max(10, 2 * P)

    # Cannot query more neighbors than there are reference cells; ensure min <= max
    max_neighbors = min(max_neighbors, N_ref)
    min_neighbors = min(min_neighbors, max_neighbors)

    print(
        f"kkNN: Querying up to {max_neighbors} neighbors, pruning down to {min_neighbors} (P={P})..."
    )

    # 1. Fit Nearest Neighbors on Reference
    nn = NearestNeighbors(n_neighbors=max_neighbors, algorithm="auto", n_jobs=-1)
    nn.fit(X_ref)

    # 2. Query neighbors for all query cells
    distances, indices = nn.kneighbors(X_query)

    # 3. Compute reference curvature bounds if not cached.
    # The bounds depend on the embedding and on max_neighbors, so the cache is keyed by
    # both and also stores a fingerprint of the embedding to detect a recomputed one.
    bounds_key = "kknn_curvature_bounds"
    cache_entry = f"{use_rep}|k={max_neighbors}"
    fingerprint = _embedding_fingerprint(X_ref)
    cache = adata_ref.uns.get(bounds_key)
    if not isinstance(cache, dict):
        cache = {}  # absent, or a single (lower, upper) pair from older versions
    cached = cache.get(cache_entry)
    if cached is not None and np.allclose(
        np.asarray(cached)[2:], fingerprint, rtol=1e-9, atol=0
    ):
        lower_bound, upper_bound = (float(b) for b in np.asarray(cached)[:2])
    else:
        print("kkNN: Computing and caching reference curvature bounds...")
        # Get neighbors for the reference dataset itself
        # If the query and reference are identical arrays, reuse the already computed indices
        if X_query is X_ref:
            ref_indices = indices
        else:
            _, ref_indices = nn.kneighbors(X_ref)

        # Compute curvatures for the reference dataset
        ref_curvatures = _compute_kknn_curvatures(X_ref, ref_indices, max_neighbors)

        # Calculate bounds and cache them (not for temporary representations)
        lower_bound = np.percentile(ref_curvatures, 1)
        upper_bound = np.percentile(ref_curvatures, 99)
        if not use_rep.startswith("__temp_"):
            cache[cache_entry] = np.concatenate([[lower_bound, upper_bound], fingerprint])
            adata_ref.uns[bounds_key] = cache

    # 4. Compute local curvature for query cells
    # Note: the query cells use the reference data for neighborhood,
    # but we extracted the neighborhood data correctly because indices point to X_ref
    curvatures = _compute_kknn_curvatures(X_ref, indices, max_neighbors)

    # 5. Robust Normalization and Linear Binning using reference bounds

    # Clip extreme outliers to prevent them from stretching the K space (Winsorization)
    curvatures_clipped = np.clip(curvatures, lower_bound, upper_bound)

    # Now perform absolute scaling on the cleaned data
    ptp = upper_bound - lower_bound
    if ptp == 0:
        K = np.zeros_like(curvatures_clipped)
    else:
        K = (curvatures_clipped - lower_bound) / (ptp + 1e-9)

    # Use linear bins on the outlier-resistant K values
    # Absolute scaling ensures global structural consistency, while the percentile clipping
    # prevents single massive outliers from compressing the valid variance.
    bins = np.linspace(0.0, 1.0, quantile_bins + 1)[1:-1]
    disc_curv = np.digitize(K, bins)  # 0 to quantile_bins-1

    pruned_distances = []
    pruned_indices = []

    for i in range(N_query):
        bin_idx = disc_curv[i]

        # Linear interpolation between max_neighbors and min_neighbors
        # bin_idx = 0 -> keep = max_neighbors
        # bin_idx = quantile_bins - 1 -> keep = min_neighbors
        fraction = bin_idx / max(1, (quantile_bins - 1))
        keep = int(round(max_neighbors - fraction * (max_neighbors - min_neighbors)))

        # Failsafe bounds
        keep = max(min_neighbors, min(max_neighbors, keep))

        pruned_distances.append(distances[i, :keep])
        pruned_indices.append(indices[i, :keep])

    return pruned_distances, pruned_indices


def _project_onto_reference_pca(adata_query, adata_fit) -> np.ndarray:
    """Project ``adata_query.X`` into the PCA space stored on ``adata_fit``.

    ``adata_fit`` is the object the PCA was computed on: its ``.X`` is the fitted
    matrix, with ``varm['PCs']`` and ``uns['pca']['params']``. The query goes
    through the same steps as the reference did:

    1. If the reference was standardised with ``sc.pp.scale`` (``var['mean']`` and
       ``var['std']`` present), the query is standardised with the reference
       statistics, ``(x - mean) / std``, and clipped like the reference
       (``max_value`` clipping is detected from the values tied at the maximum).
    2. If the PCA was zero-centred, the column means of the fitted matrix are
       subtracted. The query's own mean is never used: it depends on the query's
       cell-type composition.
    """
    if not adata_query.var_names.equals(adata_fit.var_names):
        raise ValueError(
            "Variables in the query adata are different from variables in the reference adata."
        )

    pca_params = adata_fit.uns["pca"]["params"]
    mask_key = pca_params.get("mask_var")
    if not isinstance(mask_key, str):
        mask_key = (
            "highly_variable" if pca_params.get("use_highly_variable", False) else None
        )
    if mask_key is not None:
        if mask_key not in adata_fit.var.columns:
            raise ValueError(f"Did not find `adata_ref.var['{mask_key}']`.")
        cols = adata_fit.var[mask_key].to_numpy(dtype=bool)
    else:
        cols = np.ones(adata_fit.n_vars, dtype=bool)

    x = adata_query.X[:, cols]
    # float64 copy: never modifies adata_query.X, and works for integer matrices
    x = x.toarray() if sp.issparse(x) else np.asarray(x)
    x = x.astype(np.float64)
    X_fit = adata_fit.X[:, cols]

    if "std" in adata_fit.var:
        print(
            "kkNN Ingest: Reference features were scaled. Scaling query features with the reference statistics..."
        )
        if "mean" in adata_fit.var:
            x -= adata_fit.var["mean"].to_numpy(dtype=np.float64)[cols]
        std = adata_fit.var["std"].to_numpy(dtype=np.float64)[cols]
        x /= np.where(std == 0, 1.0, std)
        # sc.pp.scale(max_value=m) clips to [-m, m], leaving many entries tied at
        # exactly +-m; unclipped continuous data has no such ties.
        abs_fit = abs(X_fit)
        amax = float(abs_fit.max())
        if amax > 0 and (abs_fit == amax).sum() > 1:
            np.clip(x, -amax, amax, out=x)

    if pca_params.get("zero_center", True):
        x -= np.asarray(X_fit.mean(axis=0), dtype=np.float64).ravel()

    return x @ np.asarray(adata_fit.varm["PCs"])[cols]


def _check_embedding_model(model, key, X_q, X_r, ref_coords, use_rep):
    """Validate that an embedding model can map ``X_q`` into ``adata_ref.obsm[key]``."""
    n_dims = getattr(model, "num_dimensions", None)
    if n_dims is not None and X_q.shape[1] != n_dims:
        raise ValueError(
            f"The embedding model for '{key}' was fit on {n_dims}-dimensional data, but the "
            f"query representation has {X_q.shape[1]} dimensions. The model must be fit on "
            f"adata_ref.obsm['{use_rep}']."
        )
    n_inst = getattr(model, "num_instances", None)
    if n_inst is not None:
        if getattr(model, "tree", None) is None and X_r.shape[0] != n_inst:
            raise ValueError(
                f"The embedding model for '{key}' was fit on {n_inst} cells, but its basis "
                f"adata_ref.obsm['{use_rep}'] has {X_r.shape[0]} rows. Pass the reference the "
                "model was fit on (same cells, same order)."
            )
        if ref_coords.shape[0] != n_inst:
            raise ValueError(
                f"The embedding model for '{key}' was fit on {n_inst} cells, but adata_ref has "
                f"{ref_coords.shape[0]}; its embedding does not correspond to adata_ref.obsm['{key}']."
            )
    embedding = getattr(model, "embedding_", None)
    if embedding is not None and embedding.shape == ref_coords.shape:
        scale = float(np.max(np.abs(ref_coords))) or 1.0
        if not np.allclose(embedding, ref_coords, rtol=1e-4, atol=1e-6 * scale):
            warnings.warn(
                f"adata_ref.obsm['{key}'] differs from the embedding the model for '{key}' "
                "was fit to; mapped query coordinates are in the model's embedding space."
            )


def kknn_ingest(
    adata_query: sc.AnnData,
    adata_ref: sc.AnnData,
    obs_keys: Optional[Union[str, List[str]]] = None,
    obsm_keys: Optional[Union[str, List[str]]] = None,
    use_rep: str = "X_pca",
    n_neighbors: Optional[int] = None,
    barycenter: str = "distance",
    embedding_models: Optional[Dict[str, Any]] = None,
    recompute_ref_PCA: bool = True,
    save_ref_PCA_key: Optional[str] = None,
    lle_reg_lambda: float = 1e-3,
    **kwargs,
) -> None:
    """
    Map annotations and embeddings from a reference to a query dataset
    using an adaptive curvature-based KNN (kkNN) strategy.

    Important: It is expected that the query and reference datasets have already
    been intersected to contain the exact same features. For example:

    ```
    common_genes = adata_reference.var_names.intersection(adata_query.var_names)
    adata_reference = adata_reference[:, common_genes].copy()
    adata_query = adata_query[:, common_genes].copy()
    ```

    To prevent overwriting existing data, all transferred keys will receive a `_kknn` suffix
    in `adata_query` (e.g. `{key}_kknn`, and `mapping_confidence_{key}_kknn`). The function
    also adds a `kknn_k` column to `adata_query.obs`, which stores the number of adapted
    neighbors chosen for each query cell based on local manifold curvature. You can plot this
    column on an embedding to inspect curvature adaptation.

    Categorical, string and boolean obs columns are transferred by weighted vote, with the
    winning weight fraction as `mapping_confidence_{key}_kknn`. Numeric columns are
    transferred as the weighted mean over the neighbourhood, with the weighted standard
    deviation in `mapping_std_{key}_kknn` (their `mapping_confidence_...` column is NaN).

    After ingest, if you wish to concatenate the query and reference datasets, use the
    `anndata.concat()` function (the preferred method over `.concatenate()`):

    ```
    # Option 1: Basic concatenation along observations
    adata_combined = anndata.concat(
        {"reference": adata_ref, "query": adata_query},
        label="dataset"
    )

    # Option 2: Advanced concatenation, joining the .obs to retain non-overlapping metadata
    adata_combined = anndata.concat(
        {"reference": adata_ref, "query": adata_query},
        label="dataset",
        join="outer"
    )
    ```

    Args:
        adata_query: The query dataset.
        adata_ref: The reference dataset.
        obs_keys: Keys in adata_ref.obs to transfer to adata_query.obs.
        obsm_keys: Keys in adata_ref.obsm to transfer to adata_query.obsm.
        use_rep: Shared representation space to find neighbors (default: 'X_pca').
        n_neighbors: Base number of neighbors to use (overrides heuristic).
        barycenter: Averaging method. Currently supports 'distance' or 'lle' (Locally Linear Embedding).
        embedding_models: Dictionary containing scikit-learn compatible projection models (e.g., PaCMAP),
                          used with `barycenter='transform'`. Each model must have been fit on
                          `adata_ref.obsm[use_rep]` (all reference cells, in order); this is checked.
        recompute_ref_PCA: If True, recomputes PCA on the reference dataset before projecting the query.
                           Embedding models are still applied in the stored `X_pca` space.
        save_ref_PCA_key: Optional key to save the projected query PCA representation in `adata_query.obsm`.
                          With `recompute_ref_PCA=True` the matching reference coordinates are saved
                          under the same key in `adata_ref.obsm` (the key must not exist there yet);
                          otherwise the query is in the basis of `adata_ref.obsm['X_pca']`.
        lle_reg_lambda: Regularization strength for Locally Linear Embedding (`barycenter='lle'`).
                        Decreasing it (e.g., to 1e-4) forces sparser, sharper assignment to nearest neighbors.
        **kwargs: Additional args for compute_kknn_neighbors (e.g., min_neighbors, max_neighbors).

    Notes:
        - With `use_rep='X_pca'` the query is projected with the reference statistics: if the
          reference was scaled with `sc.pp.scale`, the query is standardised as
          `(x - mean_ref) / std_ref` and clipped like the reference; it is then centred on the
          reference mean. The query `.X` must hold the same kind of values as the reference
          `.X` before scaling (e.g. log-normalised data).
        - When barycenter='distance', inverse distance weights are calculated using a scale-invariant
          bandwidth based on the median neighborhood distance plus a small epsilon
          (`1.0 / (dist + median_dist + 1e-6)`). This properly prevents self-nodes (dist=0) from
          pathologically dominating the vote with near-infinite self-weights.
        - Manages temporary PCA projections (`__temp_ingest_...` in `adata_query.obsm`) by wrapping
          the entire neighbor computation and mapping process in a `try...finally` block, ensuring the
          temporary representation is available for `barycenter` calculations and safely deleted afterwards.
        - Supports two refined embedding projection methods: `barycenter="transform"` maps query data natively
          via an embedding model's `.transform()` method (passed via an `embedding_models` dict), and
          `barycenter="lle"` uses an exact Non-Negative Least Squares (NNLS) solver with Cholesky decomposition
          to compute Regularized Locally Linear Embedding weights, rigorously enforcing non-negativity constraints.
        - Aligns reference and query datasets for `anndata.concat(..., join='outer')` by duplicating the
          reference's `.obs` and `.obsm` keys with a `_kknn` suffix, and setting ground-truth reference
          tracking metadata (like `kknn_k` and `mapping_confidence`) to `NaN`. This ensures keys align
          perfectly when preserving non-overlapping metadata via outer join.
    """
    if isinstance(obs_keys, str):
        obs_keys = [obs_keys]
    if isinstance(obsm_keys, str):
        obsm_keys = [obsm_keys]

    obs_keys = obs_keys or []
    obsm_keys = obsm_keys or []

    if not obs_keys and not obsm_keys:
        print("No keys specified to transfer.")
        return

    # Verify keys exist in reference
    for key in obs_keys:
        if key not in adata_ref.obs:
            raise KeyError(f"Label '{key}' not found in adata_ref.obs")
    for key in obsm_keys:
        if key not in adata_ref.obsm:
            raise KeyError(f"Embedding '{key}' not found in adata_ref.obsm")

    original_use_rep = use_rep
    query_use_rep = use_rep
    temp_query_rep_key = None
    temp_ref_rep_key = None
    # Query coordinates in the space the embedding models were fit on, when that is
    # not the space used for the neighbour search (barycenter='transform').
    model_X_query = None

    if use_rep == "X_pca":
        if not adata_query.var_names.equals(adata_ref.var_names):
            raise ValueError(
                "adata_query.var_names and adata_ref.var_names are not identical. "
                "It is expected that the datasets have been intersected to contain the same features. "
                "For example:\n"
                "common_genes = adata_ref.var_names.intersection(adata_query.var_names)\n"
                "adata_ref = adata_ref[:, common_genes].copy()\n"
                "adata_query = adata_query[:, common_genes].copy()"
            )

        has_stored_pca = (
            "pca" in adata_ref.uns and "PCs" in adata_ref.varm and "X_pca" in adata_ref.obsm
        )
        needs_model_space = (
            barycenter == "transform"
            and embedding_models is not None
            and any(key in embedding_models for key in obsm_keys)
        )

        if recompute_ref_PCA:
            if save_ref_PCA_key is not None and save_ref_PCA_key in adata_ref.obsm:
                raise ValueError(
                    f"save_ref_PCA_key='{save_ref_PCA_key}' already exists in adata_ref.obsm. With "
                    "recompute_ref_PCA=True the query is projected onto a freshly computed PCA whose "
                    "axes differ from it. Use a new key (the matching reference coordinates are "
                    "stored under it as well), or recompute_ref_PCA=False to project onto the "
                    "reference's stored PCA."
                )
            if needs_model_space and not has_stored_pca:
                raise ValueError(
                    "barycenter='transform' needs the query in the space the embedding models were "
                    "fit on (adata_ref.obsm['X_pca']), but adata_ref has no stored PCA "
                    "(uns['pca'], varm['PCs'])."
                )
            print(
                "Warning: recompute_ref_PCA is True, but this function will not mutate your reference object in place."
            )
            print("Creating a shallow copy of reference to recompute PCA...")

            # Create a shallow copy to prevent overwriting the user's reference PCA
            adata_ref_copy = adata_ref.copy()

            if "counts" in adata_ref_copy.layers:
                sc.pp.highly_variable_genes(
                    adata_ref_copy,
                    n_top_genes=1000,
                    subset=False,
                    layer="counts",
                    flavor="seurat_v3",
                )
            else:
                sc.pp.highly_variable_genes(
                    adata_ref_copy, n_top_genes=1000, subset=False, flavor="seurat"
                )
            sc.tl.pca(adata_ref_copy)

            x_pca_projected = _project_onto_reference_pca(adata_query, adata_ref_copy)
            ref_pca_coords = adata_ref_copy.obsm["X_pca"]
            del adata_ref_copy

            if save_ref_PCA_key is not None:
                # Store the reference in the same basis, so the saved query projection
                # can be compared or concatenated with it.
                adata_ref.obsm[save_ref_PCA_key] = ref_pca_coords
                use_rep = save_ref_PCA_key
            else:
                # Store it temporarily for this run
                temp_ref_rep_key = f"__temp_ref_ingest_{uuid4().hex[:8]}"
                adata_ref.obsm[temp_ref_rep_key] = ref_pca_coords
                use_rep = temp_ref_rep_key

            if needs_model_space:
                # The models were fit on the reference's stored X_pca, not on the recomputed PCA
                model_X_query = _project_onto_reference_pca(adata_query, adata_ref)
        else:
            if not has_stored_pca:
                raise ValueError(
                    "Reference dataset must have PCA computed (adata_ref.uns['pca'] and adata_ref.varm['PCs'])."
                )
            x_pca_projected = _project_onto_reference_pca(adata_query, adata_ref)

        if save_ref_PCA_key is not None:
            adata_query.obsm[save_ref_PCA_key] = x_pca_projected
            query_use_rep = save_ref_PCA_key
        else:
            # Save temporarily
            temp_query_rep_key = f"__temp_ingest_{uuid4().hex[:8]}"
            adata_query.obsm[temp_query_rep_key] = x_pca_projected
            query_use_rep = temp_query_rep_key

    try:
        # 1. Compute kkNN neighborhoods
        pruned_distances, pruned_indices = compute_kknn_neighbors(
            adata_query,
            adata_ref,
            use_rep=use_rep,
            query_use_rep=query_use_rep,
            n_neighbors=n_neighbors,
            **kwargs,
        )

        N_query = adata_query.shape[0]

        # 1.5 Store the adapted k value
        adata_query.obs["kknn_k"] = [len(idx) for idx in pruned_indices]
        # Reference cells are not mapped, so we set their kknn_k to NaN
        adata_ref.obs["kknn_k"] = np.nan

        # 1.5 Precompute cell weights based on barycenter strategy
        cell_weights = []
        if barycenter == "lle" or (barycenter == "transform" and not obsm_keys):
            # Only do scipy imports if needed
            from scipy.linalg import cholesky, solve_triangular
            from scipy.optimize import nnls

        for i in range(N_query):
            idx = pruned_indices[i]
            dist = pruned_distances[i]

            if barycenter == "distance" or barycenter == "transform":
                # Inverse distance weighting (default for transform if needed later, and distance)
                weights = _kknn_distance_weights(dist)
            elif barycenter == "lle":
                x_q = adata_query.obsm[query_use_rep][i]
                X_neigh = adata_ref.obsm[use_rep][idx]

                Z = X_neigh - x_q
                G = Z @ Z.T

                trace = np.trace(G)
                if trace > 0:
                    reg = lle_reg_lambda * trace / len(idx)
                else:
                    reg = lle_reg_lambda
                G_reg = G + reg * np.eye(len(idx))

                try:
                    L = cholesky(G_reg, lower=True)
                    b = solve_triangular(L, np.ones(len(idx)), lower=True)
                    w, _ = nnls(L.T, b)
                    w_sum = np.sum(w)
                    if w_sum > 0:
                        weights = w / w_sum
                    else:
                        weights = np.ones(len(idx)) / len(idx)
                except (np.linalg.LinAlgError, ValueError):
                    weights = _kknn_distance_weights(dist)
            elif barycenter == "wasserstein":
                if i == 0:
                    warnings.warn(
                        "Wasserstein barycenter not yet fully implemented. Falling back to distance-weighted."
                    )
                weights = _kknn_distance_weights(dist)
            else:
                # Unweighted fallback
                weights = np.ones(len(idx)) / len(idx)

            cell_weights.append(weights)


        # 2. Map .obsm (Embeddings)
        for key in obsm_keys:
            print(f"Mapping obsm: '{key}'...")
            ref_coords = adata_ref.obsm[key]
            emb_dim = ref_coords.shape[1]

            if barycenter == "transform":
                if embedding_models is not None and key in embedding_models:
                    model = embedding_models[key]
                    print(f"Using provided model's .transform() for '{key}'...")

                    # The model maps from the space it was fit on: adata_ref.obsm[original_use_rep]
                    if model_X_query is not None:
                        X_q = model_X_query
                        X_r = adata_ref.obsm[original_use_rep]
                    else:
                        X_q = adata_query.obsm[query_use_rep]
                        X_r = adata_ref.obsm[use_rep]
                    _check_embedding_model(
                        model, key, X_q, X_r, ref_coords, original_use_rep
                    )

                    try:
                        import pacmap

                        if isinstance(model, pacmap.PaCMAP):
                            query_coords = model.transform(X_q, basis=X_r)
                        else:
                            query_coords = model.transform(X_q)
                    except ImportError:
                        query_coords = model.transform(X_q)

                    adata_query.obsm[f"{key}_kknn"] = query_coords
                    adata_ref.obsm[f"{key}_kknn"] = ref_coords
                    continue
                else:
                    warnings.warn(
                        f"barycenter='transform' requested but '{key}' not found in embedding_models. Falling back to distance weights."
                    )

            query_coords = np.zeros((N_query, emb_dim))

            for i in range(N_query):
                idx = pruned_indices[i]
                weights = cell_weights[i]
                coords = ref_coords[idx]

                if barycenter not in ["distance", "lle", "wasserstein", "transform"]:
                    # Unweighted mean fallback
                    query_coords[i] = np.mean(coords, axis=0)
                else:
                    query_coords[i] = np.average(coords, axis=0, weights=weights)

            adata_query.obsm[f"{key}_kknn"] = query_coords

            # Duplicate the reference embedding to line up correctly with the mapped query embedding
            adata_ref.obsm[f"{key}_kknn"] = ref_coords

        # 3. Map .obs (Labels) and compute confidence
        for key in obs_keys:
            print(f"Mapping obs: '{key}'...")
            ref_labels = adata_ref.obs[key].values
            ref_col = adata_ref.obs[key]

            if pd.api.types.is_numeric_dtype(ref_col) and not pd.api.types.is_bool_dtype(ref_col):
                # Continuous values: NaN-aware weighted mean over the neighbourhood (a vote
                # over float values would be 1-NN). The spread is the weighted std; a
                # vote-fraction confidence has no meaning here, so it is NaN.
                values = ref_col.to_numpy(dtype=float)
                means = np.full(N_query, np.nan)
                stds = np.full(N_query, np.nan)
                for i in range(N_query):
                    v = values[pruned_indices[i]]
                    w = np.asarray(cell_weights[i], dtype=float)
                    ok = np.isfinite(v) & (w > 0)
                    if ok.any():
                        w_ok = w[ok] / w[ok].sum()
                        means[i] = np.sum(w_ok * v[ok])
                        stds[i] = np.sqrt(np.sum(w_ok * (v[ok] - means[i]) ** 2))
                adata_query.obs[f"{key}_kknn"] = means
                adata_ref.obs[f"{key}_kknn"] = ref_col
                adata_query.obs[f"mapping_std_{key}_kknn"] = stds
                adata_ref.obs[f"mapping_std_{key}_kknn"] = np.nan
                conf_key = f"mapping_confidence_{key}_kknn"
                adata_query.obs[conf_key] = np.nan
                adata_ref.obs[conf_key] = np.nan
                continue

            mapped_labels = []
            confidences = []

            for i in range(N_query):
                idx = pruned_indices[i]
                weights = cell_weights[i]

                labels_i = ref_labels[idx]

                # Tally weighted votes
                vote_tally = {}
                for lbl, w in zip(labels_i, weights):
                    vote_tally[lbl] = vote_tally.get(lbl, 0) + w

                # Find the winner
                winner = max(vote_tally.items(), key=lambda x: x[1])
                winning_label = winner[0]
                winning_weight_frac = winner[1]  # Already normalized to 1.0

                mapped_labels.append(winning_label)

                # Mapping confidence: proportion of weighted vote
                confidences.append(winning_weight_frac)

            # If the original was categorical, keep it categorical
            if isinstance(adata_ref.obs[key].dtype, pd.CategoricalDtype):
                cat_dtype = adata_ref.obs[key].dtype
                adata_query.obs[f"{key}_kknn"] = pd.Categorical(
                    mapped_labels, categories=cat_dtype.categories
                )
            else:
                adata_query.obs[f"{key}_kknn"] = mapped_labels

            # Duplicate the reference label to line up correctly with the mapped label
            adata_ref.obs[f"{key}_kknn"] = adata_ref.obs[key]

            # Store confidence
            conf_key = f"mapping_confidence_{key}_kknn"
            adata_query.obs[conf_key] = confidences
            # Reference cells are not mapped, so we set their confidence to NaN
            adata_ref.obs[conf_key] = np.nan

    finally:
        # Clean up temporary query representation if used
        if temp_query_rep_key is not None:
            if temp_query_rep_key in adata_query.obsm:
                del adata_query.obsm[temp_query_rep_key]
        if temp_ref_rep_key is not None:
            if temp_ref_rep_key in adata_ref.obsm:
                del adata_ref.obsm[temp_ref_rep_key]

    print("kkNN Ingest mapping complete!")


def find_correlated_features(
    adata: sc.AnnData,
    target: str,
    layer: Optional[str] = None,
    use_raw: bool = False,
    metrics: Sequence[str] = ("pearson",),
    exclude_features: Optional[List[str]] = None,
    use_graph: bool = False,
    weights_key: str = "connectivities",
) -> pd.DataFrame:
    """
    Find highly correlated features with respect to a given target gene or observation score.

    Args:
        adata: The annotated data matrix.
        target: The name of the target gene (in `adata.var_names`) or observation column (in `adata.obs`).
                The function checks `adata.obs` first, then falls back to `adata.var_names`.
        layer: The layer to use for expression data. If None, uses `adata.X`.
        use_raw: Whether to use `adata.raw`. Overrides `layer`.
        metrics: A list of metrics to compute. Options are 'pearson', 'spearman', 'wasserstein'.
                 Defaults to ['pearson'].
        exclude_features: An optional list of feature names to exclude from the final results.
        use_graph: If True, uses the cell-cell graph to diffuse (smooth) the expressions before
                   calculating the distance/correlation. This mimics a graph-based feature distance,
                   putting a lower distance on genes that are expressed in the same graph neighborhood.
        weights_key: The key in `adata.obsp` containing the graph edges if `use_graph` is True.

    Returns:
        A Pandas DataFrame containing the requested metrics for all features (except exclusions).
        The DataFrame is sorted descending by the first metric requested.
    """
    import scipy.sparse as sp
    import pandas as pd
    import numpy as np

    if not metrics:
        raise ValueError("At least one metric must be requested.")

    # Validate target
    target_vec = None
    if target in adata.obs:
        target_vec = adata.obs[target].values.astype(float)
    else:
        try:
            target_vec = _extract_gene_vector(
                adata,
                target,
                source="raw"
                if use_raw and adata.raw is not None
                else layer
                if layer
                else "X",
                duplicate_policy="mean",
            )
        except KeyError:
            pass

    if target_vec is None:
        raise ValueError(
            f"Target '{target}' not found in adata.obs or adata.var_names."
        )

    # Extract the main matrix
    M, var_names = _select_matrix_and_names(
        adata,
        source="raw" if use_raw and adata.raw is not None else layer if layer else "X",
    )

    # Cells without a finite target value are left out (one NaN would otherwise make
    # every metric NaN); graph smoothing needs a value on every cell.
    finite_target = np.isfinite(target_vec)
    if not finite_target.all():
        n_bad = int((~finite_target).sum())
        if use_graph:
            raise ValueError(
                f"Target '{target}' has {n_bad} non-finite values; use_graph=True needs a "
                "value for every cell. Impute them or use use_graph=False."
            )
        warnings.warn(
            f"Target '{target}' has {n_bad} non-finite values; computing on the "
            f"{int(finite_target.sum())} remaining cells."
        )
        target_vec = target_vec[finite_target]
        M = M[np.flatnonzero(finite_target)]

    n_cells, n_features = M.shape
    if n_cells <= 1:
        raise ValueError("Cannot compute correlation with 1 or fewer cells.")

    if use_graph:
        target_vec = smooth_expression_on_graph(
            adata, target_vec.reshape(-1, 1), weights_key=weights_key
        ).ravel()
        # Diffuse the entire feature matrix at once
        M = smooth_expression_on_graph(adata, M, weights_key=weights_key)
        # Note: M is now a dense numpy array

    # Target vector centering/scaling
    target_mean = np.mean(target_vec)
    target_std = np.std(target_vec)
    target_z = (target_vec - target_mean) / (target_std + 1e-8)

    # Initialize results dictionary
    res_dict = {}

    # Pre-calculate feature means/stds if needed by any metric
    # Pearson needs it to scale the covariance.
    # Wasserstein needs it for Z-scoring the features.
    need_z_stats = "pearson" in metrics or "wasserstein" in metrics
    feature_means = None
    feature_stds = None

    if need_z_stats:
        if sp.issparse(M):
            # Calculate exactly without instantiating dense matrix
            feature_means = np.asarray(M.mean(axis=0)).ravel()
            sq_means = np.asarray(M.multiply(M).mean(axis=0)).ravel()
            variances = np.maximum(sq_means - feature_means**2, 0.0)
            feature_stds = np.sqrt(variances) + 1e-8
        else:
            feature_means = np.asarray(M.mean(axis=0)).ravel()
            feature_stds = np.asarray(M.std(axis=0)).ravel() + 1e-8

    if "pearson" in metrics:
        # Fast Pearson using dot product with Z-scored target
        if sp.issparse(M):
            # M.T @ target_z gives sum(X_i * target_z_i) for each feature.
            # To get Pearson r: (X_centered.T @ target_z) / (N * X_std)
            # X_centered.T @ target_z = (X.T - mean).T @ target_z
            #                         = X.T @ target_z - mean * sum(target_z)
            # Since target_z has zero mean, sum(target_z) is ~0, so X_centered.T @ target_z ≈ X.T @ target_z
            # (Math check: exactly true if target_z has exactly zero mean)

            covar_sum = np.asarray(M.T @ target_z).ravel()
            # Correct for small numerical offset in sum(target_z)
            sum_tz = np.sum(target_z)
            covar_sum -= feature_means * sum_tz

            r_pearson = covar_sum / (n_cells * feature_stds)
        else:
            M_dense = np.asarray(M)
            covar_sum = M_dense.T @ target_z
            sum_tz = np.sum(target_z)
            covar_sum -= feature_means * sum_tz
            r_pearson = covar_sum / (n_cells * feature_stds)

        # Clip numerical noise
        res_dict["pearson"] = np.clip(r_pearson, -1.0, 1.0)

    if "spearman" in metrics:
        from scipy.stats import rankdata

        def zscore(r):
            # constant input (rank std 0) -> zeros, i.e. r = 0, as for Pearson
            sd = r.std()
            return (r - r.mean()) / sd if sd > 0 else np.zeros_like(r, dtype=float)

        target_rank_z = zscore(rankdata(target_vec))
        r_spear = np.empty(n_features, dtype=float)

        if sp.issparse(M):
            # Process column by column to avoid dense matrix allocation
            M_csc = M.tocsc()
            for j in range(n_features):
                col = M_csc[:, j].toarray().ravel()
                col_rank_z = zscore(rankdata(col))
                # Spearman is just Pearson of ranks
                r_spear[j] = np.dot(col_rank_z, target_rank_z) / n_cells
        else:
            M_dense = np.asarray(M)
            for j in range(n_features):
                col_rank_z = zscore(rankdata(M_dense[:, j]))
                r_spear[j] = np.dot(col_rank_z, target_rank_z) / n_cells

        res_dict["spearman"] = np.clip(r_spear, -1.0, 1.0)

    if "wasserstein" in metrics:
        from scipy.stats import wasserstein_distance

        # matth: The 1D Wasserstein distance between two equal-sized empirical
        # distributions with uniform weights simplifies exactly to the L1 distance
        # of their order statistics. This bypasses the numerical integration and
        # interpolation overhead in scipy.stats.wasserstein_distance.
        w_dist = np.empty(n_features, dtype=float)

        target_z_sorted = np.sort(target_z)

        if sp.issparse(M):
            M_csc = M.tocsc()
            for j in range(n_features):
                # We must dense the column to apply wasserstein, but it's only 1D
                col = M_csc[:, j].toarray().ravel()
                # Z-score using precomputed exact stats
                col_z = (col - feature_means[j]) / feature_stds[j]
                if col_z.size == target_z.size:
                    w_dist[j] = np.mean(np.abs(np.sort(col_z) - target_z_sorted))
                else:
                    w_dist[j] = wasserstein_distance(col_z, target_z)
        else:
            M_dense = np.asarray(M)
            for j in range(n_features):
                col_z = (M_dense[:, j] - feature_means[j]) / feature_stds[j]
                if col_z.size == target_z.size:
                    w_dist[j] = np.mean(np.abs(np.sort(col_z) - target_z_sorted))
                else:
                    w_dist[j] = wasserstein_distance(col_z, target_z)

        res_dict["wasserstein"] = w_dist

    # Compile DataFrame
    res_df = pd.DataFrame(res_dict, index=var_names)

    # Apply exclusions
    if exclude_features:
        exclude_set = set(exclude_features)
        # Identify which exclusions are actually in the index to avoid KeyError
        mask = res_df.index.isin(exclude_set)
        res_df = res_df[~mask]

    # Sort by the first metric requested
    first_metric = metrics[0]
    ascending = (
        first_metric == "wasserstein"
    )  # Distance metrics are better when smaller
    res_df = res_df.sort_values(by=first_metric, ascending=ascending)

    return res_df
