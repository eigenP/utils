import numpy as np
import pandas as pd
from scipy import stats

def add_stat_annotations(
    ax,
    data,
    pairs,
    x=None,
    y=None,
    hue=None,
    test='t-test_welch',
    text_format='star',
    loc='inside',
    comparisons_correction='Holm-Bonferroni',
    return_annotator=False,
    order=None,
    hue_order=None,
    **kwargs
):
    """
    Convenience wrapper around statannotations.Annotator.

    Parameters
    ----------
    ax : matplotlib.axes.Axes
        The axes to annotate.
    data : pd.DataFrame or list
        The data used for the plot.
    pairs : list of tuple
        List of pairs of groups to compare.
    x : str, optional
        The name of the x-axis variable.
    y : str, optional
        The name of the y-axis variable.
    hue : str, optional
        The name of the hue variable.
    test : str, default 't-test_welch'
        The statistical test to run.
    text_format : str, default 'star'
        The format of the text annotation ('star' or 'simple').
    loc : str, default 'inside'
        Location of the annotations ('inside' or 'outside').
    comparisons_correction : str, default 'Holm-Bonferroni'
        The multiple testing correction method.
    return_annotator : bool, default False
        Whether to return the Annotator object in addition to the Axes.
    order : list, optional
        Order of the groups along the categorical axis, as drawn. If None, it is
        read from the axis tick labels when they name exactly the groups in `data`
        (e.g. after `raincloud_plot`, which sorts groups), so the brackets land on
        the right groups; otherwise statannotations' default (first appearance) is used.
    hue_order : list, optional
        Order of the hue levels, as drawn.
    **kwargs : dict
        Additional kwargs passed to annotator.configure()

    Returns
    -------
    matplotlib.axes.Axes
        The modified axes.
    (matplotlib.axes.Axes, statannotations.Annotator)
        If return_annotator is True.
    """
    try:
        from statannotations.Annotator import Annotator
    except ImportError:
        raise ImportError(
            "The 'statannotations' package is required for add_stat_annotations. "
            "Please install it using 'pip install statannotations' or "
            "'pip install eigenp_utils[plotting]'."
        )

    if order is None:
        order = _order_from_ticks(ax, data, x, y)

    annotator = Annotator(ax, pairs, data=data, x=x, y=y, hue=hue, order=order, hue_order=hue_order)
    annotator.configure(
        test=test,
        text_format=text_format,
        loc=loc,
        comparisons_correction=comparisons_correction,
        **kwargs
    )
    annotator.apply_and_annotate()

    if return_annotator:
        return ax, annotator
    return ax


def _order_from_ticks(ax, data, x, y):
    """Group order as drawn on ax, read from the tick labels of the categorical axis.

    Returns None unless the tick labels name exactly the groups present in `data`.
    """
    if not isinstance(data, pd.DataFrame):
        return None
    for col, ticks in ((x, ax.get_xticklabels()), (y, ax.get_yticklabels())):
        if col is None or col not in data or (pd.api.types.is_numeric_dtype(data[col]) and not isinstance(data[col].dtype, pd.CategoricalDtype)):
            continue
        groups = {str(v): v for v in pd.unique(data[col].dropna())}
        labels = [t.get_text() for t in ticks]
        if labels and len(labels) == len(groups) and set(labels) == set(groups):
            return [groups[label] for label in labels]
    return None

import scipy.special
import warnings



def robust_standardize(data, axis=None):
    """
    Standardize an array robustly, handling ties, zero-inflation, and identical values.

    Implements a hierarchical dispersion fallback:
    1. Median Absolute Deviation (MAD)
    2. Mean Absolute Deviation (MeanAD)
    3. Standard Deviation (STD)

    Parameters
    ----------
    data : array-like
        The data to standardize.
    axis : int or tuple of ints, optional
        Axis along which the standardization is computed.

    Returns
    -------
    ndarray
        The standardized array.
    """
    arr = np.asarray(data, dtype=float)

    if axis is None:
        all_nan = np.isnan(arr).all()
        if all_nan:
            return arr.copy()
    else:
        all_nan = np.isnan(arr).all(axis=axis, keepdims=True)

    # Temporarily replace all-NaN slices with 0.0 to prevent RuntimeWarnings in nan-functions
    safe_arr = np.where(all_nan, 0.0, arr)

    # 1. Median and MAD
    med = np.nanmedian(safe_arr, axis=axis, keepdims=True)
    mad = np.nanmedian(np.abs(safe_arr - med), axis=axis, keepdims=True)
    # Asymptotic normal scaling factor for MAD is 1.482602218505602
    scale = mad * 1.482602218505602
    loc = med

    # 2. Mean and MeanAD fallback
    mask_mad_zero = (mad == 0)
    if np.any(mask_mad_zero):
        mean = np.nanmean(safe_arr, axis=axis, keepdims=True)
        mean_ad = np.nanmean(np.abs(safe_arr - mean), axis=axis, keepdims=True)
        # Asymptotic normal scaling factor for MeanAD is sqrt(pi / 2)
        scale_mean_ad = mean_ad * np.sqrt(np.pi / 2.0)

        # 3. Standard deviation fallback
        mask_mean_ad_zero = (mean_ad == 0)
        if np.any(mask_mean_ad_zero & mask_mad_zero):
            std = np.nanstd(safe_arr, axis=axis, keepdims=True)
            scale_mean_ad = np.where(mask_mean_ad_zero, std, scale_mean_ad)

        # Apply fallback where MAD is zero
        scale = np.where(mask_mad_zero, scale_mean_ad, scale)
        loc = np.where(mask_mad_zero, mean, loc)

    # Avoid division by zero where scale is still exactly 0 (all values identical)
    safe_scale = np.where(scale == 0, 1.0, scale)
    z = (arr - loc) / safe_scale
    z = np.where(scale == 0, 0.0, z)

    # Restore NaNs for all-NaN slices
    z = np.where(all_nan, np.nan, z)

    return z


def cohens_d(group1, group2, correction=True):
    """
    Calculate Cohen's d effect size for two independent samples.
    By default, applies Hedges' exact correction factor to yield an unbiased estimator (Hedges' g).

    Parameters
    ----------
    group1 : array-like
        The first group of observations.
    group2 : array-like
        The second group of observations.
    correction : bool, default True
        Whether to apply Hedges' correction for small sample sizes.
        If True, returns Hedges' g. If False, returns Cohen's d (biased sample estimate).

    Returns
    -------
    float
        The calculated effect size.
    """
    x1 = np.asarray(group1)
    x2 = np.asarray(group2)

    n1 = len(x1)
    n2 = len(x2)

    if n1 < 2 or n2 < 2:
        return np.nan

    var1 = np.var(x1, ddof=1)
    var2 = np.var(x2, ddof=1)

    # Pooled standard deviation
    s_pooled = np.sqrt(((n1 - 1) * var1 + (n2 - 1) * var2) / (n1 + n2 - 2))

    if s_pooled == 0:
        # Both groups constant: no effect only if the means are equal too;
        # otherwise the standardized difference is unbounded.
        diff = np.mean(x1) - np.mean(x2)
        return 0.0 if diff == 0 else float(np.copysign(np.inf, diff))

    d = (np.mean(x1) - np.mean(x2)) / s_pooled

    if correction:
        # Apply Hedges' exact correction factor J(df)
        df = n1 + n2 - 2
        # J(df) = Gamma(df/2) / (sqrt(df/2) * Gamma((df-1)/2))
        # Calculated via log-gamma for numerical stability:
        # exp(gammaln(df/2) - 0.5 * log(df/2) - gammaln((df-1)/2))
        j_factor = np.exp(scipy.special.gammaln(df / 2.0) - 0.5 * np.log(df / 2.0) - scipy.special.gammaln((df - 1) / 2.0))
        d = d * j_factor

    return float(d)

def bootstrap_ci(data, stat_func=np.mean, n_bootstraps=1000, ci=0.95, method='bca', random_state=None):
    """
    Compute bootstrapped confidence intervals for an array.

    Parameters
    ----------
    data : array-like
        The data to bootstrap.
    stat_func : callable, default np.mean
        The statistic to calculate (e.g., np.mean, np.median).
    n_bootstraps : int, default 1000
        The number of bootstrap samples.
    ci : float, default 0.95
        The confidence interval width (between 0 and 1).
    method : str, default 'bca'
        The bootstrap method to use. Options are:
        - 'bca': Bias-Corrected and Accelerated (BCa) bootstrap. Corrects for median bias and skewness.
        - 'bc': Bias-Corrected (BC) bootstrap. Corrects for median bias in the bootstrap distribution.
        - 'percentile': Standard percentile bootstrap.
    random_state : int or np.random.Generator, optional
        Seed or Generator for reproducibility.

    Returns
    -------
    tuple
        A tuple of (lower_bound, upper_bound)
    """
    data = np.asarray(data)
    if len(data) < 2:
        raise ValueError("bootstrap_ci needs at least 2 observations.")
    if np.issubdtype(data.dtype, np.number) and np.isnan(data).any():
        raise ValueError("bootstrap_ci: data contains NaN; drop missing values first.")
    rng = np.random.default_rng(random_state)

    # Generate bootstrap indices
    indices = rng.integers(0, len(data), size=(n_bootstraps, len(data)))

    # Calculate statistic for each bootstrap sample
    # Note: apply_along_axis expects a 1D array as input to the lambda, so data[x] gives us the resampled data for that row
    bootstrapped_stats = np.apply_along_axis(lambda x: stat_func(data[x]), 1, indices)

    alpha = 1.0 - ci

    if method == 'percentile':
        lower_percentile = (alpha / 2.0) * 100
        upper_percentile = (1.0 - alpha / 2.0) * 100

        lower_bound = np.percentile(bootstrapped_stats, lower_percentile)
        upper_bound = np.percentile(bootstrapped_stats, upper_percentile)

    elif method in ('bc', 'bca'):
        # Bias-Corrected (BC) Bootstrap
        theta_hat = stat_func(data)

        # Calculate empirical bias correction factor z0
        # z0 = Phi^-1 ( proportion of bootstrapped_stats < theta_hat )
        # matth: Robustly handle ties for discrete statistics (like median)
        prop_less = np.mean(bootstrapped_stats < theta_hat) + 0.5 * np.mean(bootstrapped_stats == theta_hat)

        # Handle edge cases where all stats are >= or <= theta_hat
        if prop_less == 0:
            prop_less = 1 / (n_bootstraps + 1)
        elif prop_less == 1:
            prop_less = n_bootstraps / (n_bootstraps + 1)

        z0 = stats.norm.ppf(prop_less)

        # Calculate adjusted percentiles
        z_alpha_2 = stats.norm.ppf(alpha / 2.0)
        z_1_alpha_2 = stats.norm.ppf(1.0 - alpha / 2.0)

        a = 0.0
        if method == 'bca':
            # Calculate acceleration factor (a) using jackknife estimates
            # Leave out one observation (row) at a time, matching the row-wise
            # bootstrap resampling above (np.delete without an axis would flatten 2D data)
            jackknife_stats = np.empty(len(data))
            keep = np.ones(len(data), dtype=bool)
            for i in range(len(data)):
                keep[i] = False
                jackknife_stats[i] = stat_func(data[keep])
                keep[i] = True

            mean_jackknife = np.mean(jackknife_stats)
            diffs = mean_jackknife - jackknife_stats

            denom = 6.0 * (np.sum(diffs**2))**1.5
            if denom != 0:
                a = np.sum(diffs**3) / denom

        # BCa adjustment formula (reduces to BC when a = 0)
        adj_alpha_1 = stats.norm.cdf(z0 + (z0 + z_alpha_2) / (1.0 - a * (z0 + z_alpha_2)))
        adj_alpha_2 = stats.norm.cdf(z0 + (z0 + z_1_alpha_2) / (1.0 - a * (z0 + z_1_alpha_2)))


        lower_percentile = adj_alpha_1 * 100
        upper_percentile = adj_alpha_2 * 100

        lower_bound = np.percentile(bootstrapped_stats, lower_percentile)
        upper_bound = np.percentile(bootstrapped_stats, upper_percentile)

    else:
        raise ValueError(f"Unknown bootstrap method '{method}'. Use 'bc', 'bca', or 'percentile'.")

    return float(lower_bound), float(upper_bound)

def summary_stats(df, group_by, value_col):
    """
    Generate a clean summary for grouped data in a DataFrame.

    Parameters
    ----------
    df : pd.DataFrame
        The DataFrame containing the data.
    group_by : str or list of str
        The column(s) to group by.
    value_col : str
        The column to calculate statistics for.

    Returns
    -------
    pd.DataFrame
        A DataFrame with the summary statistics.
    """
    if isinstance(group_by, str):
        group_by = [group_by]

    summary = df.groupby(group_by)[value_col].agg(
        count='count',
        mean='mean',
        median='median',
        std='std',
        sem=lambda x: x.std() / np.sqrt(x.count()) if x.count() > 0 else np.nan,
        min='min',
        max='max'
    ).reset_index()

    return summary

def _abs_zscore(values):
    """|z| of NaN-free values; a zero-variance (or single-value) sample has no outliers.

    scipy.stats.zscore returns NaN there, and NaN <= threshold is False, which used
    to flag every value of a constant column (and so drop every row).
    """
    values = np.asarray(values, dtype=float)
    sd = values.std()
    if values.size < 2 or not sd > 0:
        return np.zeros(values.shape)
    return np.abs((values - values.mean()) / sd)


def remove_outliers(data, method='iqr', threshold=1.5, column=None):
    """
    Filter out outliers in a DataFrame or array.

    Parameters
    ----------
    data : pd.DataFrame or array-like
        The data to filter.
    method : str, default 'iqr'
        The method to use ('iqr', 'zscore', 'robust_zscore', or 'mahalanobis').
        'robust_zscore' uses Median Absolute Deviation (MAD) which is less susceptible
        to extreme outliers inflating variance compared to 'zscore'.
        'mahalanobis' computes the squared Mahalanobis distance using the pseudo-inverse
        covariance matrix. It requires at least 2 dimensions and bypasses NaNs.
    threshold : float, default 1.5
        The threshold for filtering (IQR multiplier or Z-score threshold).
        If method='mahalanobis', this functions as a Chi-Square cumulative probability
        (e.g., 0.95 or 0.99).
    column : str, optional
        If data is a DataFrame, the column to filter on. If None and data
        is a DataFrame, filters rows where any column has an outlier.
        Must be None if method='mahalanobis' since Mahalanobis is inherently multivariate.

    Returns
    -------
    pd.DataFrame or array-like
        The filtered data. 1D arrays drop outliers and NaNs; 2D arrays drop rows
        (observations) with an outlier in any column, keeping NaNs as DataFrames do.
        A constant (zero-variance) column never produces z-score outliers.
    """

    if isinstance(data, pd.DataFrame):
        df_out = data.copy()

        if column is not None:
            if method == 'mahalanobis':
                raise ValueError("Mahalanobis distance cannot be applied to a single column.")
            # Filtering based on a single column
            if method == 'iqr':
                q1 = df_out[column].quantile(0.25)
                q3 = df_out[column].quantile(0.75)
                iqr = q3 - q1
                lower_bound = q1 - threshold * iqr
                upper_bound = q3 + threshold * iqr
                mask = (df_out[column] >= lower_bound) & (df_out[column] <= upper_bound)
            elif method == 'zscore':
                # Use scipy.stats.zscore with nan_policy='omit'
                valid_mask = df_out[column].notna()
                z_scores = pd.Series(index=df_out.index, dtype=float)
                z_scores[valid_mask] = _abs_zscore(df_out.loc[valid_mask, column])
                mask = valid_mask & (z_scores <= threshold)
            elif method == 'robust_zscore':
                valid_mask = df_out[column].notna()
                z_scores = pd.Series(index=df_out.index, dtype=float)
                z_scores[valid_mask] = np.abs(robust_standardize(df_out.loc[valid_mask, column].values))
                mask = valid_mask & (z_scores <= threshold)
            else:
                raise ValueError(f"Unknown method '{method}'")

            # Keep NaNs if present
            mask = mask | df_out[column].isna()
            return df_out[mask].copy()

        else:
            # Filtering based on all numeric columns
            numeric_cols = df_out.select_dtypes(include=[np.number]).columns

            if method == 'mahalanobis':
                if len(numeric_cols) < 2:
                    raise ValueError("Mahalanobis distance requires at least 2 dimensions.")
                if not (0 < threshold < 1):
                    raise ValueError(f"For method='mahalanobis', threshold must be a probability between 0 and 1, got {threshold}.")

                X = df_out[numeric_cols].values
                valid_row_mask = ~np.isnan(X).any(axis=1)

                bool_mask = np.ones(len(df_out), dtype=bool)

                # D^2 needs a covariance, i.e. at least 2 complete rows; keep all otherwise
                if valid_row_mask.sum() >= 2:
                    X_valid = X[valid_row_mask]
                    n_samples, n_features = X_valid.shape

                    mean = np.mean(X_valid, axis=0)
                    X_centered = X_valid - mean
                    cov = np.cov(X_valid, rowvar=False)
                    inv_cov = np.linalg.pinv(cov)

                    left = np.dot(X_centered, inv_cov)
                    D_squared = np.sum(left * X_centered, axis=1)

                    if n_samples <= n_features + 1:
                        thresh = stats.chi2.ppf(threshold, df=n_features)
                    else:
                        bound = ((n_samples - 1) ** 2) / n_samples
                        thresh = bound * stats.beta.ppf(threshold, a=n_features / 2.0, b=(n_samples - n_features - 1) / 2.0)

                    valid_keep = D_squared <= thresh
                    bool_mask[valid_row_mask] = valid_keep

                mask = pd.Series(bool_mask, index=df_out.index)
                return df_out[mask].copy()

            mask = pd.Series(True, index=df_out.index)

            for col in numeric_cols:
                col_data = df_out[col]
                valid_mask = col_data.notna()
                if not valid_mask.any():
                    continue

                if method == 'iqr':
                    q1 = col_data.quantile(0.25)
                    q3 = col_data.quantile(0.75)
                    iqr = q3 - q1
                    lower_bound = q1 - threshold * iqr
                    upper_bound = q3 + threshold * iqr
                    col_mask = (col_data >= lower_bound) & (col_data <= upper_bound)
                elif method == 'zscore':
                    z_scores = pd.Series(index=df_out.index, dtype=float)
                    z_scores[valid_mask] = _abs_zscore(df_out.loc[valid_mask, col])
                    col_mask = valid_mask & (z_scores <= threshold)
                elif method == 'robust_zscore':
                    z_scores = pd.Series(index=df_out.index, dtype=float)
                    z_scores[valid_mask] = np.abs(robust_standardize(df_out.loc[valid_mask, col].values))
                    col_mask = valid_mask & (z_scores <= threshold)
                else:
                    raise ValueError(f"Unknown method '{method}'")

                # For NaNs, we keep them so we don't drop rows just for NaN unless intended
                col_mask = col_mask | df_out[col].isna()
                mask = mask & col_mask

            return df_out[mask].copy()

    else:
        # Array-like
        values = np.asarray(data)

        if method == 'mahalanobis':
            if values.ndim < 2 or values.shape[1] < 2:
                raise ValueError("Mahalanobis distance requires at least 2 dimensions.")
            if not (0 < threshold < 1):
                raise ValueError(f"For method='mahalanobis', threshold must be a probability between 0 and 1, got {threshold}.")

            valid_row_mask = ~np.isnan(values).any(axis=1)
            keep_mask = np.ones(values.shape[0], dtype=bool)

            # D^2 needs a covariance, i.e. at least 2 complete rows; keep all otherwise
            if valid_row_mask.sum() >= 2:
                X_valid = values[valid_row_mask]
                n_samples, n_features = X_valid.shape

                mean = np.mean(X_valid, axis=0)
                X_centered = X_valid - mean
                cov = np.cov(X_valid, rowvar=False)
                inv_cov = np.linalg.pinv(cov)

                left = np.dot(X_centered, inv_cov)
                D_squared = np.sum(left * X_centered, axis=1)

                if n_samples <= n_features + 1:
                    thresh = stats.chi2.ppf(threshold, df=n_features)
                else:
                    bound = ((n_samples - 1) ** 2) / n_samples
                    thresh = bound * stats.beta.ppf(threshold, a=n_features / 2.0, b=(n_samples - n_features - 1) / 2.0)

                valid_keep = D_squared <= thresh
                keep_mask[valid_row_mask] = valid_keep

            return values[keep_mask]

        if values.ndim == 2:
            # Filter rows on each column (as for a DataFrame) instead of pooling all
            # columns into one flattened sample.
            keep = remove_outliers(pd.DataFrame(values), method=method, threshold=threshold).index
            return values[np.asarray(keep)]
        if values.ndim > 2:
            raise ValueError("remove_outliers supports 1D or 2D arrays (rows = observations).")

        # Filter out NaNs for calculation
        valid_mask = ~np.isnan(values)
        valid_values = values[valid_mask]

        if len(valid_values) == 0:
            return values

        if method == 'iqr':
            q1 = np.percentile(valid_values, 25)
            q3 = np.percentile(valid_values, 75)
            iqr = q3 - q1
            lower_bound = q1 - threshold * iqr
            upper_bound = q3 + threshold * iqr
            keep_valid = (valid_values >= lower_bound) & (valid_values <= upper_bound)
        elif method == 'zscore':
            z_scores = _abs_zscore(valid_values)
            keep_valid = z_scores <= threshold
        elif method == 'robust_zscore':
            z_scores = np.abs(robust_standardize(valid_values))
            keep_valid = z_scores <= threshold
        else:
            raise ValueError(f"Unknown method '{method}'")

        # Reconstruct mask for the full array
        keep_mask = np.zeros_like(values, dtype=bool)
        keep_mask[valid_mask] = keep_valid

        # We generally drop the outliers for a flat array, and we drop NaNs
        return values[keep_mask]
