# /// script
# requires-python = ">=3.10"
# dependencies = [
#     "anywidget",
#     "traitlets",
#     "matplotlib",
#     "numpy",
#     "scipy",
# ]
# ///

import pathlib
import warnings

def _safe_float(v):
    if v is None:
        return None
    try:
        return float(v)
    except (TypeError, ValueError):
        # Handle zero-dimensional numpy arrays like np.array(1.5)
        if hasattr(v, 'size') and v.size == 1 and hasattr(v, 'item'):
            return float(v.item())
        raise ValueError(f"Could not convert {v} to float")

def _parse_zyx_tuple_or_dict(val, default_val=None, warn=True):
    """
    Parse a (Z, Y, X) tuple/list or a {'Z', 'Y', 'X'} dict into three floats.

    Missing or None entries (e.g. an uncalibrated axis from
    ``image_io.get_tiff_voxel_size``) become ``default_val``; a warning names
    the axis when a non-None default is substituted (unless ``warn`` is False,
    for callers that pass ``val`` on to a parser that will warn).
    """
    if val is None:
        return (default_val, default_val, default_val)
    if isinstance(val, dict):
        raw = (val.get('Z'), val.get('Y'), val.get('X'))
    else:
        try:
            raw = tuple(val)
        except TypeError:
            raw = ()
        if len(raw) != 3:
            raise ValueError(f"Expected dict with 'Z','Y','X' keys or a 3-element tuple/list, got {val}")

    out = []
    for axis, v in zip('ZYX', raw):
        if v is None:
            if default_val is not None and warn:
                warnings.warn(
                    f"No value for axis {axis} in {val!r}; using {default_val}.",
                    UserWarning, stacklevel=3,
                )
            out.append(default_val)
        else:
            out.append(_safe_float(v))
    return tuple(out)


# Length units of a pixel-size dict ('unit' key, e.g. from image_io) -> factor to µm
_UNIT_TO_UM = {
    'µm': 1.0, 'μm': 1.0, 'um': 1.0, 'micron': 1.0, 'microns': 1.0,
    'micrometer': 1.0, 'micrometre': 1.0, '\\u00b5m': 1.0,
    'nm': 1e-3, 'nanometer': 1e-3, 'nanometre': 1e-3,
    'mm': 1e3, 'millimeter': 1e3, 'millimetre': 1e3,
    'cm': 1e4, 'centimeter': 1e4, 'centimetre': 1e4,
    'm': 1e6, 'meter': 1e6, 'metre': 1e6,
    'inch': 25400.0, 'in': 25400.0,
}


def _length_unit(pixel_sizes):
    """The 'unit' of a pixel-size dict, or None."""
    if isinstance(pixel_sizes, dict):
        unit = pixel_sizes.get('unit')
        if isinstance(unit, str) and unit.strip():
            return unit.strip()
    return None

import anywidget
import traitlets
import matplotlib
import matplotlib.pyplot as plt
import numpy as np
import io
import base64
from matplotlib import gridspec

from scipy import ndimage as ndi
from matplotlib.colors import PowerNorm, to_rgb, LinearSegmentedColormap
import matplotlib.colors as mcolors
from matplotlib.figure import Figure

# The widget assets sit next to this module; resolving them from __file__ (not
# importlib.resources("eigenp_utils")) also works when the file runs standalone.
_ASSET_DIR = pathlib.Path(__file__).resolve().parent


class _PanelRotation:
    """
    Geometry of one rotated 2D panel, shared by the image resampling, the
    crosshairs and the click/hover inverse so all three agree exactly.

    A panel of ``shape`` (H, W) with pixel sizes ``(s_h, s_w)`` is displayed
    with pixel (r, c) centred at physical ``((c + 0.5) * s_w, (r + 0.5) * s_h)``.
    Rotation happens in physical space, counter-clockwise on screen (y down),
    about the centre of the panel. The rotated canvas has isotropic pixels of
    size ``p``; for isotropic input ``p`` equals the input pixel size and the
    result is identical to ``skimage.transform.rotate(resize=True)``.
    """

    def __init__(self, shape, angle_deg, s_h=1.0, s_w=1.0):
        H, W = int(shape[0]), int(shape[1])
        s_h, s_w = float(s_h), float(s_w)
        self.angle = float(angle_deg) if angle_deg else 0.0
        self.in_shape = (H, W)
        self.cx, self.cy = W * s_w / 2.0, H * s_h / 2.0
        if self.angle == 0.0:
            self.out_shape = (H, W)
            self.p_out = (s_h, s_w)
            return
        theta = np.deg2rad(self.angle)
        self.c, self.s = c, s = np.cos(theta), np.sin(theta)

        if s_h == s_w:
            # skimage's canvas: the rotated outermost pixel centres plus one pixel
            p = s_h
            hx, hy = (W - 1) / 2.0 * s_w, (H - 1) / 2.0 * s_h
            dx = np.array([-hx, -hx, hx, hx])
            dy = np.array([-hy, hy, hy, -hy])
            rx, ry = c * dx + s * dy, -s * dx + c * dy
            minx, miny = rx.min(), ry.min()
            self.out_shape = (int(np.around((ry.max() - miny) / p + 1)), int(np.around((rx.max() - minx) / p + 1)))
        else:
            # Anisotropic: resample onto the finer pixel size, capped at ~4x the
            # input pixel count, on a canvas holding the whole rotated physical box.
            ex = abs(c) * W * s_w + abs(s) * H * s_h
            ey = abs(s) * W * s_w + abs(c) * H * s_h
            p = max(min(s_h, s_w), np.sqrt(ex * ey / max(4 * H * W, 512 * 512)))
            out_w = max(1, int(np.ceil(ex / p - 1e-6)))
            out_h = max(1, int(np.ceil(ey / p - 1e-6)))
            self.out_shape = (out_h, out_w)
            minx, miny = -(out_w - 1) * p / 2.0, -(out_h - 1) * p / 2.0
        self.p_out = (p, p)
        # Output pixel (r, c) is centred at rotated offset (minx + c p, miny + r p)
        # from the panel centre, i.e. displayed at ((c + 0.5) p, (r + 0.5) p).
        self.offx, self.offy = 0.5 * p - minx, 0.5 * p - miny

        # Inverse map in (row, col) index order: input = M @ output + offset
        self.M = np.array([[c * p / s_h, s * p / s_h],
                           [-s * p / s_w, c * p / s_w]])
        self.offset = np.array([(s * minx + c * miny + self.cy) / s_h - 0.5,
                                (c * minx - s * miny + self.cx) / s_w - 0.5])

    def forward(self, x, y):
        """Unrotated physical (x, y) -> displayed physical (x, y)."""
        if self.angle == 0.0:
            return x, y
        dx, dy = np.asarray(x) - self.cx, np.asarray(y) - self.cy
        return (self.c * dx + self.s * dy + self.offx,
                -self.s * dx + self.c * dy + self.offy)

    def inverse(self, x, y):
        """Displayed physical (x, y) -> unrotated physical (x, y)."""
        if self.angle == 0.0:
            return x, y
        dx, dy = np.asarray(x) - self.offx, np.asarray(y) - self.offy
        return (self.c * dx - self.s * dy + self.cx,
                self.s * dx + self.c * dy + self.cy)

    def warp(self, image, order=3, cval=0.0):
        """Resample a 2D or channels-last image onto the rotated canvas (corners filled with ``cval``)."""
        image = np.asarray(image)
        if self.angle == 0.0:
            return image
        if not np.issubdtype(image.dtype, np.floating):
            image = image.astype(np.float64)

        def _warp(plane):
            finite = np.isfinite(plane)
            all_finite = finite.all()
            src = plane if all_finite else np.where(finite, plane, 0.0)
            out = ndi.affine_transform(src, self.M, offset=self.offset, output_shape=self.out_shape,
                                       order=order, mode='grid-constant', cval=cval)
            if order > 1 and src.size:
                out = np.clip(out, min(src.min(), cval), max(src.max(), cval))
            if not all_finite:
                # Keep non-finite pixels local instead of letting the spline
                # spread one NaN over the whole panel.
                bad = ndi.affine_transform((~finite).astype(np.float64), self.M, offset=self.offset,
                                           output_shape=self.out_shape, order=1,
                                           mode='grid-constant', cval=0.0)
                out[bad > 0.5] = np.nan
            return out

        if image.ndim == 2:
            return _warp(image)
        return np.stack([_warp(image[..., k]) for k in range(image.shape[-1])], axis=-1)


def _rotate_expand(image, angle_deg, order=3, pixel_size=None):
    """
    Rotate a 2D (H, W) or channels-last (H, W, C) image counter-clockwise by
    ``angle_deg`` about its centre, expanding the canvas to fit the result.

    Pure scipy replacement for
    ``skimage.transform.rotate(image, angle_deg, resize=True, order=order, preserve_range=True)``:
    same output shape, rotation centre ``((W - 1) / 2, (H - 1) / 2)``, zero fill
    and clipping of spline overshoot to the input range. Non-finite pixels stay
    local (NaN in the output) instead of spreading through the spline.

    ``pixel_size=(s_h, s_w)`` rotates in physical space instead; the output then
    has isotropic pixels (see ``_PanelRotation``).
    """
    s_h, s_w = (1.0, 1.0) if pixel_size is None else pixel_size
    return _PanelRotation(np.shape(image)[:2], angle_deg, s_h, s_w).warp(image, order=order)


class _PointRotation:
    """Rotation of scatter points about (cx, cy); same interface as ``_PanelRotation``."""

    def __init__(self, angle_deg, cx, cy):
        self.angle, self.cx, self.cy = float(angle_deg or 0.0), cx, cy

    def forward(self, x, y):
        return _rotate_points_2d(x, y, self.angle, self.cx, self.cy)

    def inverse(self, x, y):
        return _rotate_points_2d(x, y, -self.angle, self.cx, self.cy)


def _rotate_points_2d(px, py, angle_deg, cx, cy):
    """Rotate points about (cx, cy) with the same on-screen sense as ``_rotate_expand``."""
    if angle_deg == 0:
        return px, py
    theta = np.radians(angle_deg)
    cos_t = np.cos(theta)
    sin_t = np.sin(theta)
    rx = cos_t * (px - cx) + sin_t * (py - cy) + cx
    ry = -sin_t * (px - cx) + cos_t * (py - cy) + cy
    return rx, ry


def _unrotate_2d(phys_x, phys_y, angle_deg, orig_dim_x, orig_dim_y, sx, sy):
    """
    Unrotates physical coordinate (phys_x, phys_y) on a rotated 2D view back to
    the original unrotated physical space.
    """
    if angle_deg == 0.0 or angle_deg is None:
        return phys_x, phys_y
    return _PanelRotation((orig_dim_y, orig_dim_x), angle_deg, sy, sx).inverse(phys_x, phys_y)


def _get_rotated_line(x0, y0, x1, y1, angle_deg, orig_dim_w, orig_dim_h, s_w, s_h):
    """
    Transforms a 2D line segment (x0,y0)->(x1,y1) in physical space through 2D rotation.
    """
    if angle_deg == 0.0 or angle_deg is None:
        return [x0, x1], [y0, y1]
    g = _PanelRotation((orig_dim_h, orig_dim_w), angle_deg, s_h, s_w)
    rx, ry = g.forward(np.array([x0, x1], dtype=float), np.array([y0, y1], dtype=float))
    return [float(rx[0]), float(rx[1])], [float(ry[0]), float(ry[1])]


def _parse_rotate_view(val):
    """rotate_view -> (rot_z, rot_y, rot_x) in degrees (XY, XZ and ZY panels)."""
    if val is None:
        return 0.0, 0.0, 0.0
    if isinstance(val, (int, float)):
        return float(val), 0.0, 0.0
    try:
        val_list = list(val)
        if len(val_list) == 3:
            return float(val_list[0]), float(val_list[1]), float(val_list[2])
    except TypeError:
        pass
    raise ValueError(f"rotate_view must be a float or a tuple of 3 floats (Z, Y, X), got {val}")


_DEFAULT_CHANNEL_COLORS = ['white', 'lime', 'magenta', 'yellow', 'cyan', 'red', 'blue']
# With blending='minimum' each channel runs from white (low) to its colour (high),
# so the defaults are the complements of the additive defaults ("inks" on paper):
# the composite then looks like an inverted additive composite.
_DEFAULT_INVERTED_CHANNEL_COLORS = ['black', 'magenta', 'lime', 'blue', 'red', 'cyan', 'yellow']

# Channel compositing modes (napari names; 'add'/'max'/'min' accepted as aliases).
_BLENDING_MODES = ('additive', 'maximum', 'screen', 'minimum')
_BLENDING_ALIASES = {'add': 'additive', 'max': 'maximum', 'min': 'minimum'}
# Slab projections (napari's volume rendering modes, applied along the view axis).
_PROJECTIONS = ('mip', 'minip', 'average', 'attenuated_mip')


def _check_blending(blending):
    """Canonical blending name, or None for each function's historical default."""
    if blending is None:
        return None
    b = _BLENDING_ALIASES.get(blending, blending)
    if b not in _BLENDING_MODES:
        raise ValueError(f"blending must be one of {_BLENDING_MODES} (or None), got {blending!r}")
    return b


def _check_projection(projection, attenuation=0.05):
    """Canonical projection name ('mip' for None) after validating ``attenuation``."""
    p = 'mip' if projection is None else projection
    if p not in _PROJECTIONS:
        raise ValueError(f"projection must be one of {_PROJECTIONS} (or None), got {projection!r}")
    if not (np.isfinite(attenuation) and attenuation >= 0):
        raise ValueError(f"attenuation must be a finite number >= 0, got {attenuation!r}")
    return p


def _channel_colormaps(colormap, n, blending=None):
    """
    Normalise a per-channel colormap argument to a list of length ``n``.

    A single string or colour tuple applies to the first channel; missing
    entries are filled with the default channel colours not already used
    (the inverted defaults for ``blending='minimum'``).
    """
    defaults = _DEFAULT_INVERTED_CHANNEL_COLORS if blending == 'minimum' else _DEFAULT_CHANNEL_COLORS
    if colormap is None:
        given = []
    elif isinstance(colormap, str) or (isinstance(colormap, tuple) and mcolors.is_color_like(colormap)):
        given = [colormap]
    else:
        given = list(colormap)
    fill = [c for c in defaults if not any(c is g or (isinstance(g, str) and c == g) for g in given)]
    fill = fill or defaults
    return given[:n] + [fill[i % len(fill)] for i in range(max(0, n - len(given)))]

def is_colormap(c):
    """
    Checks if a string is a valid matplotlib colormap name.
    """
    if not isinstance(c, str):
        return False
    try:
        matplotlib.colormaps[c]
        return True
    except (ValueError, KeyError):
        return False

def _gui_channel_color(c, blending=None):
    """GUI colour for a channel; dark inks of minimum blending are lifted to stay readable in the dark GUI."""
    col = get_gui_channel_color(c)
    if blending == 'minimum':
        try:
            r, g, b = mcolors.to_rgb(col)
        except (ValueError, TypeError):
            return col
        if 0.2126 * r + 0.7152 * g + 0.0722 * b < 0.2:
            return '#9e9e9e'
    return col


def get_gui_channel_color(c):
    """
    Darkens a given color to improve contrast for GUI elements like channel labels and histograms.
    Converts color to RGB, multiplies by 0.75, and returns a hex string.
    """
    try:
        rgb = mcolors.to_rgb(resolve_color(c))
        darkened_rgb = tuple(val * 0.75 for val in rgb)
        return mcolors.to_hex(darkened_rgb)
    except (ValueError, TypeError):
        return resolve_color(c)

def resolve_color(c):
    """
    Attempts to resolve a string to a valid matplotlib color.
    If it is a valid colormap name, it returns the final color (at 1.0) of that colormap.
    """
    if isinstance(c, mcolors.Colormap):
        raise TypeError(
            f"Expected a registered colormap name or color as a string (e.g., 'viridis' or 'red'), "
            f"but got a Colormap instance: {c}. Please pass the string name of the registered colormap."
        )

    if not isinstance(c, str):
        return c

    if is_colormap(c):
        cmap = matplotlib.colormaps[c]
        return mcolors.to_hex(cmap(1.0)[:3])  # Get hex of final color

    try:
        # Check if it's already a valid color name or hex
        to_rgb(c)
        return c
    except ValueError:
        pass

    return c

def _norm(arr, symmetric=False, eps=1e-12, dtype=np.float32):
    a = arr.astype(dtype, copy=False)
    if symmetric:
        d = max(eps, float(np.abs(a).max()))
    else:
        d = max(eps, float(a.max()))
    return a / d


# Copyright tnia 2021 - BSD License
def show_zyx_slice(image_to_show, x, y, z, pixel_sizes=None, figsize=(10,10), colormap=None, vmin = None, vmax=None, gamma = 1, use_plt=True, opacity=None):
    """ extracts xy, xz, and zy slices at x, y, z of a 3D image and plots them

    Args:
        image_to_show (3d numpy array): image to plot
        x (int): x position of slice
        y (int): y position of slice
        z (int): z position of slice
        pixel_sizes (tuple or dict, optional): pixel sizes of 3D in physical units. Defaults to None.
        figsize (tuple, optional): figure size. Defaults to (10,10).
        colormap (_type_, optional): _description_. Defaults to None.
        vmax (float, optional): maximum value for display range. Defaults to None.
    """

    slice_zy = np.flip(np.rot90(image_to_show[:,:,x],1),0)
    slice_xz = image_to_show[:,y,:]
    slice_xy = image_to_show[z,:,:]

    return show_zyx(slice_xy, slice_xz, slice_zy, pixel_sizes=pixel_sizes, figsize=figsize, colormap=colormap, vmax=vmax, vmin=vmin, gamma=gamma, use_plt=use_plt, opacity=opacity)

# Copyright tnia 2021 - BSD License
def show_zyx_max(image_to_show, pixel_sizes=None, figsize=(10,10), colormap=None, vmin = None, vmax=None, gamma = 1, colors = None, opacity = None, blending=None, projection=None, attenuation=0.05):
    """ plots max xy, xz, and zy projections of a 3D image

    Args:
        image_to_show (3d numpy array): image to plot
        pixel_sizes (tuple or dict, optional): pixel sizes in physical units. Defaults to None.
        figsize (tuple, optional): figure size. Defaults to (10,10).
        colormap (_type_, optional): _description_. Defaults to None.
        vmax (float, optional): maximum value for display range. Defaults to None.
        blending (str, optional): channel compositing mode, see `show_zyx`.
        projection (str, optional): how each slab is projected along the view
            axis (napari's rendering names): 'mip' (maximum, the default),
            'minip' (minimum), 'average', or 'attenuated_mip'. None uses
            ``projector``.
        attenuation (float, optional): for 'attenuated_mip', the attenuation per
            voxel along the ray (napari's default 0.05). Rays enter each slab at
            its lowest index (z = start for XY, y = start for XZ, x = start for
            ZY); samples are normalised with the display range (vmin/vmax, or
            the channel's default range), so bright structures hide dimmer ones
            behind them.
    """
    if colors is not None:
        warnings.warn("The 'colors' parameter is deprecated and will be removed. Use 'colormap' instead.", DeprecationWarning, stacklevel=2)
        if colormap is None:
            colormap = colors

    return show_zyx_projection(image_to_show, pixel_sizes=pixel_sizes, figsize=figsize, projector=np.max, colormap=colormap, vmax=vmax, vmin = vmin, gamma = gamma, colors = None, opacity = opacity, blending=blending, projection=projection, attenuation=attenuation)


def show_zyx_projection(image_to_show, pixel_sizes=None, figsize=(10,10), projector=np.max, colormap=None, vmin = None, vmax=None, gamma = 1, colors = None, opacity = None, blending=None, projection=None, attenuation=0.05):
    """ generates xy, xz, and zy max projections of a 3D image and plots them

    Args:
        image_to_show (3d numpy array, or a list of them for channels): image to plot
        pixel_sizes (tuple or dict, optional): pixel sizes in physical units. Defaults to None.
        figsize (tuple): size of figure to
        projector: function to project with
        colormap (_type_, optional): _description_. Defaults to None.
        vmax (float, optional): maximum value for display range. Defaults to None.
        blending (str, optional): channel compositing mode, see `show_zyx`.
        projection (str, optional): how each slab is projected along the view
            axis (napari's rendering names): 'mip' (maximum, the default),
            'minip' (minimum), 'average', or 'attenuated_mip'. None uses
            ``projector``.
        attenuation (float, optional): for 'attenuated_mip', the attenuation per
            voxel along the ray (napari's default 0.05). Rays enter each slab at
            its lowest index (z = start for XY, y = start for XZ, x = start for
            ZY); samples are normalised with the display range (vmin/vmax, or
            the channel's default range), so bright structures hide dimmer ones
            behind them.
    """
    if colors is not None:
        warnings.warn("The 'colors' parameter is deprecated and will be removed. Use 'colormap' instead.", DeprecationWarning, stacklevel=2)
        if colormap is None:
            colormap = colors
    full = slice(None)
    return show_zyx_projection_slabs(image_to_show, full, full, full, pixel_sizes=pixel_sizes, figsize=figsize, projector=projector, colormap=colormap, vmax=vmax, vmin=vmin, gamma=gamma, colors=None, opacity=opacity, blending=blending, projection=projection, attenuation=attenuation)

# Copyright tnia 2021 - BSD License
def show_zyx(xy, xz, zy, pixel_sizes=None, figsize=(10,10), colormap=None, vmin=None, vmax=None, gamma=1, use_plt=True, colors=None, opacity=None, subplot_bg=None, rotate_view=None, channel_labels=None, channel_label_fontsize_pt=None, gap_in=1.0/16.0, channel_label_colors=None, pixel_sizes_given=None, blending=None):
    """ shows pre-computed xy, xz and zy of a 3D image in a plot

    Args:
        xy (2d numpy array): xy projection
        xz (2d numpy array): xz projection
        zy (2d numpy array): zy projection
        pixel_sizes (tuple or dict, optional): pixel sizes in physical units. Defaults to None.
        figsize (tuple, optional): figure size. Defaults to (10,10).
        colormap (_type_, optional): _description_. Defaults to None.
        vmin, vmax (float, optional): display range. For a single channel, a
            bound left as None is computed once over all three panels, so the
            panels share one intensity scale.
        rotate_view (float or (Z, Y, X) tuple, optional): rotates the XY, XZ and
            ZY panels counter-clockwise (degrees) in physical space; rotated
            panels are resampled onto isotropic pixels.
        channel_label_colors (list, optional): label colours, overriding the
            ones derived from ``colormap`` (for pre-composited RGB input).
        pixel_sizes_given (bool, optional): whether the scale bar shows physical
            units; defaults to ``pixel_sizes is not None``.
        blending (str, optional): how channels are composited (napari's names):
            'additive', 'maximum', 'screen' or 'minimum'. None (default) keeps
            the historical behaviour: additive for colour names, maximum when a
            channel is a colormap name. 'minimum' keeps the per-RGB minimum of
            the channels, each drawn from white (low) to its colour (high), or
            with an inverted colormap such as 'Blues' or 'Greys': it gives a
            multichannel image on a white background, and the panels, rotation
            padding and scale bar switch to a white theme. For a single channel
            or pre-composited RGB input only the white theme (and white->colour
            colormap) applies.
    Returns:
        matplotlib Figure with named axes ``axXY``, ``axZY``, ``axXZ``, ``axBar``.
    """
    if figsize is None:
        figsize = (10, 10)
    blending = _check_blending(blending)
    white_theme = blending == 'minimum'
    if white_theme and subplot_bg is None:
        subplot_bg = 'white'
    # Value used for the corners that rotation adds to a panel
    pad_value = 0.0

    if colors is not None:
        warnings.warn("The 'colors' parameter is deprecated and will be removed. Use 'colormap' instead.", DeprecationWarning, stacklevel=2)
        if colormap is None:
            colormap = colors

    pz, py, px = _parse_zyx_tuple_or_dict(pixel_sizes, default_val=1.0)
    both_given = (pixel_sizes is not None) if pixel_sizes_given is None else bool(pixel_sizes_given)

    if isinstance(xy, list):
        colormap = _channel_colormaps(colormap, len(xy), blending)

    # Preserve original colormap reference before resetting colormap=None for RGB arrays
    orig_colormap = colormap

    if isinstance(xy, list):
        has_colormap = any(is_colormap(c) for c in colormap)

        if has_colormap:
            xy, xz, zy = create_multichannel_rgb_cmap(
                xy, xz, zy, vmin=vmin, vmax=vmax, gamma=gamma, colormap=colormap, opacity=opacity,
                blend=blending or 'maximum',
            )
        else:
            xy, xz, zy = create_multichannel_rgb(
                xy, xz, zy, vmin=vmin, vmax=vmax, gamma=gamma, colormap=colormap, opacity=opacity,
                blend=blending or 'additive',
            )

        colormap = None
        vmin, vmax, gamma = None, None, 1
        opacity = None
        if white_theme:
            pad_value = 1.0
    else:
        if isinstance(opacity, list):
            # Opacity of a pre-composited RGB(A) image is already baked in;
            # applying channel 0's value would fade every channel.
            opacity = None if np.ndim(xy) == 3 else opacity[0]
        if isinstance(vmin, list):
            vmin = vmin[0]
        if isinstance(vmax, list):
            vmax = vmax[0]
        if isinstance(gamma, list):
            gamma = gamma[0]

        if np.ndim(xy) == 2 and (vmin is None or vmax is None):
            # One intensity scale for all three panels (computed before
            # rotation, which pads the canvas with zeros).
            finite = [np.asarray(a, dtype=float) for a in (xy, xz, zy)]
            finite = [a[np.isfinite(a)] for a in finite]
            finite = [a for a in finite if a.size]
            if finite:
                if vmin is None:
                    vmin = float(min(a.min() for a in finite))
                if vmax is None:
                    vmax = float(max(a.max() for a in finite))

        if isinstance(colormap, list) and len(colormap) == 1:
            colormap = colormap[0]

        # A plain colour is drawn black -> colour (white -> colour for minimum blending)
        to_cmap = white_to if white_theme else black_to
        if colormap is None and white_theme and np.ndim(xy) == 2:
            colormap = _DEFAULT_INVERTED_CHANNEL_COLORS[0]
            orig_colormap = colormap
        if colormap is not None:
            c = colormap
            if isinstance(c, str):
                try:
                    matplotlib.colormaps[c]
                except (ValueError, KeyError):
                    resolved = resolve_color(c)
                    colormap = to_cmap(resolved)
            else:
                resolved = resolve_color(c)
                colormap = to_cmap(resolved)

        if white_theme:
            # Corners added by rotation take the colour of the low end of the range
            pad_value = 1.0 if np.ndim(xy) == 3 else (vmin if vmin is not None else 0.0)

    rot_z, rot_y, rot_x = _parse_rotate_view(rotate_view)

    # Physical extent of each panel: (row pixel size, column pixel size).
    # Rotation happens in physical space, so a rotated panel has isotropic pixels.
    g_xy = _PanelRotation(np.shape(xy)[:2], rot_z, py, px)
    g_xz = _PanelRotation(np.shape(xz)[:2], rot_y, pz, px)
    g_zy = _PanelRotation(np.shape(zy)[:2], rot_x, py, pz)
    xy, xz, zy = g_xy.warp(xy, cval=pad_value), g_xz.warp(xz, cval=pad_value), g_zy.warp(zy, cval=pad_value)
    (sxy_h, sxy_w), (sxz_h, sxz_w), (szy_h, szy_w) = g_xy.p_out, g_xz.p_out, g_zy.p_out

    if use_plt:
        fig = plt.figure(figsize=figsize, constrained_layout=False)
    else:
        fig = Figure(figsize=figsize, constrained_layout=False)

    figW, figH = figsize

    xy_w, xy_h = xy.shape[1] * sxy_w, xy.shape[0] * sxy_h
    xz_w, xz_h = xz.shape[1] * sxz_w, xz.shape[0] * sxz_h
    zy_w, zy_h = zy.shape[1] * szy_w, zy.shape[0] * szy_h

    col1_w = max(xy_w, xz_w)
    col2_w = zy_w
    row1_h = max(xy_h, zy_h)
    row2_h = xz_h
    fig_h_in = figH
    fontsize_pt = max(10, min(24, fig_h_in * 72 * 0.035))
    if channel_label_fontsize_pt is None:
        channel_label_fontsize_pt = fontsize_pt

    hl_in = (0.10 + (channel_label_fontsize_pt / 72.0)) if channel_labels is not None else 0.0

    margin_in = 0.05
    avail_w_in = figW - gap_in - 2.0 * margin_in
    num_v_gaps = 2 if channel_labels is not None else 1
    avail_h_in = figH - num_v_gaps * gap_in - 2.0 * margin_in - hl_in
    total_unscaled_h = row1_h + row2_h

    scale = min(avail_w_in / max(col1_w + col2_w, 1e-6), avail_h_in / max(total_unscaled_h, 1e-6))

    w1_in = col1_w * scale
    w2_in = col2_w * scale
    h1_in = row1_h * scale
    h2_in = row2_h * scale

    block_w_in = w1_in + gap_in + w2_in
    block_h_in = h1_in + gap_in + h2_in + (hl_in + gap_in if channel_labels is not None else 0.0)

    left_margin_in = (figW - block_w_in) / 2.0
    bottom_margin_in = (figH - block_h_in) / 2.0

    x0_frac = left_margin_in / figW
    w1_frac = w1_in / figW
    gap_w_frac = gap_in / figW
    w2_frac = w2_in / figW

    x_col1 = x0_frac
    x_col2 = x0_frac + w1_frac + gap_w_frac

    y0_frac = bottom_margin_in / figH
    h2_frac = h2_in / figH
    gap_h_frac = gap_in / figH
    h1_frac = h1_in / figH
    hl_frac = hl_in / figH

    y_row2 = y0_frac
    y_row1 = y0_frac + h2_frac + gap_h_frac

    axLabels = None
    if channel_labels is not None:
        y_labels = y_row1 + h1_frac + gap_h_frac
        axLabels = fig.add_axes([x_col1, y_labels, w1_frac, hl_frac])
        axXY = fig.add_axes([x_col1, y_row1, w1_frac, h1_frac])
        axZY = fig.add_axes([x_col2, y_row1, w2_frac, h1_frac])
        axXZ = fig.add_axes([x_col1, y_row2, w1_frac, h2_frac])
        axBar = fig.add_axes([x_col2, y_row2, w2_frac, h2_frac])

        axLabels.patch.set_visible(False)
        axLabels.set_xticks([])
        axLabels.set_yticks([])
        for spine in axLabels.spines.values():
            spine.set_visible(False)

        bar_linewidth = max(1.0, channel_label_fontsize_pt * 0.15)
        axLabels.plot([0, 1], [0, 0], transform=axLabels.transAxes, color=(0.85, 0.85, 0.85), linewidth=bar_linewidth, clip_on=False)

        n_labels = len(channel_labels)
        if n_labels > 0:
            def _get_color_str(c):
                if isinstance(c, mcolors.Colormap):
                    return mcolors.to_hex(c(1.0)[:3])
                return resolve_color(c)

            if channel_label_colors is not None:
                color_list = [_get_color_str(c) for c in channel_label_colors]
            elif orig_colormap is None:
                color_list = ['black']
            elif isinstance(orig_colormap, (str, mcolors.Colormap)) or (isinstance(orig_colormap, tuple) and mcolors.is_color_like(orig_colormap)):
                color_list = [_get_color_str(orig_colormap)]
            else:
                color_list = [_get_color_str(c) for c in orig_colormap]
            color_list = color_list or ['black']
            if len(color_list) < n_labels:
                color_list = color_list * (n_labels // len(color_list) + 1)

            from matplotlib.offsetbox import TextArea, HPacker, AnchoredOffsetbox

            text_areas = []
            for i, label in enumerate(channel_labels):
                GUI_CHANNEL_COLOR = get_gui_channel_color(color_list[i])
                ta = TextArea(label, textprops=dict(color=GUI_CHANNEL_COLOR, fontsize=channel_label_fontsize_pt, fontweight='bold'))
                text_areas.append(ta)

            packer = HPacker(children=text_areas, align="center", pad=0, sep=10)
            anchored_box = AnchoredOffsetbox(
                loc='lower center', child=packer, pad=0.0, frameon=False, borderpad=0.0,
                bbox_to_anchor=(0.5, 0.2), bbox_transform=axLabels.transAxes
            )
            axLabels.add_artist(anchored_box)
    else:
        axXY = fig.add_axes([x_col1, y_row1, w1_frac, h1_frac])
        axZY = fig.add_axes([x_col2, y_row1, w2_frac, h1_frac])
        axXZ = fig.add_axes([x_col1, y_row2, w1_frac, h2_frac])
        axBar = fig.add_axes([x_col2, y_row2, w2_frac, h2_frac])

    if gamma == 1:
        axXY.imshow(xy, cmap=colormap, vmin=vmin, vmax=vmax, extent=[0, xy_w, xy_h, 0], interpolation='nearest', alpha=opacity)
        axZY.imshow(zy, cmap=colormap, vmin=vmin, vmax=vmax, extent=[0, zy_w, zy_h, 0], interpolation='nearest', alpha=opacity)
        axXZ.imshow(xz, cmap=colormap, vmin=vmin, vmax=vmax, extent=[0, xz_w, xz_h, 0], interpolation='nearest', alpha=opacity)
    else:
        norm = PowerNorm(gamma=gamma, vmin=vmin, vmax=vmax, clip=True)
        axXY.imshow(xy, cmap=colormap, norm=norm, extent=[0, xy_w, xy_h, 0], interpolation='nearest', alpha=opacity)
        axZY.imshow(zy, cmap=colormap, norm=norm, extent=[0, zy_w, zy_h, 0], interpolation='nearest', alpha=opacity)
        axXZ.imshow(xz, cmap=colormap, norm=norm, extent=[0, xz_w, xz_h, 0], interpolation='nearest', alpha=opacity)

    axXY.set_xlim([0, xy_w]); axXY.set_ylim([xy_h, 0])
    axZY.set_xlim([0, zy_w]); axZY.set_ylim([zy_h, 0])
    axXZ.set_xlim([0, xz_w]); axXZ.set_ylim([xz_h, 0])

    for i, ax in enumerate([axXY, axZY, axXZ, axBar]):
        if i < 3 and subplot_bg is not None:
            ax.set_facecolor(subplot_bg)
        elif ax == axBar:
            ax.patch.set_visible(False)

        ax.set_xticks([])
        ax.set_yticks([])
        for spine in ax.spines.values():
            spine.set_visible(False)

    if white_theme:
        fig.patch.set_facecolor('white')  # the gaps between panels belong to the white canvas
    else:
        fig.patch.set_alpha(0.0)  # set transparent bgnd

    _add_scale_bar(axXY, axBar, xy_w, both_given, figsize, unit=_length_unit(pixel_sizes),
                   color='black' if white_theme else 'white')

    fig.axXY = axXY
    fig.axZY = axZY
    fig.axXZ = axXZ
    fig.axBar = axBar
    fig.axLabels = axLabels

    fig.canvas.draw()
    return fig

def _add_scale_bar(ax_line, ax_text, ax_physical_width_um, pixel_sizes_given, figsize, unit=None, color='white'):
    # ``ax_physical_width_um`` is in the units of the pixel sizes: ``unit``
    # (a pixel-size dict's 'unit'; µm when None). Known length units are
    # converted so the bar is labelled in µm; an unknown unit is shown as is.
    unit_label = 'µm'
    if unit is not None:
        factor = _UNIT_TO_UM.get(unit.lower())
        if factor is None:
            unit_label = unit
        else:
            ax_physical_width_um = ax_physical_width_um * factor

    # a small utility to pick the largest "nice" number ≤ target
    target = ax_physical_width_um * 0.2

    def nice_length(x):
        # get exponent
        if x <= 0: return 1
        exp = np.floor(np.log10(x))
        # candidates: 1, 2, 5 times 10^exp
        for m in [5, 2, 1]:
            val = m * 10**exp
            if val <= x:
                return val
        # if nothing smaller (very small x), just return x itself
        return x

    bar_um = nice_length(target)
    # Convert back to fraction of the full width of the current axes
    bar_frac = bar_um / ax_physical_width_um if ax_physical_width_um > 0 else 0

    # pick fontsize and line width to scale with figure size
    fig_h_in = figsize[1] if figsize is not None else 10
    fontsize_pt = max(8, min(24, fig_h_in * 72 * 0.03))
    linewidth = max(1, fig_h_in * 0.2)

    ### Draw
    # Put the line at the bottom right of ax_line
    x1 = 0.95
    x0 = x1 - bar_frac
    y_line = 0.05

    ax_line.hlines(y_line, x0, x1, transform=ax_line.transAxes, linewidth=linewidth, color=color, clip_on=False)

    if pixel_sizes_given:
        text_label = f"{int(bar_um)} {unit_label}" if bar_um >= 1 else f"{bar_um:.2g} {unit_label}"
    else:
        text_label = "`pixel_sizes`"

    # Put the text centered in ax_text
    ax_text.text(0.5, 0.5, text_label, transform=ax_text.transAxes, clip_on=False,
            ha='center', va='center', color='gray', fontsize=fontsize_pt)

### New function
def show_zyx_max_slabs(image_to_show, x=[0,1], y=[0,1], z=[0,1], pixel_sizes=None, figsize=(10,10), colormap=None, vmin=None, vmax=None, gamma=1, colors=None, opacity=None, rotate_view=None, channel_labels=None, channel_label_fontsize_pt=None, blending=None, projection=None, attenuation=0.05):
    """ plots max xy, xz, and zy projections of a 3D image SLABS (slice intervals)

    Author: PanosOik https://github.com/PanosOik

    Args:
        image_to_show (3d numpy array): image to plot
        x: slices for x in format [x_1, x_2] where values are integers, to be passed as slice(x_1, x_2, None)
        y: slices for y in format [y_1, y_2] where values are integers
        z: slices for z in format [z_1, z_2] where values are integers
        pixel_sizes (tuple or dict, optional): pixel sizes in physical units. Defaults to None.
        figsize (tuple, optional): figure size. Defaults to (10,10).
        colormap (_type_, optional): _description_. Defaults to None.
        vmax (float, optional): maximum value for display range. Defaults to None.
        blending (str, optional): channel compositing mode, see `show_zyx`.
        projection (str, optional): how each slab is projected along the view
            axis (napari's rendering names): 'mip' (maximum, the default),
            'minip' (minimum), 'average', or 'attenuated_mip'. None uses
            ``projector``.
        attenuation (float, optional): for 'attenuated_mip', the attenuation per
            voxel along the ray (napari's default 0.05). Rays enter each slab at
            its lowest index (z = start for XY, y = start for XZ, x = start for
            ZY); samples are normalised with the display range (vmin/vmax, or
            the channel's default range), so bright structures hide dimmer ones
            behind them.
    """
    if colors is not None:
        warnings.warn("The 'colors' parameter is deprecated and will be removed. Use 'colormap' instead.", DeprecationWarning, stacklevel=2)
        if colormap is None:
            colormap = colors

    ### Coerce into integers for slices, rounding floats and ensuring non-zero bounds
    x_ = [int(np.round(float(i))) for i in x]
    y_ = [int(np.round(float(i))) for i in y]
    z_ = [int(np.round(float(i))) for i in z]

    if x_[1] <= x_[0]: x_[1] = x_[0] + 1
    if y_[1] <= y_[0]: y_[1] = y_[0] + 1
    if z_[1] <= z_[0]: z_[1] = z_[0] + 1

    x_slices = slice(*x_)
    y_slices = slice(*y_)
    z_slices = slice(*z_)

    return show_zyx_projection_slabs(image_to_show, x_slices, y_slices, z_slices, pixel_sizes=pixel_sizes, figsize=figsize, projector=np.max, colormap=colormap, vmax=vmax, vmin=vmin, gamma=gamma, colors=None, opacity=opacity, rotate_view=rotate_view, channel_labels=channel_labels, channel_label_fontsize_pt=channel_label_fontsize_pt, blending=blending, projection=projection, attenuation=attenuation)


### New function
def show_zyx_projection_slabs(image_to_show, x_slices, y_slices, z_slices, pixel_sizes=None, figsize=(10,10), projector=np.max, colormap=None, vmin = None, vmax=None, gamma = 1, colors = None, opacity = None, rotate_view=None, channel_labels=None, channel_label_fontsize_pt=None, blending=None, projection=None, attenuation=0.05):
    """ generates xy, xz, and zy max projections of a 3D image and plots them

    Author: PanosOik https://github.com/PanosOik

    Args:
        image_to_show (3d numpy array): image to plot
        pixel_sizes (tuple or dict, optional): pixel sizes in physical units. Defaults to None.
        figsize (tuple): size of figure to
        projector: function to project with (used when ``projection`` is None)
        colormap (_type_, optional): _description_. Defaults to None.
        vmax (float, optional): maximum value for display range. Defaults to None.
        blending (str, optional): channel compositing mode, see `show_zyx`.
        projection (str, optional): how each slab is projected along the view
            axis (napari's rendering names): 'mip' (maximum, the default),
            'minip' (minimum), 'average', or 'attenuated_mip'. None uses
            ``projector``.
        attenuation (float, optional): for 'attenuated_mip', the attenuation per
            voxel along the ray (napari's default 0.05). Rays enter each slab at
            its lowest index (z = start for XY, y = start for XZ, x = start for
            ZY); samples are normalised with the display range (vmin/vmax, or
            the channel's default range), so bright structures hide dimmer ones
            behind them.
    """
    if colors is not None:
        warnings.warn("The 'colors' parameter is deprecated and will be removed. Use 'colormap' instead.", DeprecationWarning, stacklevel=2)
        if colormap is None:
            colormap = colors
    if projection is not None:
        projection = _check_projection(projection, attenuation)

    def _projector(img, i):
        if projection is None:
            return projector
        lo = hi = None
        if projection == 'attenuated_mip':
            # Samples are normalised with the channel's display range
            lo = vmin[i] if isinstance(vmin, (list, tuple)) else vmin
            hi = vmax[i] if isinstance(vmax, (list, tuple)) else vmax
            lo = _default_vmin(img) if lo is None else float(lo)
            hi = _finite_max(img) if hi is None else float(hi)
            if hi is None or not hi > lo:
                hi = lo + 1.0
        return _projector_for(projection, attenuation, lo, hi)

    def _project(img, i):
        # Slicing creates a view. Some projectors might make copies. np.max over an axis
        # might allocate a temporary buffer if the memory is not contiguous in that axis.
        proj = _projector(img, i)
        return (proj(img[:, y_slices, :], axis=1),
                np.flip(np.rot90(proj(img[:, :, x_slices], axis=2), 1), 0),
                proj(img[z_slices, :, :], axis=0))

    if isinstance(image_to_show, list):
        projections = [_project(img, i) for i, img in enumerate(image_to_show)]
        projection_y = [p[0] for p in projections]
        projection_x = [p[1] for p in projections]
        projection_z = [p[2] for p in projections]
    else:
        projection_y, projection_x, projection_z = _project(image_to_show, 0)

    return show_zyx(projection_z, projection_y, projection_x, pixel_sizes=pixel_sizes, figsize=figsize, colormap=colormap, vmax=vmax, vmin=vmin, gamma=gamma, colors=None, opacity=opacity, rotate_view=rotate_view, channel_labels=channel_labels, channel_label_fontsize_pt=channel_label_fontsize_pt, blending=blending)


def _finite_min(*arrays):
    """Smallest finite value over several arrays (None if there is none)."""
    best = None
    for a in arrays:
        a = np.asarray(a)
        if a.size == 0:
            continue
        if np.issubdtype(a.dtype, np.floating):
            a = a[np.isfinite(a)]
            if a.size == 0:
                continue
        m = float(a.min())
        best = m if best is None else min(best, m)
    return best


def _default_vmin(*arrays):
    """0 (fluorescence convention), or the data minimum if the data go below 0."""
    m = _finite_min(*arrays)
    return 0.0 if m is None else min(0.0, m)


def _check_gammas(gammas):
    for g in gammas:
        if g is not None and not float(g) > 0:
            raise ValueError(f"gamma must be > 0, got {g}")


def _finite_max(*arrays):
    """Largest finite value over several arrays (None if there is none)."""
    best = None
    for a in arrays:
        a = np.asarray(a)
        if a.size == 0:
            continue
        if np.issubdtype(a.dtype, np.floating):
            a = a[np.isfinite(a)]
            if a.size == 0:
                continue
        m = float(a.max())
        best = m if best is None else max(best, m)
    return best


def _robust_vmax(arr, q=99.9, max_samples=1_000_000):
    """
    Default display maximum: the `q`-th percentile of the finite values.

    A few hot pixels, saturated debris or a single bright cell set the plain
    maximum and leave the rest of the image dark. The percentile is estimated
    on a fixed-seed random sample of at most `max_samples` values (a strided
    sample can alias with the image rows). When the signal is sparser than
    (100 - q)% of the voxels the percentile equals the background level; the
    plain maximum is used then. Integer images get an integer (rounded up).
    Returns None if there is no finite value.
    """
    arr = np.asarray(arr)
    hi = _finite_max(arr)
    if hi is None:
        return None
    flat = arr.ravel()
    if flat.size > max_samples:
        flat = flat[np.random.default_rng(0).integers(0, flat.size, max_samples)]
    if np.issubdtype(flat.dtype, np.floating):
        flat = flat[np.isfinite(flat)]
    if flat.size == 0:
        return hi
    v = float(np.percentile(flat, q))
    if not v > float(flat.min()):
        return hi
    if np.issubdtype(arr.dtype, np.integer):
        v = float(np.ceil(v))
    return min(v, hi)


def create_multichannel_rgb(
    xy_list, xz_list, zy_list,
    vmin=None, vmax=None, gamma=1, colormap=None, colors=None, opacity=None,
    blend='add',        # 'additive' | 'maximum' | 'screen' | 'minimum'
    soft_clip=True,     # only used for additive blending
    eps=1e-12,
):
    """
    Compose multi-channel XY/XZ/ZY into RGB with per-channel normalization.

    Parameters
    ----------
    xy_list, xz_list, zy_list : list[np.ndarray]
        One 2D array per channel for each orientation.
    vmin, vmax : float | list[float] | None
        Per-channel input range. If None, computed per channel across XY/XZ/ZY:
        vmin is 0, or the data minimum when the channel has negative values;
        vmax is the largest finite value. Scalars are broadcast to all channels.
    gamma : float | list[float]
        Power gamma applied AFTER linear [0,1] normalization (1 = linear).
    colors : list[str | tuple]
        One color per channel (default: ['magenta','cyan','yellow','green'][:n]).
    opacity : float | list[float] | None
        Opacity multiplier per channel (1 = full opacity).
    blend : str
        How channels combine: 'additive' (default; alias 'add'), 'maximum'
        (alias 'max'), 'screen', or 'minimum' (alias 'min'). With 'minimum'
        each channel is drawn from white (low) to its colour (high) and the
        per-RGB minimum is kept, giving a multichannel image on a white
        background; opacity fades a channel towards white.
    soft_clip : bool
        For additive blending, compress values >1 instead of hard clipping.
    """
    blend = _check_blending(blend) or 'additive'
    if colors is not None:
        warnings.warn("The 'colors' parameter is deprecated and will be removed. Use 'colormap' instead.", DeprecationWarning, stacklevel=2)
        if colormap is None:
            colormap = colors

    assert isinstance(xy_list, list) and isinstance(xz_list, list) and isinstance(zy_list, list)
    n = len(xy_list)
    assert len(xz_list) == n and len(zy_list) == n, "xy/xz/zy must have same number of channels"

    Hxy, Wxy = xy_list[0].shape
    Hxz, Wxz = xz_list[0].shape
    Hzy, Wzy = zy_list[0].shape

    # Prepare outputs
    xy_rgb = np.zeros((Hxy, Wxy, 3), dtype=np.float32)
    xz_rgb = np.zeros((Hxz, Wxz, 3), dtype=np.float32)
    zy_rgb = np.zeros((Hzy, Wzy, 3), dtype=np.float32)

    # Broadcast params
    gammas = (list(gamma) if isinstance(gamma, (list, tuple)) else [gamma] * n)
    _check_gammas(gammas)
    opacities = (list(opacity) if isinstance(opacity, (list, tuple)) else [opacity if opacity is not None else 1.0] * n)

    colormap = _channel_colormaps(colormap, n)
    color_map = [np.asarray(to_rgb(resolve_color(c)), dtype=np.float32) for c in colormap]

    # Determine per-channel vmin/vmax if not provided
    # vmin/vmax can be None, or a list containing floats and/or Nones
    if vmin is None:
        vmins = [None] * n
    else:
        vmins = list(vmin) if isinstance(vmin, (list, tuple)) else [vmin] * n

    if vmax is None:
        vmaxs = [None] * n
    else:
        vmaxs = list(vmax) if isinstance(vmax, (list, tuple)) else [vmax] * n

    for i in range(n):
        if vmins[i] is None:
            vmins[i] = _default_vmin(xy_list[i], xz_list[i], zy_list[i])
        else:
            vmins[i] = float(vmins[i])

        if vmaxs[i] is None:
            # max over 2D slices instead of concatenating; non-finite pixels
            # (masked or ratio images) must not set the display range
            vmaxs[i] = _finite_max(xy_list[i], xz_list[i], zy_list[i])
        else:
            vmaxs[i] = float(vmaxs[i])

    # Sanitize: ensure vmax > vmin
    for i in range(n):
        if not np.isfinite(vmins[i]): vmins[i] = 0.0
        if vmaxs[i] is None or not np.isfinite(vmaxs[i]): vmaxs[i] = vmins[i] + 1.0
        if vmaxs[i] <= vmins[i] + eps:
            vmaxs[i] = vmins[i] + 1.0  # avoid zero range

    # Choose blending accumulators
    if blend in ('screen', 'minimum'):
        xy_acc = np.ones_like(xy_rgb)
        xz_acc = np.ones_like(xz_rgb)
        zy_acc = np.ones_like(zy_rgb)
    else:
        xy_acc = xy_rgb
        xz_acc = xz_rgb
        zy_acc = zy_rgb

    # Helpers
    def _norm_window(a, lo, hi, g):
        # linear normalize to [0,1] then gamma
        out = (a.astype(np.float32, copy=False) - lo) / max(hi - lo, eps)
        out = np.nan_to_num(out, nan=0.0, posinf=0.0, neginf=0.0, copy=False)
        out = np.clip(out, 0.0, 1.0, out=out)
        if g != 1:
            out = np.power(out, g, out=out)
        return out

    # Per-channel accumulate
    for i, (xy, xz, zy) in enumerate(zip(xy_list, xz_list, zy_list)):
        c = color_map[i]  # (3,)
        g = gammas[i]
        o = opacities[i]
        lo, hi = vmins[i], vmaxs[i]

        if blend == 'minimum':
            # white -> colour, faded towards white by the opacity
            c_inv = (o * (1.0 - c)).astype(np.float32)
            xy_acc = np.minimum(xy_acc, 1.0 - _norm_window(xy, lo, hi, g)[..., None] * c_inv)
            xz_acc = np.minimum(xz_acc, 1.0 - _norm_window(xz, lo, hi, g)[..., None] * c_inv)
            zy_acc = np.minimum(zy_acc, 1.0 - _norm_window(zy, lo, hi, g)[..., None] * c_inv)
            continue

        # multiply by color * opacity
        c_o = (c * o).astype(np.float32)

        xy_n = _norm_window(xy, lo, hi, g)[..., None] * c_o  # (H,W,3)
        xz_n = _norm_window(xz, lo, hi, g)[..., None] * c_o
        zy_n = _norm_window(zy, lo, hi, g)[..., None] * c_o

        if blend == 'screen':
            xy_acc *= (1.0 - xy_n)
            xz_acc *= (1.0 - xz_n)
            zy_acc *= (1.0 - zy_n)
        elif blend == 'maximum':
            xy_acc = np.maximum(xy_acc, xy_n)
            xz_acc = np.maximum(xz_acc, xz_n)
            zy_acc = np.maximum(zy_acc, zy_n)
        else:  # 'add'
            xy_acc += xy_n
            xz_acc += xz_n
            zy_acc += zy_n

    # Finalize per blend
    if blend == 'screen':
        xy_rgb = 1.0 - xy_acc
        xz_rgb = 1.0 - xz_acc
        zy_rgb = 1.0 - zy_acc
    else:
        xy_rgb = xy_acc
        xz_rgb = xz_acc
        zy_rgb = zy_acc

        if blend == 'additive':
            if soft_clip:
                # compress highlights smoothly instead of hard clipping
                # scale by max component per-pixel if it exceeds 1
                for rgb in (xy_rgb, xz_rgb, zy_rgb):
                    m = rgb.max(axis=-1, keepdims=True)
                    scale = np.maximum(1.0, m)
                    rgb /= scale
            # ensure display-safe range
            xy_rgb = np.clip(xy_rgb, 0.0, 1.0)
            xz_rgb = np.clip(xz_rgb, 0.0, 1.0)
            zy_rgb = np.clip(zy_rgb, 0.0, 1.0)

    return xy_rgb, xz_rgb, zy_rgb

    # # return show_zyx(xy_rgb, xz_rgb, zy_rgb, vmin = None, vmax=None, gamma = 1, use_plt=True)
    # return xy_rgb, xz_rgb, zy_rgb

def create_multichannel_rgb_cmap(xy_list, xz_list, zy_list, vmin=None, vmax=None, gamma=1, colormap=None, colors=None, opacity=None, blend='max', soft_clip=True, eps=1e-12):
    """
    Like `create_multichannel_rgb`, but each channel may be a colormap name.

    Colormap names are applied as given; plain colours become black->colour
    colormaps (white->colour for ``blend='minimum'``, so that inverted colormaps
    such as 'Blues' or 'Greys' and plain colours compose on a white background).
    ``blend`` takes the same modes as `create_multichannel_rgb` and defaults to
    'maximum'.
    """
    blend = _check_blending(blend) or 'maximum'
    if colors is not None:
        warnings.warn("The 'colors' parameter is deprecated and will be removed. Use 'colormap' instead.", DeprecationWarning, stacklevel=2)
        if colormap is None:
            colormap = colors
    assert isinstance(xy_list, list) and isinstance(xz_list, list) and isinstance(zy_list, list)
    n = len(xy_list)
    assert len(xz_list) == n and len(zy_list) == n, "xy/xz/zy must have same number of channels"

    Hxy, Wxy = xy_list[0].shape
    Hxz, Wxz = xz_list[0].shape
    Hzy, Wzy = zy_list[0].shape

    xy_rgb = np.zeros((Hxy, Wxy, 3), dtype=np.float32)
    xz_rgb = np.zeros((Hxz, Wxz, 3), dtype=np.float32)
    zy_rgb = np.zeros((Hzy, Wzy, 3), dtype=np.float32)

    gammas = (list(gamma) if isinstance(gamma, (list, tuple)) else [gamma] * n)
    _check_gammas(gammas)
    opacities = (list(opacity) if isinstance(opacity, (list, tuple)) else [opacity if opacity is not None else 1.0] * n)

    colormap = _channel_colormaps(colormap, n)

    cmap_list = []
    for c in colormap:
        if is_colormap(c):
            cmap_list.append(matplotlib.colormaps[c])
        elif blend == 'minimum':
            cmap_list.append(white_to(resolve_color(c)))
        else:
            cmap_list.append(black_to(resolve_color(c)))

    if vmin is None:
        vmins = [None] * n
    else:
        vmins = list(vmin) if isinstance(vmin, (list, tuple)) else [vmin] * n

    if vmax is None:
        vmaxs = [None] * n
    else:
        vmaxs = list(vmax) if isinstance(vmax, (list, tuple)) else [vmax] * n

    for i in range(n):
        if vmins[i] is None:
            vmins[i] = _default_vmin(xy_list[i], xz_list[i], zy_list[i])
        else:
            vmins[i] = float(vmins[i])

        if vmaxs[i] is None:
            vmaxs[i] = _finite_max(xy_list[i], xz_list[i], zy_list[i])
        else:
            vmaxs[i] = float(vmaxs[i])

    for i in range(n):
        if not np.isfinite(vmins[i]): vmins[i] = 0.0
        if vmaxs[i] is None or not np.isfinite(vmaxs[i]): vmaxs[i] = vmins[i] + 1.0
        if vmaxs[i] <= vmins[i] + eps:
            vmaxs[i] = vmins[i] + 1.0

    if blend in ('screen', 'minimum'):
        xy_acc = np.ones_like(xy_rgb)
        xz_acc = np.ones_like(xz_rgb)
        zy_acc = np.ones_like(zy_rgb)
    else:
        xy_acc = xy_rgb
        xz_acc = xz_rgb
        zy_acc = zy_rgb

    def _norm_window(a, lo, hi, g):
        out = (a.astype(np.float32, copy=False) - lo) / max(hi - lo, eps)
        out = np.nan_to_num(out, nan=0.0, posinf=0.0, neginf=0.0, copy=False)
        out = np.clip(out, 0.0, 1.0, out=out)
        if g != 1:
            out = np.power(out, g, out=out)
        return out

    for i, (xy, xz, zy) in enumerate(zip(xy_list, xz_list, zy_list)):
        cmap = cmap_list[i]
        g = gammas[i]
        o = opacities[i]
        lo, hi = vmins[i], vmaxs[i]

        xy_n = cmap(_norm_window(xy, lo, hi, g), bytes=True)[..., :3].astype(np.float32) / 255.0
        xz_n = cmap(_norm_window(xz, lo, hi, g), bytes=True)[..., :3].astype(np.float32) / 255.0
        zy_n = cmap(_norm_window(zy, lo, hi, g), bytes=True)[..., :3].astype(np.float32) / 255.0

        if blend == 'minimum':
            # opacity fades the channel towards white (the minimum's neutral value)
            xy_acc = np.minimum(xy_acc, 1.0 - o * (1.0 - xy_n))
            xz_acc = np.minimum(xz_acc, 1.0 - o * (1.0 - xz_n))
            zy_acc = np.minimum(zy_acc, 1.0 - o * (1.0 - zy_n))
            continue
        xy_n *= o
        xz_n *= o
        zy_n *= o

        if blend == 'screen':
            xy_acc *= (1.0 - xy_n)
            xz_acc *= (1.0 - xz_n)
            zy_acc *= (1.0 - zy_n)
        elif blend == 'maximum':
            xy_acc = np.maximum(xy_acc, xy_n)
            xz_acc = np.maximum(xz_acc, xz_n)
            zy_acc = np.maximum(zy_acc, zy_n)
        else:
            xy_acc += xy_n
            xz_acc += xz_n
            zy_acc += zy_n

    if blend == 'screen':
        xy_rgb = 1.0 - xy_acc
        xz_rgb = 1.0 - xz_acc
        zy_rgb = 1.0 - zy_acc
    else:
        xy_rgb = xy_acc
        xz_rgb = xz_acc
        zy_rgb = zy_acc

        if blend == 'additive':
            if soft_clip:
                for rgb in (xy_rgb, xz_rgb, zy_rgb):
                    m = rgb.max(axis=-1, keepdims=True)
                    scale = np.maximum(1.0, m)
                    rgb /= scale
            xy_rgb = np.clip(xy_rgb, 0.0, 1.0)
            xz_rgb = np.clip(xz_rgb, 0.0, 1.0)
            zy_rgb = np.clip(zy_rgb, 0.0, 1.0)

    return xy_rgb, xz_rgb, zy_rgb

def black_to(color):
    """Return a black→color LinearSegmentedColormap."""
    rgb = to_rgb(color)
    return LinearSegmentedColormap.from_list(f"black_to_{color}", [(0,0,0), rgb])


def white_to(color):
    """Return a white→color LinearSegmentedColormap (an inverted colormap, for minimum blending)."""
    rgb = to_rgb(color)
    return LinearSegmentedColormap.from_list(f"white_to_{color}", [(1, 1, 1), rgb])


def _attenuated_mip(volume, axis, lo, hi, attenuation):
    """
    Attenuated maximum intensity projection along ``axis`` (napari's ``attenuated_mip``).

    Rays enter the volume at index 0 of ``axis``. Each sample is normalised to
    [0, 1] with the display range (lo, hi) and scaled by
    ``exp(-attenuation * (cumulative normalised intensity - 1))``, so bright
    structures hide what lies behind them; the brightest scaled sample is kept.
    ``attenuation`` is per voxel along the ray (0 gives the plain MIP of the
    clipped data). The result is returned in data units (``lo + m * (hi - lo)``)
    so the usual display range, gamma and colormap apply to it.
    """
    span = max(float(hi) - float(lo), 1e-12)
    v = (np.asarray(volume, dtype=np.float32) - np.float32(lo)) / np.float32(span)
    v = np.clip(np.nan_to_num(v, nan=0.0, posinf=1.0, neginf=0.0), 0.0, 1.0)
    scaled = v * np.exp(-np.float32(attenuation) * (np.cumsum(v, axis=axis) - 1.0))
    m = np.clip(scaled.max(axis=axis), 0.0, 1.0)
    return float(lo) + m * span


def _projector_for(projection, attenuation, lo=None, hi=None):
    """A ``f(volume, axis)`` projector for a canonical projection name."""
    if projection == 'mip':
        return np.max
    if projection == 'minip':
        return np.min
    if projection == 'average':
        return np.mean
    return lambda vol, axis: _attenuated_mip(vol, axis, lo, hi, attenuation)


def blend_colors(intensities, base_colors, vmin=None, vmax=None, gamma=1, soft_clip=True, blending=None):
    """
    Blend multiple channels of intensities into RGB.

    intensities : (N, C) array
        Values per point per channel.
    base_colors : list of str or rgb tuples
        Colors per channel.
    blending : str, optional
        'additive' (default; ``soft_clip`` applies), 'maximum', 'screen' or
        'minimum' (each channel from white to its colour, per-RGB minimum).

    Notes:
        - Multi-channel visualization widgets support rendering with colormaps by distinguishing strings
          via `is_colormap()`. When active, intensities map directly using `cmap(norm)[:, :3]` rather
          than failing through `matplotlib.colors.to_rgb()`.
        - The `colors` parameter in top-level functions is deprecated in favor of `colormap`. To support
          multi-channel arrays, `colormap` accepts a list of colormaps. To prevent `TypeError: unhashable type: 'list'`
          from Matplotlib's `imshow`, functions explicitly unset `colormap` after mapping channels into a pre-rendered RGB array.
        - The default colormap for interactive plotters (slice, scatter, annotator) when no colormap is provided
          is `['white']` for single-channel data, and cycles through `['white', 'lime', 'magenta', 'yellow', 'cyan', 'red', 'blue']`
          for multi-channel data.
    """
    import numpy as np
    from matplotlib.colors import to_rgb

    blending = _check_blending(blending) or 'additive'
    N, C = intensities.shape
    colors = np.ones((N, 3), dtype=float) if blending in ('screen', 'minimum') else np.zeros((N, 3), dtype=float)

    vmin = [None]*C if vmin is None else (vmin.tolist() if hasattr(vmin, 'tolist') else vmin)
    if not isinstance(vmin, (list, tuple)): vmin = [vmin]*C
    elif len(vmin) == 1: vmin = [vmin[0]]*C
    elif len(vmin) < C: vmin = list(vmin) + [None]*(C-len(vmin))

    vmax = [None]*C if vmax is None else (vmax.tolist() if hasattr(vmax, 'tolist') else vmax)
    if not isinstance(vmax, (list, tuple)): vmax = [vmax]*C
    elif len(vmax) == 1: vmax = [vmax[0]]*C
    elif len(vmax) < C: vmax = list(vmax) + [None]*(C-len(vmax))
    gammas = np.full(C, float(gamma)) if np.isscalar(gamma) else np.asarray(gamma, dtype=float)

    for c in range(C):
        arr = intensities[:, c].astype(float)
        vmin_c = np.nanmin(arr) if vmin[c] is None else vmin[c]
        vmax_c = np.nanmax(arr) if vmax[c] is None else vmax[c]
        norm = (arr - vmin_c) / max(1e-9, vmax_c - vmin_c)
        norm = np.clip(norm, 0, 1)
        if gammas[c] != 1:
            norm = norm**gammas[c]

        c_name = base_colors[c]
        if is_colormap(c_name):
            rgb = matplotlib.colormaps[c_name](norm)[:, :3]
        else:
            col = np.asarray(to_rgb(resolve_color(c_name)))
            # black -> colour, or white -> colour for minimum blending
            rgb = 1.0 - norm[:, None] * (1.0 - col) if blending == 'minimum' else norm[:, None] * col
        if blending == 'minimum':
            colors = np.minimum(colors, rgb)
        elif blending == 'maximum':
            colors = np.maximum(colors, rgb)
        elif blending == 'screen':
            colors *= 1.0 - rgb
        else:
            colors += rgb

    if blending == 'screen':
        colors = 1.0 - colors
    if soft_clip and blending == 'additive':
        maxval = colors.max(axis=1, keepdims=True)
        scale = np.maximum(1.0, maxval)
        colors = colors / scale

    return np.clip(colors, 0, 1)





def compute_histogram(arr, bins=128, max_samples=1_000_000, value_range=None):
    """
    Computes a 1D histogram for array values.

    To enhance the visibility of sparse/heavy-tailed intensity distributions in interactive
    widgets, the returned bin counts are transformed into log frequencies (using log1p).
    If the array size exceeds `max_samples`, it subsamples the array to improve performance
    without noticeably degrading the visual overlay.

    `value_range` ``(lo, hi)`` fixes the outer bin edges (see
    `infer_histogram_range`); by default uint8/uint16/bool channels span their
    dtype range and other channels their data range.
    """
    if arr.size == 0:
        return {'counts': [], 'bin_edges': []}

    stride = 1
    if arr.size > max_samples:
        stride = max(1, arr.size // max_samples)
        arr_to_use = arr.ravel()[::stride]
    else:
        arr_to_use = arr

    arr_clean = arr_to_use[np.isfinite(arr_to_use)] if np.issubdtype(arr_to_use.dtype, np.floating) else arr_to_use
    if arr_clean.size == 0:
        return {'counts': [], 'bin_edges': []}

    # Determine absolute range based on dtype
    range_val = None if value_range is None else (float(value_range[0]), float(value_range[1]))
    if range_val is not None:
        if arr.dtype == bool:
            arr_clean = arr_clean.astype(np.uint8)
    elif arr.dtype == np.uint8:
        range_val = (0, 255)
    elif arr.dtype == np.uint16:
        range_val = (0, 65535)
    elif arr.dtype == bool:
        range_val = (0, 1)
        # np.histogram would do this conversion itself, but warns about it.
        arr_clean = arr_clean.astype(np.uint8)

    if range_val is not None:
        counts, bin_edges = np.histogram(arr_clean, bins=bins, range=range_val)
    else:
        counts, bin_edges = np.histogram(arr_clean, bins=bins)

    if stride > 1:
        # Scale back up to match original magnitude
        counts = counts * stride

    # Use log frequencies to enhance visibility of tails in widgets
    counts = np.log1p(counts)

    return {'counts': counts.tolist(), 'bin_edges': bin_edges.tolist()}


# Bit depths of common detectors (8-bit cameras, 10/12/14/16-bit sCMOS/CCD/EMCCD)
# and of wider containers. Inferred depths snap up to the next of these.
_COMMON_BIT_DEPTHS = (8, 10, 12, 14, 16, 24, 32, 64)


def _snap_bit_depth(needed, cap=64):
    for b in _COMMON_BIT_DEPTHS:
        if b >= needed:
            return min(b, cap)
    return cap


def _bit_depth_range(bits, signed):
    """Inclusive integer range of a `bits`-bit signed/unsigned type."""
    if signed:
        return -(2 ** (bits - 1)), 2 ** (bits - 1) - 1
    return 0, 2 ** bits - 1


def _is_integer_valued(arr, max_samples=100_000):
    """True if the (strided sample of the) finite values of a float array are all integers."""
    flat = arr.ravel()
    if flat.size > max_samples:
        flat = flat[::flat.size // max_samples]
    flat = flat[np.isfinite(flat)]
    return flat.size > 0 and bool(np.all(flat == np.round(flat)))


def infer_bit_depth(arr):
    """
    Smallest common detector bit depth (8, 10, 12, 14, 16, 24, 32, 64) that
    holds every value of an integer-valued image.

    The depth is inferred from the data, not the container: 12-bit camera data
    stored as uint16 (max <= 4095) gives 12, a dim 16-bit acquisition whose
    maximum happens to stay below 4096 also gives 12 (the data cannot tell the
    two apart; pass ``bit_depth`` to the viewer to enforce one). Negative values
    count the sign bit (int16 data in [-2048, 2047] gives 12, signed). Float
    images whose finite values are all integers (e.g. camera counts converted
    to float32) are treated the same way. The result never exceeds the integer
    dtype's own width.

    Returns
    -------
    (bits, signed) : (int, bool), or None for bool, empty or non-integer data.
    """
    arr = np.asarray(arr)
    if arr.size == 0 or arr.dtype == bool:
        return None
    if np.issubdtype(arr.dtype, np.integer):
        cap = arr.dtype.itemsize * 8
        lo, hi = int(arr.min()), int(arr.max())
    elif np.issubdtype(arr.dtype, np.floating):
        lo, hi = _finite_min(arr), _finite_max(arr)
        if lo is None or max(abs(lo), abs(hi)) >= 2.0 ** 53 or not _is_integer_valued(arr):
            return None
        cap = 64
        lo, hi = int(lo), int(hi)
    else:
        return None
    signed = lo < 0
    # Magnitude bits; a signed type of b bits holds [-2**(b-1), 2**(b-1) - 1].
    needed = max(hi, -lo - 1 if signed else 0).bit_length() + int(signed)
    return _snap_bit_depth(max(needed, 1), cap), signed


def infer_histogram_range(arr, bit_depth=None):
    """
    Value range ``(lo, hi)`` the channel histogram should span, and the bit
    depth it corresponds to.

    bit_depth : None | 'auto' | int | 'dtype' | 'data'
        None / 'auto' (default): floats in [0, 1] (or [-1, 1]) span that
        normalised range; other integer-valued data span the full range of
        their inferred bit depth (`infer_bit_depth`), e.g. 0..4095 for 12-bit
        data in a uint16 array; remaining floats span their data range.
        int: enforce that bit depth (signed if the data go below 0).
        'dtype': the full range of the integer dtype (uint16 -> 0..65535),
        the data range for floats. 'data': the data range.

    Returns
    -------
    (value_range, bits) : value_range is ``(lo, hi)`` for `compute_histogram`
        (integer levels are centred in their bins, so the edges sit half a
        level outside the range), or None to let `compute_histogram` choose;
        bits is the bit depth used, or None.
    """
    arr = np.asarray(arr)
    if bit_depth is None:
        bit_depth = 'auto'
    if arr.dtype == bool:
        return (-0.5, 1.5), 1

    def _levels(bits, signed):
        lo, hi = _bit_depth_range(bits, signed)
        return (lo - 0.5, hi + 0.5), bits

    if isinstance(bit_depth, str):
        mode = bit_depth.lower()
        if mode == 'data':
            lo, hi = _finite_min(arr), _finite_max(arr)
            if lo is None:
                return None, None
            if np.issubdtype(arr.dtype, np.integer):
                return (lo - 0.5, hi + 0.5), None
            return (None, None) if lo == hi else ((lo, hi), None)
        if mode == 'dtype':
            if np.issubdtype(arr.dtype, np.integer):
                info = np.iinfo(arr.dtype)
                return (info.min - 0.5, info.max + 0.5), info.bits
            return None, None
        if mode != 'auto':
            raise ValueError(f"bit_depth must be None, 'auto', 'dtype', 'data' or an int, got {bit_depth!r}")
        if np.issubdtype(arr.dtype, np.floating):
            # Normalised floats (incl. 0/1 masks) keep their [0, 1] / [-1, 1] range
            lo, hi = _finite_min(arr), _finite_max(arr)
            if lo is not None and hi <= 1.0:
                if lo >= 0.0:
                    return (0.0, 1.0), None
                if lo >= -1.0:
                    return (-1.0, 1.0), None
        inferred = infer_bit_depth(arr)
        if inferred is not None:
            return _levels(*inferred)
        return None, None

    if isinstance(bit_depth, (bool, np.bool_)) or not isinstance(bit_depth, (int, np.integer)):
        raise ValueError(f"bit_depth must be None, 'auto', 'dtype', 'data' or an int, got {bit_depth!r}")
    bits = int(bit_depth)
    if not 1 <= bits <= 64:
        raise ValueError(f"bit_depth must be between 1 and 64, got {bits}")
    lo = _finite_min(arr) if arr.size else None
    return _levels(bits, lo is not None and lo < 0)

def _draw_slab_crosshairs(axes, geoms, x_edges, y_edges, z_edges, widths, origin=(0.0, 0.0, 0.0)):
    """
    Draw the slab boundaries on the three ortho panels.

    ``*_edges`` are the (low, high) slab edges and ``widths`` the full
    (x, y, z) extents, all in unrotated physical units measured from
    ``origin``. ``geoms`` maps each plane to the forward transform of its
    panel (a ``_PanelRotation`` or any object with ``forward(x, y)``).
    """
    wx, wy, wz = widths
    ox, oy, oz = origin

    def line(plane, a0, b0, a1, b1):
        xs, ys = geoms[plane].forward(np.array([a0, a1], dtype=float), np.array([b0, b1], dtype=float))
        axes[plane].plot(xs, ys, color='r', ls=':', alpha=0.3)

    for e in x_edges:
        line('xy', e, oy, e, oy + wy)
        line('xz', e, oz, e, oz + wz)
    for e in y_edges:
        line('xy', ox, e, ox + wx, e)
        line('zy', oz, e, oz + wz, e)
    for e in z_edges:
        line('zy', e, oy, e, oy + wy)
        line('xz', ox, e, ox + wx, e)


class TNIAWidgetBase(anywidget.AnyWidget):
    _esm = _ASSET_DIR.joinpath("tnia_plotting_anywidgets.js").read_text()
    _css = _ASSET_DIR.joinpath("tnia_plotting_anywidgets.css").read_text()


    # Data traits
    image_data = traitlets.Unicode().tag(sync=True)

    # Sliders
    x_s = traitlets.Int(0).tag(sync=True)
    y_s = traitlets.Int(0).tag(sync=True)
    z_s = traitlets.Int(0).tag(sync=True)

    x_t = traitlets.Int(1).tag(sync=True)
    y_t = traitlets.Int(1).tag(sync=True)
    z_t = traitlets.Int(1).tag(sync=True)

    x_start = traitlets.Int(0).tag(sync=True)
    x_end = traitlets.Int(1).tag(sync=True)
    y_start = traitlets.Int(0).tag(sync=True)
    y_end = traitlets.Int(1).tag(sync=True)
    z_start = traitlets.Int(0).tag(sync=True)
    z_end = traitlets.Int(1).tag(sync=True)

    sx = traitlets.Float(1.0).tag(sync=True)
    sy = traitlets.Float(1.0).tag(sync=True)
    sz = traitlets.Float(1.0).tag(sync=True)

    # Bounds for sliders (computed)
    x_min_pos = traitlets.Int(0).tag(sync=True)
    x_max_pos = traitlets.Int(100).tag(sync=True)
    y_min_pos = traitlets.Int(0).tag(sync=True)
    y_max_pos = traitlets.Int(100).tag(sync=True)
    z_min_pos = traitlets.Int(0).tag(sync=True)
    z_max_pos = traitlets.Int(100).tag(sync=True)

    x_thick_max = traitlets.Int(100).tag(sync=True)
    y_thick_max = traitlets.Int(100).tag(sync=True)
    z_thick_max = traitlets.Int(100).tag(sync=True)

    min_thickness = traitlets.Int(1).tag(sync=True)

    # Channels
    channel_names = traitlets.List(traitlets.Unicode()).tag(sync=True)
    channel_dtypes = traitlets.List(traitlets.Unicode()).tag(sync=True)
    channel_colors = traitlets.List(traitlets.Unicode()).tag(sync=True)

    # Channel Parameters
    vmin_list = traitlets.List(traitlets.Any()).tag(sync=True)
    vmax_list = traitlets.List(traitlets.Any()).tag(sync=True)
    gamma_list = traitlets.List(traitlets.Float()).tag(sync=True)
    opacity_list = traitlets.List(traitlets.Float()).tag(sync=True)
    histograms_data = traitlets.List(traitlets.Dict()).tag(sync=True)

    # UI Toggles
    show_crosshair = traitlets.Bool(True).tag(sync=True)
    sync_on_hover = traitlets.Bool(True).tag(sync=True)

    warning_msg = traitlets.Unicode("").tag(sync=True)

    # Communication
    hover_coords = traitlets.Dict().tag(sync=True) # {'plane': 'xy', 'x': 0.5, 'y': 0.5, 't': 123}
    axis_bounds = traitlets.Dict().tag(sync=True) # Bounding boxes of axes in figure coords

    # Save UI
    save_filename = traitlets.Unicode("filepath_save.svg").tag(sync=True)
    save_trigger = traitlets.Int(0).tag(sync=True)

    # Copy Params UI
    copy_params_trigger = traitlets.Int(0).tag(sync=True)
    copy_params_string = traitlets.Unicode("").tag(sync=True)

    def __init__(self, X, Y, Z, show_crosshair=True, sync_on_hover=True, **kwargs):
        super().__init__(**kwargs)
        self.show_crosshair = show_crosshair
        self.sync_on_hover = sync_on_hover
        self.dims = (Z, Y, X) # (Z, Y, X) convention from numpy shape

        # Set max thickness bounds
        self.x_thick_max = max(1, X - 1)
        self.y_thick_max = max(1, Y - 1)
        self.z_thick_max = max(1, Z - 1)

    def _init_observers(self):
        # Observe thickness changes to update position bounds
        self.observe(self._update_bounds, names=['x_t', 'y_t', 'z_t', 'x_start', 'x_end', 'y_start', 'y_end', 'z_start', 'z_end'])

        # Sync handlers between (x_s, x_t) and (x_start, x_end)
        self.observe(self._on_st_changed, names=['x_s', 'y_s', 'z_s', 'x_t', 'y_t', 'z_t'])
        self.observe(self._on_start_end_changed, names=['x_start', 'x_end', 'y_start', 'y_end', 'z_start', 'z_end'])

        # Observe all parameters to update plot
        self.observe(self._render_wrapper, names=['x_s', 'y_s', 'z_s', 'x_t', 'y_t', 'z_t', 'x_start', 'x_end', 'y_start', 'y_end', 'z_start', 'z_end'])

        # Observe channel parameters
        self.observe(self._render_wrapper, names=['vmin_list', 'vmax_list', 'gamma_list', 'opacity_list'])

        # Observe crosshair toggle
        self.observe(self._render_wrapper, names=['show_crosshair'])

        # Observe hover synchronization
        self.observe(self._handle_hover_sync, names=['hover_coords'])

        # Observe save trigger
        self.observe(self._save_svg, names='save_trigger')

        # Observe copy params trigger
        self.observe(self._copy_params, names='copy_params_trigger')

        # Sync initial start/end from initial x_s, x_t
        self._sync_start_end_from_st()

        # Initial bounds update
        self._update_bounds(None)

        # Initial render
        self._render_wrapper(None)

    def _sync_start_end_from_st(self):
        if getattr(self, '_syncing_traits', False):
            return
        self._syncing_traits = True
        try:
            Z, Y, X = self.dims
            x_s_c = max(0, min(X - 1, self.x_s))
            y_s_c = max(0, min(Y - 1, self.y_s))
            z_s_c = max(0, min(Z - 1, self.z_s))

            nx_start = max(0, min(X - 1, x_s_c - self.x_t))
            nx_end = max(0, min(X - 1, x_s_c + self.x_t))
            if nx_end < nx_start: nx_end = nx_start

            ny_start = max(0, min(Y - 1, y_s_c - self.y_t))
            ny_end = max(0, min(Y - 1, y_s_c + self.y_t))
            if ny_end < ny_start: ny_end = ny_start

            nz_start = max(0, min(Z - 1, z_s_c - self.z_t))
            nz_end = max(0, min(Z - 1, z_s_c + self.z_t))
            if nz_end < nz_start: nz_end = nz_start

            with self.hold_trait_notifications():
                self.x_s = x_s_c
                self.y_s = y_s_c
                self.z_s = z_s_c
                self.x_start = nx_start
                self.x_end = nx_end
                self.y_start = ny_start
                self.y_end = ny_end
                self.z_start = nz_start
                self.z_end = nz_end
        finally:
            self._syncing_traits = False

    def _on_st_changed(self, change):
        self._sync_start_end_from_st()

    def _on_start_end_changed(self, change):
        if getattr(self, '_syncing_traits', False):
            return
        self._syncing_traits = True
        try:
            Z, Y, X = self.dims
            nx_start = max(0, min(X - 1, self.x_start))
            nx_end = max(0, min(X - 1, self.x_end))
            if nx_end < nx_start: nx_end = nx_start

            ny_start = max(0, min(Y - 1, self.y_start))
            ny_end = max(0, min(Y - 1, self.y_end))
            if ny_end < ny_start: ny_end = ny_start

            nz_start = max(0, min(Z - 1, self.z_start))
            nz_end = max(0, min(Z - 1, self.z_end))
            if nz_end < nz_start: nz_end = nz_start

            nx_s = (nx_start + nx_end) // 2
            nx_t = max(0, (nx_end - nx_start) // 2)

            ny_s = (ny_start + ny_end) // 2
            ny_t = max(0, (ny_end - ny_start) // 2)

            nz_s = (nz_start + nz_end) // 2
            nz_t = max(0, (nz_end - nz_start) // 2)

            with self.hold_trait_notifications():
                self.x_start = nx_start
                self.x_end = nx_end
                self.y_start = ny_start
                self.y_end = ny_end
                self.z_start = nz_start
                self.z_end = nz_end
                self.x_s = nx_s
                self.x_t = nx_t
                self.y_s = ny_s
                self.y_t = ny_t
                self.z_s = nz_s
                self.z_t = nz_t
        finally:
            self._syncing_traits = False

    def _update_bounds(self, change):
        # x
        lo = 0
        hi = max(0, self.dims[2] - 1)
        self.x_min_pos = lo
        self.x_max_pos = hi
        if self.x_s < lo: self.x_s = lo
        if self.x_s > hi: self.x_s = hi

        # y
        lo = 0
        hi = max(0, self.dims[1] - 1)
        self.y_min_pos = lo
        self.y_max_pos = hi
        if self.y_s < lo: self.y_s = lo
        if self.y_s > hi: self.y_s = hi

        # z
        lo = 0
        hi = max(0, self.dims[0] - 1)
        self.z_min_pos = lo
        self.z_max_pos = hi
        if self.z_s < lo: self.z_s = lo
        if self.z_s > hi: self.z_s = hi

    def _render_wrapper(self, change):
        # Skip renders requested from inside a trait-synchronization pass.
        # Moving one slider writes the paired representation too (e.g. x_start
        # -> x_s + x_t), and every one of those traits is observed here, so a
        # single interaction would otherwise rasterize the figure three times.
        # The trait that started the sync is itself observed by this handler,
        # so the outer notification still renders exactly once after the sync
        # has finished. _init_observers() renders explicitly after its initial
        # sync for the same reason.
        if getattr(self, '_syncing_traits', False):
            return

        # Traits set in one message (a middle-thumb drag sets x_start and x_end;
        # hover sync sets x_s and y_s) notify one at a time after all of them
        # are set, so the second notification would render the same state again.
        if change is not None and getattr(change, 'name', None) in self._RENDER_STATE_TRAITS:
            if self._render_state() == getattr(self, '_last_render_state', None):
                return
        self._last_render_state = self._render_state()

        fig = None
        try:
            fig = self._render()
            if fig:
                if hasattr(fig, 'axXY') and hasattr(fig, 'axZY') and hasattr(fig, 'axXZ'):
                    def get_axis_info(ax):
                        xlim = ax.get_xlim()
                        ylim = ax.get_ylim()
                        p_top_left = fig.transFigure.inverted().transform(ax.transData.transform((xlim[0], ylim[1])))
                        p_bot_right = fig.transFigure.inverted().transform(ax.transData.transform((xlim[1], ylim[0])))
                        x0 = float(p_top_left[0])
                        x1 = float(p_bot_right[0])
                        y1_mpl = float(p_top_left[1])
                        y0_mpl = float(p_bot_right[1])
                        # Map Matplotlib figure coordinates (bottom-left) to JS top-left origin coordinates
                        y0_js = float(1.0 - y1_mpl)
                        y1_js = float(1.0 - y0_mpl)
                        return {
                            'x0': x0,
                            'x1': x1,
                            'y0': y0_mpl,
                            'y1': y1_mpl,
                            'y0_js': y0_js,
                            'y1_js': y1_js,
                            'bbox': [x0, y0_js, x1 - x0, y1_js - y0_js],
                            'bbox_mpl': [x0, y0_mpl, x1 - x0, y1_mpl - y0_mpl],
                            'xlim': [float(xlim[0]), float(xlim[1])],
                            'ylim': [float(ylim[0]), float(ylim[1])]
                        }

                    self.axis_bounds = {
                        'xy': get_axis_info(fig.axXY),
                        'zy': get_axis_info(fig.axZY),
                        'xz': get_axis_info(fig.axXZ)
                    }

                buf = io.BytesIO()
                # The PNG must show the whole figure frame that axis_bounds were
                # computed in, whatever the user's savefig rcParams (e.g. 'tight').
                with matplotlib.rc_context({'savefig.bbox': 'standard'}):
                    fig.savefig(buf, format='png')
                self.image_data = base64.b64encode(buf.getvalue()).decode('utf-8')
        finally:
            if fig is not None:
                plt.close(fig)
    # Traits whose values fully describe what the slab/channel observers render.
    _RENDER_STATE_TRAITS = (
        'x_s', 'y_s', 'z_s', 'x_t', 'y_t', 'z_t',
        'x_start', 'x_end', 'y_start', 'y_end', 'z_start', 'z_end',
        'vmin_list', 'vmax_list', 'gamma_list', 'opacity_list', 'show_crosshair',
    )

    def _render_state(self):
        return tuple(repr(getattr(self, name)) for name in self._RENDER_STATE_TRAITS)

    def _handle_hover_sync(self, change):
        if not self.sync_on_hover:
            return

        coords = change.new if hasattr(change, 'new') else change.get('new', {})
        if not coords:
            return

        plane = coords.get('plane')
        frac_x = coords.get('x')
        frac_y = coords.get('y')

        info = self.axis_bounds.get(plane)
        if not info or not isinstance(info, dict):
            return

        x0, x1 = info.get('x0'), info.get('x1')
        y0_js, y1_js = info.get('y0_js'), info.get('y1_js')
        if x0 is None or x1 is None or y0_js is None or y1_js is None:
            return

        mpl_x = frac_x
        mpl_y_js = frac_y

        if not (x0 <= mpl_x <= x1 and y0_js <= mpl_y_js <= y1_js):
            return

        u = (mpl_x - x0) / (x1 - x0) if (x1 - x0) > 0 else 0.0
        v = (mpl_y_js - y0_js) / (y1_js - y0_js) if (y1_js - y0_js) > 0 else 0.0

        xlim = info.get('xlim')
        ylim = info.get('ylim')

        if not xlim or not ylim:
            return

        phys_x = xlim[0] + u * (xlim[1] - xlim[0])
        phys_y = ylim[1] + v * (ylim[0] - ylim[1])

        idx = self._phys_to_index(plane, phys_x, phys_y)
        if idx is None:
            return
        Z, Y, X = self.dims
        with self.hold_trait_notifications():
            if 'x' in idx:
                self.x_s = max(0, min(X - 1, idx['x']))
            if 'y' in idx:
                self.y_s = max(0, min(Y - 1, idx['y']))
            if 'z' in idx:
                self.z_s = max(0, min(Z - 1, idx['z']))

    def _panel_geometry(self, plane):
        """
        ``_PanelRotation`` of a displayed panel; the same object maps the
        image, the crosshairs and click/hover positions.
        """
        Z, Y, X = self.dims
        rot_z, rot_y, rot_x = _parse_rotate_view(getattr(self, 'rotate_view', None))
        if plane == 'xy':
            return _PanelRotation((Y, X), rot_z, self.sy, self.sx)
        if plane == 'zy':
            return _PanelRotation((Y, Z), rot_x, self.sy, self.sz)
        if plane == 'xz':
            return _PanelRotation((Z, X), rot_y, self.sz, self.sx)
        return None

    def _phys_to_index(self, plane, phys_x, phys_y):
        """
        Displayed physical position on a panel -> voxel indices, e.g.
        ``{'x': 3, 'y': 7}`` for the XY panel. Voxel i spans
        ``[i * s, (i + 1) * s)`` before rotation.
        """
        g = self._panel_geometry(plane)
        if g is None:
            return None
        u, v = g.inverse(phys_x, phys_y)
        if plane == 'xy':
            return {'x': int(np.floor(u / self.sx)), 'y': int(np.floor(v / self.sy))}
        if plane == 'zy':
            return {'z': int(np.floor(u / self.sz)), 'y': int(np.floor(v / self.sy))}
        return {'x': int(np.floor(u / self.sx)), 'z': int(np.floor(v / self.sz))}

    def _render(self):
        raise NotImplementedError

    def _save_svg(self, change):
        fig = self._render()
        if fig:
            try:
                fig.savefig(self.save_filename, format='svg', dpi=300, bbox_inches='tight')
                print(f"Saved to {self.save_filename}")
            except Exception as e:
                print(f"Error saving file: {e}")
            finally:
                plt.close(fig)

    def _copy_params(self, change):
        s = []

        x_s_phys = self.x_s * self.sx
        y_s_phys = self.y_s * self.sy
        z_s_phys = self.z_s * self.sz
        s.append(f"slabs_position=({z_s_phys}, {y_s_phys}, {x_s_phys}),")

        x_t_phys = self.x_t * self.sx
        y_t_phys = self.y_t * self.sy
        z_t_phys = self.z_t * self.sz
        s.append(f"slabs_thickness=({z_t_phys}, {y_t_phys}, {x_t_phys}),")

        # Handle channels
        if hasattr(self, 'num_channels'):
            n = self.num_channels
        else:
            n = getattr(self, 'C', 1)

        vmin = [None if v == "" else float(v) for v in self.vmin_list][:n]
        vmax = [None if v == "" else float(v) for v in self.vmax_list][:n]
        gamma = [float(g) for g in self.gamma_list][:n]
        opacity = [float(o) for o in self.opacity_list][:n]

        # In case n==1 and it's a list, the user can still copy it as a list,
        # but single channel functions accept list of length 1 seamlessly.
        s.append(f"vmin={vmin},")
        s.append(f"vmax={vmax},")
        s.append(f"gamma={gamma},")
        s.append(f"opacity={opacity},")

        if hasattr(self, 'rotate_view') and self.rotate_view is not None:
            s.append(f"rotate_view={self.rotate_view},")
        # Keyword-only rendering options (not in the GUI), kept so a paste reproduces the view
        if getattr(self, 'blending', None) is not None:
            s.append(f"blending={self.blending!r},")
        if getattr(self, 'projection', None) is not None:
            s.append(f"projection={self.projection!r},")
            if self.projection == 'attenuated_mip':
                s.append(f"attenuation={self.attenuation},")

        self.copy_params_string = "\n".join(s)

class TNIASliceWidget(TNIAWidgetBase):
    """
    Interactive ortho-slab viewer of a 3D image (or a list of channels).

    Besides the GUI-controlled display settings, two keyword-only rendering
    options are available (not shown in the GUI):

    - ``blending``: how channels are composited, 'additive', 'maximum',
      'screen' or 'minimum' (see `show_zyx`). None keeps the default
      (additive; maximum when a channel is a colormap name). 'minimum' draws
      each channel from white to its colour and gives a white canvas; with no
      ``colormap`` the channels get the inverted default colours.
    - ``projection`` / ``attenuation``: how each slab is projected, 'mip'
      (default), 'minip', 'average' or 'attenuated_mip' (see
      `show_zyx_projection_slabs`).
    - ``bit_depth``: range of the channel histograms. None / 'auto' infers
      the detector bit depth from the data (8, 10, 12, 14, 16, ... bits, e.g.
      0..4095 for 12-bit data stored as uint16); an int enforces one; 'dtype'
      uses the full dtype range; 'data' the data range. A list sets it per
      channel. See `infer_histogram_range`.
    """
    def __init__(self, im, pixel_sizes=None, figsize=None, colormap=None, vmin=None, vmax=None, gamma=1,
                 show_crosshair=True, sync_on_hover=True, slabs_position=None, slabs_thickness=None, opacity=None, rotate_view=None, channel_labels=None, channel_label_fontsize_pt=None,
                 blending=None, projection=None, attenuation=0.05, bit_depth=None, **kwargs):

        self.blending = _check_blending(blending)
        self.projection = None if projection is None else _check_projection(projection, attenuation)
        self.attenuation = float(attenuation)
        self.rotate_view = rotate_view
        self.channel_labels_input = channel_labels
        self.channel_label_fontsize_pt = channel_label_fontsize_pt
        # Handle 2D images gracefully by adding a Z dimension of 1
        if isinstance(im, list):
            if im[0].ndim == 2:
                im = [img[np.newaxis, ...] for img in im]
        elif im.ndim == 2:
            im = im[np.newaxis, ...]

        pz, py, px = _parse_zyx_tuple_or_dict(pixel_sizes, default_val=1.0)
        z_t, y_t, x_t = _parse_zyx_tuple_or_dict(slabs_thickness, default_val=None)
        z_s, y_s, x_s = _parse_zyx_tuple_or_dict(slabs_position, default_val=None)

        # Determine dimensions
        im_shape = (im[0].shape if isinstance(im, list) else im.shape)
        Z, Y, X = im_shape

        super().__init__(X, Y, Z, show_crosshair=show_crosshair, sync_on_hover=sync_on_hover)

        # Override Base Trait defaults with physical scaling properly
        self.sx = px
        self.sy = py
        self.sz = pz
        self.channel_labels_input = channel_labels
        self.X_arr_phys = X * px
        self.Y_arr_phys = Y * py
        self.Z_arr_phys = Z * pz


        self.im_orig = im

        self._pixel_sizes_given = pixel_sizes is not None
        self._length_unit = _length_unit(pixel_sizes)

        self.figsize = figsize
        self.colormap = colormap
        self.colors_orig = colormap

        # Helper to ensure args are lists of length num_channels
        def _to_list(val, n, default):
            if val is None:
                return [default] * n
            elif isinstance(val, (list, tuple)):
                if len(val) >= n:
                    return list(val[:n])
                else:
                    return list(val) + [default] * (n - len(val))
            else:
                return [val] * n

        # Initialize Channel info
        if isinstance(im, list):
            self.num_channels = len(im)
            if channel_labels is not None:
                self.channel_names = _to_list(channel_labels, self.num_channels, "Channel")
            else:
                self.channel_names = [f"Channel {i}" for i in range(self.num_channels)]
            self.channel_dtypes = [img.dtype.name for img in im]

            # Resolve default colors to ensure stability when toggling. A single
            # colormap string must not be split into characters, and missing
            # entries get the default channel colours.
            self.colors_resolved = _channel_colormaps(colormap, self.num_channels, self.blending)
        else:
            self.num_channels = 1
            if channel_labels is not None:
                self.channel_names = _to_list(channel_labels, 1, "Channel")
            else:
                self.channel_names = ["Channel 0"]
            self.channel_dtypes = [im.dtype.name]
            if colormap is None:
                self.colors_resolved = _channel_colormaps(None, 1, self.blending)
            elif isinstance(colormap, (list, tuple)):
                self.colors_resolved = list(colormap)
            else:
                self.colors_resolved = [colormap]

        # Use resolve_color for channel_colors (which is passed to JS)
        GUI_CHANNEL_COLORS = [_gui_channel_color(c, self.blending) for c in self.colors_resolved]
        self.channel_colors = GUI_CHANNEL_COLORS

        # Set traitlets lists for interactive parameters
        def _resolve_vmin(val, n):
            lst = _to_list(val, n, None)
            res = []
            for x in lst:
                res.append(0.0 if x is None else float(x))
            return res

        def _resolve_vmax(val, n, im_orig):
            lst = _to_list(val, n, None)
            res = []
            for i, x in enumerate(lst):
                if x is not None:
                    res.append(float(x))
                else:
                    res.append(self._auto_vmax[i])
            return res

        # Robust default display maximum per channel (99.9th percentile), also
        # used when a vmax box is cleared in the GUI.
        channels = im if isinstance(im, list) else [im]
        self._auto_vmax = [1.0 if m is None else m for m in (_robust_vmax(c) for c in channels)]
        self.vmin_list = _resolve_vmin(vmin, self.num_channels)
        self.vmax_list = _resolve_vmax(vmax, self.num_channels, self.im_orig)
        self.gamma_list = _to_list(gamma, self.num_channels, 1.0)
        self.opacity_list = _to_list(opacity, self.num_channels, 1.0)

        # Convert physical position/thickness to pixel indices
        def _default_t(n): return max(1, n // 64)
        x_t_idx = int(round(x_t / px)) if x_t is not None else _default_t(X)
        y_t_idx = int(round(y_t / py)) if y_t is not None else _default_t(Y)
        z_t_idx = int(round(z_t / pz)) if z_t is not None else _default_t(Z)

        x_s_idx = int(round(x_s / px)) if x_s is not None else X // 2
        y_s_idx = int(round(y_s / py)) if y_s is not None else Y // 2
        z_s_idx = int(round(z_s / pz)) if z_s is not None else Z // 2

        # Override for max projection if thickness exceeds shape
        if x_t_idx >= X:
            x_t_idx = max(1, X // 2)
            x_s_idx = X // 2
        if y_t_idx >= Y:
            y_t_idx = max(1, Y // 2)
            y_s_idx = Y // 2
        if z_t_idx >= Z:
            z_t_idx = max(1, Z // 2)
            z_s_idx = Z // 2

        self.x_t = x_t_idx
        self.y_t = y_t_idx
        self.z_t = z_t_idx
        self.x_s = x_s_idx
        self.y_s = y_s_idx
        self.z_s = z_s_idx

        # Compute histograms over each channel's (inferred or enforced) bit-depth range
        hists = []
        channels = im if isinstance(im, list) else [im]
        for img, bd in zip(channels, _to_list(bit_depth, len(channels), None)):
            value_range, bits = infer_histogram_range(img, bd)
            h = compute_histogram(img, value_range=value_range)
            h['bit_depth'] = bits
            hists.append(h)
        self.histograms_data = hists

        # Initialize observers and render
        self._init_observers()

    def _render(self):
        Z, Y, X = self.dims

        # The slab [start, end] is inclusive, as shown by the range sliders.
        x0 = max(0, self.x_start)
        x1 = max(x0, min(X - 1, self.x_end))
        y0 = max(0, self.y_start)
        y1 = max(y0, min(Y - 1, self.y_end))
        z0 = max(0, self.z_start)
        z1 = max(z0, min(Z - 1, self.z_end))

        # Half-open index ranges for slicing
        x_lims = [x0, x1 + 1]
        y_lims = [y0, y1 + 1]
        z_lims = [z0, z1 + 1]

        clipped = False
        if x0 > self.x_start or x1 < self.x_end: clipped = True
        if y0 > self.y_start or y1 < self.y_end: clipped = True
        if z0 > self.z_start or z1 < self.z_end: clipped = True

        if clipped:
            self.warning_msg = "⚠️ Projection clipped to image boundaries"
        else:
            self.warning_msg = ""

        # Prepare arguments based on opacity
        # Channels with opacity == 0 are considered hidden and filtered out
        if isinstance(self.im_orig, list):
            # Map "" to None for vmin/vmax
            vmin_resolved = [None if v == "" else float(v) for v in self.vmin_list]
            vmax_resolved = [self._auto_vmax[i] if v == "" else float(v) for i, v in enumerate(self.vmax_list)]
            gamma_resolved = [float(g) for g in self.gamma_list]
            opacity_resolved = [float(o) for o in self.opacity_list]

            # Indices of visible channels
            visible_indices = [i for i, op in enumerate(opacity_resolved) if op > 0]

            if not visible_indices:
                # Create a placeholder figure
                fig = plt.figure(figsize=self.figsize if self.figsize else (10, 10))
                fig.text(0.5, 0.5, "No Channels Visible", ha='center', va='center', color='white')
                fig.patch.set_facecolor('black')
                return fig

            im_curr = [self.im_orig[i] for i in visible_indices]

            if isinstance(self.colors_resolved, list) and len(self.colors_resolved) == self.num_channels:
                 colors_curr = [self.colors_resolved[i] for i in visible_indices]
            else:
                 colors_curr = self.colors_resolved

            vmin_curr = [vmin_resolved[i] for i in visible_indices]
            vmax_curr = [vmax_resolved[i] for i in visible_indices]
            gamma_curr = [gamma_resolved[i] for i in visible_indices]
            opacity_curr = [opacity_resolved[i] for i in visible_indices]
            if self.channel_labels_input is not None:
                channel_labels_curr = [self.channel_names[i] for i in visible_indices]
            else:
                import matplotlib.colors as mcolors
                def _get_name(c):
                    return c.name if isinstance(c, mcolors.Colormap) else str(c)
                channel_labels_curr = [_get_name(c) for c in colors_curr] if isinstance(colors_curr, list) else _get_name(colors_curr)

        else:
            vmin_val = None if self.vmin_list[0] == "" else float(self.vmin_list[0])
            vmax_val = None if self.vmax_list[0] == "" else float(self.vmax_list[0])

            # Robust default if vmax is not explicitly set
            if vmax_val is None:
                vmax_val = self._auto_vmax[0]

            gamma_val = float(self.gamma_list[0])
            opacity_val = float(self.opacity_list[0])

            if opacity_val <= 0:
                fig = plt.figure(figsize=self.figsize if self.figsize else (10, 10))
                fig.text(0.5, 0.5, "No Channels Visible", ha='center', va='center', color='white')
                fig.patch.set_facecolor('black')
                return fig

            im_curr = self.im_orig
            colors_curr = self.colors_resolved
            vmin_curr = vmin_val
            vmax_curr = vmax_val
            gamma_curr = gamma_val
            opacity_curr = opacity_val

            if self.channel_labels_input is not None:
                channel_labels_curr = self.channel_names
            else:
                import matplotlib.colors as mcolors
                def _get_name(c):
                    return c.name if isinstance(c, mcolors.Colormap) else str(c)
                channel_labels_curr = [_get_name(c) for c in colors_curr] if isinstance(colors_curr, list) else [_get_name(colors_curr)]

        # Pass pixel_sizes directly to trigger scale bar logic
        pass_pixel_sizes = None
        if getattr(self, '_pixel_sizes_given', False):
            pass_pixel_sizes = {'Z': self.sz, 'Y': self.sy, 'X': self.sx,
                                'unit': getattr(self, '_length_unit', None)}

        # show_zyx_max_slabs returns a Figure
        fig = show_zyx_max_slabs(
            im_curr, x_lims, y_lims, z_lims,
            pixel_sizes=pass_pixel_sizes, figsize=self.figsize, colormap=colors_curr,
            vmin=vmin_curr, vmax=vmax_curr, gamma=gamma_curr, opacity=opacity_curr,
            rotate_view=self.rotate_view, channel_labels=channel_labels_curr,
            channel_label_fontsize_pt=self.channel_label_fontsize_pt,
            blending=self.blending, projection=self.projection, attenuation=self.attenuation,
        )

        if self.show_crosshair and fig:
            axXY = getattr(fig, 'axXY', None)
            axZY = getattr(fig, 'axZY', None)
            axXZ = getattr(fig, 'axXZ', None)

            if axXY and axZY and axXZ:
                # Slab edges sit on voxel boundaries: the projected range
                # [start, end] covers [start * s, (end + 1) * s).
                _draw_slab_crosshairs(
                    {'xy': axXY, 'zy': axZY, 'xz': axXZ},
                    {plane: self._panel_geometry(plane) for plane in ('xy', 'zy', 'xz')},
                    x_edges=(x_lims[0] * self.sx, x_lims[1] * self.sx),
                    y_edges=(y_lims[0] * self.sy, y_lims[1] * self.sy),
                    z_edges=(z_lims[0] * self.sz, z_lims[1] * self.sz),
                    widths=(X * self.sx, Y * self.sy, Z * self.sz),
                )

        return fig


class TNIAAnnotatorWidget(TNIASliceWidget):
    """
    Subclass of TNIASliceWidget that supports interactive point annotation.
    """
    # UI Toggles
    annotation_mode = traitlets.Bool(False).tag(sync=True)
    annotation_action = traitlets.Unicode('add').tag(sync=True) # 'add' or 'delete'

    # Save CSV UI
    save_csv_filename = traitlets.Unicode("points.csv").tag(sync=True)
    save_csv_trigger = traitlets.Int(0).tag(sync=True)

    # Communication
    click_coords = traitlets.Dict().tag(sync=True) # {'plane': 'xy', 'x': 0.5, 'y': 0.5, 't': 123}

    # Data
    points = traitlets.List().tag(sync=True) # List of [z, y, x] lists

    @property
    def annotate(self):
        return self.annotation_mode

    @annotate.setter
    def annotate(self, value):
        self.annotation_mode = bool(value)

    def __init__(self, im, colormap=None, colors=None, opacity=None, point_size_scale=0.01, annotate=False, *args, **kwargs):
        if colors is not None:
            warnings.warn("The 'colors' parameter is deprecated and will be removed. Use 'colormap' instead.", DeprecationWarning, stacklevel=2)
            if colormap is None:
                colormap = colors
        # Normalize input to list
        if not isinstance(im, list):
            im_list = [im]
        else:
            im_list = list(im)

        # Ensure colormap is a list (inverted default colours for minimum blending)
        defaults = (_DEFAULT_INVERTED_CHANNEL_COLORS
                    if _check_blending(kwargs.get('blending')) == 'minimum'
                    else _DEFAULT_CHANNEL_COLORS)
        if colormap is None:
            if len(im_list) == 1:
                colors_list = defaults[:1]
            else:
                colors_list = list(defaults)
        elif isinstance(colormap, str):
            colors_list = [colormap]
        else:
            colors_list = list(colormap)

        while len(colors_list) < len(im_list):
            if len(im_list) == 1:
                colors_list.extend(defaults[:1])
            else:
                colors_list.extend(defaults)

        colors_list = colors_list[:len(im_list)]

        if opacity is None:
            opacity_list = [1.0] * len(im_list)
        elif isinstance(opacity, (int, float)):
            opacity_list = [opacity] * len(im_list)
        else:
            opacity_list = list(opacity)
            while len(opacity_list) < len(im_list):
                opacity_list.append(1.0)
            opacity_list = opacity_list[:len(im_list)]

        # Gracefully handle 2D
        if im_list[0].ndim == 2:
            im_list = [img[np.newaxis, ...] for img in im_list]

        # Get shape
        im_shape = im_list[0].shape
        Z, Y, X = im_shape
        min_dim = min(X, Y)
        self.point_size = max(3, int(np.ceil(point_size_scale * min_dim)))

        # Create persistent annotation channel
        self._annot_img = np.zeros((Z, Y, X), dtype=np.uint8)

        # Append annotation channel
        im_list.append(self._annot_img)
        colors_list.append('red')
        opacity_list.append(1.0)

        # Ensure vmax is padded correctly for the annotation channel
        vmax = kwargs.get('vmax', None)

        if vmax is None:
            vmax_list = [None] * (len(im_list) - 1)
        elif isinstance(vmax, (list, tuple)):
            vmax_list = (list(vmax) + [None] * len(im_list))[:len(im_list) - 1]
        else:
            vmax_list = [vmax] * (len(im_list) - 1)
        # None entries get the superclass's robust default; annotations are 0/255.
        kwargs['vmax'] = vmax_list + [255.0]

        # The annotation channel is always 8-bit, whatever is set for the image channels
        bit_depth = kwargs.get('bit_depth', None)
        n_img = len(im_list) - 1
        if isinstance(bit_depth, (list, tuple)):
            bd_list = (list(bit_depth) + [None] * n_img)[:n_img]
        else:
            bd_list = [bit_depth] * n_img
        kwargs['bit_depth'] = bd_list + [8]

        # Initialize superclass
        super().__init__(im_list, colormap=colors_list, opacity=opacity_list, *args, **kwargs)

        self.annotation_mode = bool(annotate)

        # Override the last channel name
        self.channel_names = self.channel_names[:-1] + ['Annotations']

    def _init_observers(self):
        super()._init_observers()
        self.observe(self._handle_click, names=['click_coords'])
        self.observe(self._on_points_changed, names=['points'])
        # Also re-render if annotation_mode changes (so UI cursor updates)
        self.observe(self._render_wrapper, names=['annotation_mode'])
        self.observe(self._save_csv, names='save_csv_trigger')

    def _handle_click(self, change):
        if not self.annotation_mode:
            return

        coords = change.new if hasattr(change, 'new') else change.get('new', {})
        if not coords:
            return

        plane = coords.get('plane')
        frac_x = coords.get('x')
        frac_y = coords.get('y')

        info = self.axis_bounds.get(plane)
        if not info or not isinstance(info, dict):
            return

        x0, x1 = info.get('x0'), info.get('x1')
        y0_js, y1_js = info.get('y0_js'), info.get('y1_js')
        if x0 is None or x1 is None or y0_js is None or y1_js is None:
            return

        mpl_x = frac_x
        mpl_y_js = frac_y

        if not (x0 <= mpl_x <= x1 and y0_js <= mpl_y_js <= y1_js):
            return

        u = (mpl_x - x0) / (x1 - x0) if (x1 - x0) > 0 else 0.0
        v = (mpl_y_js - y0_js) / (y1_js - y0_js) if (y1_js - y0_js) > 0 else 0.0

        xlim = info.get('xlim')
        ylim = info.get('ylim')

        if not xlim or not ylim:
            return

        phys_x = xlim[0] + u * (xlim[1] - xlim[0])
        phys_y = ylim[1] + v * (ylim[0] - ylim[1])

        Z, Y, X = self.dims

        idx = self._phys_to_index(plane, phys_x, phys_y)
        if idx is None:
            return
        data_x = idx.get('x', self.x_s)
        data_y = idx.get('y', self.y_s)
        data_z = idx.get('z', self.z_s)

        data_x = max(0, min(X - 1, data_x))
        data_y = max(0, min(Y - 1, data_y))
        data_z = max(0, min(Z - 1, data_z))

        if self.annotation_action == 'add':
            self.add_point(data_z, data_y, data_x)
        elif self.annotation_action == 'delete':
            if not self.points:
                return
            pts = np.array(self.points)
            x0_sl = max(0, self.x_s - self.x_t)
            x1_sl = min(self.dims[2] - 1, self.x_s + self.x_t)
            y0_sl = max(0, self.y_s - self.y_t)
            y1_sl = min(self.dims[1] - 1, self.y_s + self.y_t)
            z0_sl = max(0, self.z_s - self.z_t)
            z1_sl = min(self.dims[0] - 1, self.z_s + self.z_t)

            if plane == 'xy':
                mask = (pts[:, 0] >= z0_sl) & (pts[:, 0] <= z1_sl)
                if not np.any(mask): return
                visible_pts = pts[mask]
                dist = (visible_pts[:, 2] - data_x)**2 + (visible_pts[:, 1] - data_y)**2
            elif plane == 'zy':
                mask = (pts[:, 2] >= x0_sl) & (pts[:, 2] <= x1_sl)
                if not np.any(mask): return
                visible_pts = pts[mask]
                dist = (visible_pts[:, 0] - data_z)**2 + (visible_pts[:, 1] - data_y)**2
            elif plane == 'xz':
                mask = (pts[:, 1] >= y0_sl) & (pts[:, 1] <= y1_sl)
                if not np.any(mask): return
                visible_pts = pts[mask]
                dist = (visible_pts[:, 2] - data_x)**2 + (visible_pts[:, 0] - data_z)**2

            closest_idx = np.argmin(dist)
            if dist[closest_idx] <= 400:
                closest_pt = visible_pts[closest_idx]
                self.remove_point(closest_pt[0], closest_pt[1], closest_pt[2])
    def add_point(self, z, y, x):
        """Programmatically add a point"""
        pt = [int(z), int(y), int(x)]
        if pt not in self.points:
            self.points = self.points + [pt]

    def remove_point(self, z, y, x):
        """Programmatically remove a point"""
        pt = [int(z), int(y), int(x)]
        new_points = []
        deleted = False
        for p in self.points:
            if not deleted and p == pt:
                deleted = True
                continue
            new_points.append(p)
        if deleted:
            self.points = new_points

    def _save_csv(self, change):
        if not self.points:
            print("No points to save.")
            return

        import os
        filename = self.save_csv_filename
        if not filename:
            filename = "points.csv"

        filename = os.path.expanduser(os.path.expandvars(filename))

        try:
            with open(filename, 'w') as f:
                f.write("z,y,x\n")
                for p in self.points:
                    f.write(f"{p[0]},{p[1]},{p[2]}\n")
            print(f"Saved {len(self.points)} points to {filename}")
        except Exception as e:
            print(f"Error saving CSV: {e}")


    def _on_points_changed(self, change):
        # Update annotation mask efficiently
        self._annot_img.fill(0)
        Z, Y, X = self.dims
        s = max(1, self.point_size // 2)
        R = s * min(self.sx, self.sz)
        s_xy = max(1, int(np.round(R / self.sx)))
        s_z = max(1, int(np.round(R / self.sz)))
        for p in self.points:
            pz, py, px = p
            z0 = max(0, pz - s_z)
            z1 = min(Z, pz + s_z + 1)
            y0 = max(0, py - s_xy)
            y1 = min(Y, py + s_xy + 1)
            x0 = max(0, px - s_xy)
            x1 = min(X, px + s_xy + 1)
            if z1 <= z0 or y1 <= y0 or x1 <= x0:
                continue  # marker box entirely outside the volume
            self._annot_img[z0:z1, y0:y1, x0:x1] = 255

        self._render_wrapper(change)

def _int_bounds(a):
    """(floor(min), ceil(max)) of a coordinate array; (0, 0) when it is empty."""
    if len(a) == 0:
        return 0.0, 0.0
    return float(np.floor(np.min(a))), float(np.ceil(np.max(a)))


def _finite_points(X, Y, Z, channels=None):
    """
    Drop points with a non-finite coordinate (with a warning), together with
    their per-point channel values; index-list channels are re-indexed.
    """
    X, Y, Z = (np.asarray(a).reshape(-1) for a in (X, Y, Z))
    if not (len(X) == len(Y) == len(Z)):
        raise ValueError(f"X, Y and Z must have the same length, got {len(X)}, {len(Y)}, {len(Z)}")
    keep = np.isfinite(X.astype(float)) & np.isfinite(Y.astype(float)) & np.isfinite(Z.astype(float))
    if keep.all():
        return X, Y, Z, channels
    n_drop = int((~keep).sum())
    warnings.warn(f"Dropping {n_drop} of {len(X)} points with non-finite coordinates.",
                  UserWarning, stacklevel=3)
    N = len(X)
    new_index = np.cumsum(keep) - 1

    if channels is not None:
        if isinstance(channels, (list, tuple)):
            arrs = [np.asarray(a) for a in channels]
            if all(len(a) == N for a in arrs) and any(np.issubdtype(a.dtype, np.floating) for a in arrs):
                channels = [a[keep] for a in arrs]  # one value per point and channel
            else:
                channels = [new_index[ix[keep[ix]]] for ix in (np.asarray(i, dtype=int) for i in arrs)]
        else:
            channels = np.asarray(channels)[keep]
    return X[keep], Y[keep], Z[keep], channels


class TNIAScatterWidget(TNIAWidgetBase):
    def __init__(self, X_arr, Y_arr, Z_arr, channels=None, pixel_sizes=None, render='points', bins=512,
                 point_size=4, alpha=0.6, colormap=None, colors=None, opacity=None, gamma=1, vmin=None, vmax=None, figsize=None,
                 show_crosshair=True, sync_on_hover=True, subplot_bg=None, slabs_position=None, x_s=None, y_s=None, z_s=None, slabs_thickness=None, x_t=None, y_t=None, z_t=None, rotate_view=None, channel_labels=None, channel_label_fontsize_pt=None,
                 blending=None, **kwargs):
        # Keyword-only channel compositing (not in the GUI); see `show_zyx`.
        # 'minimum' also switches to a white canvas and inverted default colours.
        self.blending = _check_blending(blending)
        if subplot_bg is None:
            subplot_bg = 'white' if self.blending == 'minimum' else 'black'
        self.rotate_view = rotate_view
        self.channel_label_fontsize_pt = channel_label_fontsize_pt
        if colors is not None:
            warnings.warn("The 'colors' parameter is deprecated and will be removed. Use 'colormap' instead.", DeprecationWarning, stacklevel=2)
            if colormap is None:
                colormap = colors

        X_arr, Y_arr, Z_arr, channels = _finite_points(X_arr, Y_arr, Z_arr, channels)
        self.X_arr = X_arr
        self.Y_arr = Y_arr
        self.Z_arr = Z_arr

        # Compute bounds for init
        (xmin, xmax), (ymin, ymax), (zmin, zmax) = (_int_bounds(a) for a in (X_arr, Y_arr, Z_arr))

        X_dim = int(np.ceil(xmax - xmin + 1))
        Y_dim = int(np.ceil(ymax - ymin + 1))
        Z_dim = int(np.ceil(zmax - zmin + 1))

        super().__init__(X_dim, Y_dim, Z_dim, show_crosshair=show_crosshair, sync_on_hover=sync_on_hover)

        self.channels = channels
        self._pixel_sizes_given = pixel_sizes is not None
        self._length_unit = _length_unit(pixel_sizes)
        pz, py, px = _parse_zyx_tuple_or_dict(pixel_sizes, default_val=1.0)
        self.sx = px
        self.sy = py
        self.sz = pz
        self.channel_labels_input = channel_labels
        self.render = render
        self.bins = bins
        self.point_size = point_size
        self.alpha = alpha
        self.colors = colors
        self.figsize = figsize

        self.xmin = xmin
        self.ymin = ymin
        self.zmin = zmin
        self.xmax = xmax
        self.ymax = ymax
        self.zmax = zmax
        self.subplot_bg = subplot_bg

        # Precompute Density helpers
        def _resolve_bins(B):
            if isinstance(B, (tuple, list)) and len(B) == 2:
                bx, by = int(B[0]), int(B[1])
            else:
                bx = by = int(B)
            bx = max(1, bx); by = max(1, by)
            return bx, by

        self.BX, self.BY = _resolve_bins(bins)

        # Widget index i covers data [min + i - 0.5, min + i + 0.5), so points on
        # integer coordinates sit in the middle of their index; the data box is
        # [min - 0.5, max + 0.5) per axis.
        self._box_size = (xmax + 1 - xmin, ymax + 1 - ymin, zmax + 1 - zmin)
        Wx, Wy, Wz = self._box_size
        self._box_lo = (xmin - 0.5, ymin - 0.5, zmin - 0.5)
        self._box_centre_phys = ((xmin + xmax) / 2.0 * px, (ymin + ymax) / 2.0 * py, (zmin + zmax) / 2.0 * pz)
        # Density bins: BX x BY in XY; Z gets bins of about the same physical
        # size, so each panel is drawn with its true physical aspect.
        bxs, bys = Wx / self.BX * px, Wy / self.BY * py
        self.BZ = int(np.clip(np.round(Wz * pz / min(bxs, bys)), 1, 4 * max(self.BX, self.BY)))
        self._bin_data = (Wx / self.BX, Wy / self.BY, Wz / self.BZ)
        self._bin_phys = (bxs, bys, Wz / self.BZ * pz)

        # Analyze channels
        self.N = len(self.X_arr)

        def _is_int_like(a): return np.issubdtype(np.asarray(a).dtype, np.integer) or np.asarray(a).dtype == bool
        def _as_1d(a):
            a = np.asarray(a)
            return a.reshape(-1) if a.ndim == 1 else a

        self.mode = 'single'
        self.ch_ids = None
        self.cont_single = None
        self.cont_multi = None
        self.idx_lists = None

        if channels is None:
            self.mode = 'single'
        elif isinstance(channels, (list, tuple)):
            arrs = [ _as_1d(a) for a in channels ]
            lens = {len(a) for a in arrs}
            if lens == {self.N} and any(np.issubdtype(a.dtype, np.floating) for a in arrs):
                self.mode = 'cont_multi'
                self.cont_multi = np.stack([a.astype(float) for a in arrs], axis=1)
            else:
                self.mode = 'idx_lists'
                self.idx_lists = [np.asarray(ix, dtype=int) for ix in channels]
        else:
            a = _as_1d(channels)
            if a.ndim == 2:
                # (N, C) array: one column of values per channel
                if a.shape[0] != self.N:
                    raise ValueError(
                        f"A 2D channels array must have shape (n_points, n_channels) = ({self.N}, C), got {a.shape}"
                    )
                self.mode = 'cont_multi'
                self.cont_multi = a.astype(float)
            elif _is_int_like(a):
                self.mode = 'ids'
                self.ch_ids = np.asarray(a, dtype=int)
            else:
                self.mode = 'cont_single'
                self.cont_single = np.asarray(a, dtype=float)

        if self.mode in ('single',):
            self.C = 1
        elif self.mode == 'ids':
            self.C = int(self.ch_ids.max()) + 1 if self.ch_ids.size else 1
        elif self.mode == 'idx_lists':
            self.C = len(self.idx_lists)
        elif self.mode == 'cont_single':
            self.C = 1
        else:
            self.C = self.cont_multi.shape[1]

        if colormap is None:
            defaults = (_DEFAULT_INVERTED_CHANNEL_COLORS if self.blending == 'minimum'
                        else _DEFAULT_CHANNEL_COLORS)
            default_cols = list(defaults[:1] if self.C == 1 else defaults)
            while len(default_cols) < self.C:
                 default_cols += default_cols
            self.colors_use = default_cols[:max(1, self.C)]
        else:
            if isinstance(colormap, str):
                self.colors_use = [colormap]
            elif isinstance(colormap, (list, tuple)):
                self.colors_use = list(colormap)
            else:
                self.colors_use = [colormap]

        if self.mode == 'ids' and len(self.colors_use) == 1 and is_colormap(self.colors_use[0]):
            cmap = matplotlib.colormaps[self.colors_use[0]]
            self.colors_rgb = [cmap(i / max(1, self.C - 1))[:3] for i in range(self.C)]
        else:
            self.colors_rgb = [matplotlib.colors.to_rgb(resolve_color(c)) for c in self.colors_use]


        # Set traitlets lists for interactive parameters
        def _to_list(val, n, default):
            if val is None:
                return [default] * n
            elif isinstance(val, (list, tuple)):
                if len(val) >= n:
                    return list(val[:n])
                else:
                    return list(val) + [default] * (n - len(val))
            else:
                return [val] * n

        def _resolve_vmin(val, n):
            lst = _to_list(val, n, None)
            res = []
            for x in lst:
                res.append(0.0 if x is None else float(x))
            return res

        def _resolve_vmax(val, n, mode, cont_single, cont_multi):
            lst = _to_list(val, n, None)
            res = []
            for i, x in enumerate(lst):
                if x is not None:
                    res.append(float(x))
                else:
                    if mode == 'cont_single':
                        m = _finite_max(cont_single)
                    elif mode == 'cont_multi':
                        m = _finite_max(cont_multi[:, i])
                    else:
                        m = 1.0
                    res.append(1.0 if m is None else m)
            return res

        self.vmin_list = _resolve_vmin(vmin, self.C)
        self.vmax_list = _resolve_vmax(vmax, self.C, self.mode, self.cont_single, self.cont_multi)
        self.gamma_list = _to_list(gamma, self.C, 1.0)
        self.opacity_list = _to_list(opacity, self.C, 1.0)

        if channel_labels is not None:
            self.channel_names = _to_list(channel_labels, self.C, "Channel")
        else:
            self.channel_names = [f"Channel {i}" for i in range(self.C)]
        self.channel_dtypes = ["float"] * self.C
        GUI_CHANNEL_COLORS = [get_gui_channel_color(matplotlib.colors.to_hex(c)) for c in self.colors_rgb]
        self.channel_colors = GUI_CHANNEL_COLORS

        z_t_in, y_t_in, x_t_in = _parse_zyx_tuple_or_dict(slabs_thickness, default_val=None)
        z_s_in, y_s_in, x_s_in = _parse_zyx_tuple_or_dict(slabs_position, default_val=None)

        # Init values
        if x_t_in is not None: self.x_t = int(x_t_in)
        if y_t_in is not None: self.y_t = int(y_t_in)
        if z_t_in is not None: self.z_t = int(z_t_in)

        # Center default
        if x_s_in is None: self.x_s = int((self.xmax - self.xmin)/2) # relative to 0
        else: self.x_s = int(x_s_in)

        if y_s_in is None: self.y_s = int((self.ymax - self.ymin)/2)
        else: self.y_s = int(y_s_in)

        if z_s_in is None: self.z_s = int((self.zmax - self.zmin)/2)
        else: self.z_s = int(z_s_in)

        # Compute histograms
        hists = []
        if self.mode == 'single' or self.mode == 'ids' or self.mode == 'idx_lists':
            # For scatter with a single set of points and uniform color, the distribution is just counts (not really intensities).
            # We don't have multiple intensity channels here. We'll leave it empty.
            # If ids, we just have 1 channel (the IDs).
            if self.mode == 'ids':
                hists.append(compute_histogram(self.ch_ids))
            else:
                hists.append({'counts': [], 'bin_edges': []}) # No intensities to map
        elif self.mode == 'cont_single':
            hists.append(compute_histogram(self.cont_single))
        elif self.mode == 'cont_multi':
            for c in range(self.C):
                hists.append(compute_histogram(self.cont_multi[:, c]))

        # pad to C
        while len(hists) < self.C:
            hists.append({'counts': [], 'bin_edges': []})
        self.histograms_data = hists

        # Initialize observers and render
        self._init_observers()

    def _copy_params(self, change):
        """
        Like the base class, but slabs in the units ``show_zyx_max_scatter_interactive``
        takes: positions in data coordinates (index + data minimum), thicknesses in
        data units (one index is one data unit).
        """
        super()._copy_params(change)
        lines = self.copy_params_string.split("\n")
        lines[0] = (f"slabs_position=({self.z_s + self.zmin}, {self.y_s + self.ymin}, "
                    f"{self.x_s + self.xmin}),")
        lines[1] = f"slabs_thickness=({self.z_t}, {self.y_t}, {self.x_t}),"
        self.copy_params_string = "\n".join(lines)

    def _label_colors(self):
        """Colour of each channel as drawn (used for the channel labels)."""
        return [matplotlib.colors.to_hex(self.colors_rgb[i % len(self.colors_rgb)]) for i in range(self.C)]

    def _panel_geometry(self, plane):
        rot_z, rot_y, rot_x = _parse_rotate_view(self.rotate_view)
        if self.render == 'density':
            # Histogram panels, displayed from 0 (= data minimum) in physical units
            bxs, bys, bzs = self._bin_phys
            if plane == 'xy':
                return _PanelRotation((self.BY, self.BX), rot_z, bys, bxs)
            if plane == 'zy':
                return _PanelRotation((self.BY, self.BZ), rot_x, bys, bzs)
            if plane == 'xz':
                return _PanelRotation((self.BZ, self.BX), rot_y, bzs, bxs)
            return None
        # Points, displayed at their physical coordinates and rotated about the
        # centre of the data box
        cx, cy, cz = self._box_centre_phys
        if plane == 'xy':
            return _PointRotation(rot_z, cx, cy)
        if plane == 'zy':
            return _PointRotation(rot_x, cz, cy)
        if plane == 'xz':
            return _PointRotation(rot_y, cx, cz)
        return None

    def _phys_to_index(self, plane, phys_x, phys_y):
        # Widget index i covers data coordinates [min + i - 0.5, min + i + 0.5).
        g = self._panel_geometry(plane)
        if g is None:
            return None
        u, v = g.inverse(phys_x, phys_y)
        if self.render == 'density':
            ox, oy, oz = 0.0, 0.0, 0.0
        else:
            bx0, by0, bz0 = self._box_lo
            ox, oy, oz = bx0 * self.sx, by0 * self.sy, bz0 * self.sz
        if plane == 'xy':
            return {'x': int(np.floor((u - ox) / self.sx)), 'y': int(np.floor((v - oy) / self.sy))}
        if plane == 'zy':
            return {'z': int(np.floor((u - oz) / self.sz)), 'y': int(np.floor((v - oy) / self.sy))}
        return {'x': int(np.floor((u - ox) / self.sx)), 'z': int(np.floor((v - oz) / self.sz))}

    def _render(self):
        vmin_resolved = [None if v == "" else float(v) for v in self.vmin_list]
        vmax_resolved = [None if v == "" else float(v) for v in self.vmax_list]
        gamma_resolved = [float(g) for g in self.gamma_list]
        opacity_resolved = [float(o) for o in self.opacity_list]

        # Translate widget relative coordinates (0..Dim) to data coordinates (min..max).
        # The slab [x0, x1] is inclusive in widget indices; index i covers data
        # [xmin + i - 0.5, xmin + i + 0.5), so points are selected with
        # x0 - 0.5 <= X < x1 + 0.5, the band the crosshairs draw.
        x0 = max(self.xmin, self.xmin + self.x_start)
        x1 = min(self.xmax, self.xmin + self.x_end)
        y0 = max(self.ymin, self.ymin + self.y_start)
        y1 = min(self.ymax, self.ymin + self.y_end)
        z0 = max(self.zmin, self.zmin + self.z_start)
        z1 = min(self.zmax, self.zmin + self.z_end)

        x_lims = (x0, x1)
        y_lims = (y0, y1)
        z_lims = (z0, z1)

        clipped = False
        if x0 > self.xmin + self.x_start or x1 < self.xmin + self.x_end: clipped = True
        if y0 > self.ymin + self.y_start or y1 < self.ymin + self.y_end: clipped = True
        if z0 > self.zmin + self.z_start or z1 < self.zmin + self.z_end: clipped = True

        if clipped:
            self.warning_msg = "⚠️ Projection clipped to data boundaries"
        else:
            self.warning_msg = ""

        def _slab_masks(Xi, Yi, Zi):
            mZ = (Zi >= z_lims[0] - 0.5) & (Zi < z_lims[1] + 0.5)
            mY = (Yi >= y_lims[0] - 0.5) & (Yi < y_lims[1] + 0.5)
            mX = (Xi >= x_lims[0] - 0.5) & (Xi < x_lims[1] + 0.5)
            return mZ, mY, mX

        rot_z, rot_y, rot_x = _parse_rotate_view(self.rotate_view)
        channel_labels = self.channel_names if self.channel_labels_input is not None else None
        sx, sy, sz = self.sx, self.sy, self.sz
        Wx, Wy, Wz = self._box_size
        widths = (Wx * sx, Wy * sy, Wz * sz)
        bx0, by0, bz0 = self._box_lo

        # Density Mode Logic
        if self.render == 'density':
            bx, by, bz = self._bin_data

            def _bin2d(cols, rows, col_lo, col_w, n_c, row_lo, row_w, n_r, w=None):
                # Counts per bin, or the per-bin maximum of w (NaN where empty),
                # so a bin's colour encodes the value as it does in points mode.
                ci = np.clip(np.floor((cols - col_lo) / col_w).astype(np.intp), 0, n_c - 1)
                ri = np.clip(np.floor((rows - row_lo) / row_w).astype(np.intp), 0, n_r - 1)
                flat = ri * n_c + ci
                if w is None:
                    out = np.bincount(flat, minlength=n_r * n_c).astype(float)
                else:
                    ok = np.isfinite(w)
                    out = np.full(n_r * n_c, -np.inf)
                    np.maximum.at(out, flat[ok], w[ok])
                    out[np.isneginf(out)] = np.nan
                return out.reshape(n_r, n_c)

            def _planes(Xi, Yi, Zi, w=None):
                mZ, mY, mX = _slab_masks(Xi, Yi, Zi)
                wz = None if w is None else w[mZ]
                wy = None if w is None else w[mY]
                wx = None if w is None else w[mX]
                Hxy = _bin2d(Xi[mZ], Yi[mZ], bx0, bx, self.BX, by0, by, self.BY, wz)
                Hxz = _bin2d(Xi[mY], Zi[mY], bx0, bx, self.BX, bz0, bz, self.BZ, wy)
                Hzy = _bin2d(Zi[mX], Yi[mX], bz0, bz, self.BZ, by0, by, self.BY, wx)
                return Hxy, Hxz, Hzy

            xy_list, xz_list, zy_list = [], [], []

            if self.mode in ('single', 'ids', 'idx_lists'):
                if self.mode == 'single':
                    idx_lists_local = [np.arange(self.N)]
                elif self.mode == 'ids':
                    idx_lists_local = [np.nonzero(self.ch_ids == c)[0] for c in range(self.C)]
                else:
                    idx_lists_local = self.idx_lists

                for idxs in idx_lists_local:
                    Hxy, Hxz, Hzy = _planes(self.X_arr[idxs], self.Y_arr[idxs], self.Z_arr[idxs])
                    xy_list.append(Hxy); xz_list.append(Hxz); zy_list.append(Hzy)

            elif self.mode == 'cont_single':
                Hxy, Hxz, Hzy = _planes(self.X_arr, self.Y_arr, self.Z_arr, self.cont_single)
                xy_list = [Hxy]; xz_list = [Hxz]; zy_list = [Hzy]

            else: # cont_multi
                for c in range(self.C):
                    Hxy, Hxz, Hzy = _planes(self.X_arr, self.Y_arr, self.Z_arr, self.cont_multi[:, c])
                    xy_list.append(Hxy); xz_list.append(Hxz); zy_list.append(Hzy)

            # One colour (or colormap) per channel. With fewer entries than
            # channels (e.g. integer ids coloured by one colormap name), use the
            # per-channel colours sampled in __init__, as points mode does.
            if len(self.colors_use) >= self.C:
                colors_for_rgb = list(self.colors_use[:self.C])
            else:
                colors_for_rgb = self._label_colors()

            has_colormap = any(is_colormap(c) for c in colors_for_rgb)
            if has_colormap:
                xy_rgb, xz_rgb, zy_rgb = create_multichannel_rgb_cmap(
                    xy_list, xz_list, zy_list,
                    vmin=vmin_resolved, vmax=vmax_resolved, gamma=gamma_resolved, colormap=colors_for_rgb, opacity=opacity_resolved, blend=self.blending or 'additive', soft_clip=True
                )
            else:
                xy_rgb, xz_rgb, zy_rgb = create_multichannel_rgb(
                    xy_list, xz_list, zy_list,
                    vmin=vmin_resolved, vmax=vmax_resolved, gamma=gamma_resolved, colormap=colors_for_rgb, opacity=opacity_resolved, blend=self.blending or 'additive', soft_clip=True
                )

            # Each histogram bin is drawn with its physical size, so panels,
            # scale bar, crosshairs and hover all share the data's units.
            # Opacity is already baked into the composite.
            bxs, bys, bzs = self._bin_phys
            fig = show_zyx(
                xy_rgb, xz_rgb, zy_rgb,
                pixel_sizes={'Z': bzs, 'Y': bys, 'X': bxs, 'unit': self._length_unit},
                pixel_sizes_given=self._pixel_sizes_given,
                figsize=self.figsize, colormap=None,
                vmin=None, vmax=None, gamma=1, use_plt=True, colors=None, opacity=None, subplot_bg=self.subplot_bg,
                rotate_view=self.rotate_view, channel_labels=channel_labels,
                channel_label_fontsize_pt=self.channel_label_fontsize_pt,
                channel_label_colors=self._label_colors(),
                blending=self.blending,
            )

            if self.blending != 'minimum':  # the white theme keeps its white canvas
                fig.patch.set_alpha(0.0) # transparent figure bg
                fig.patch.set_facecolor("none")
            # Subplot facecolor is handled by show_zyx if subplot_bg is passed

            if self.show_crosshair:
                _draw_slab_crosshairs(
                    {'xy': fig.axXY, 'zy': fig.axZY, 'xz': fig.axXZ},
                    {plane: self._panel_geometry(plane) for plane in ('xy', 'zy', 'xz')},
                    x_edges=((x_lims[0] - self.xmin) * sx, (x_lims[1] + 1 - self.xmin) * sx),
                    y_edges=((y_lims[0] - self.ymin) * sy, (y_lims[1] + 1 - self.ymin) * sy),
                    z_edges=((z_lims[0] - self.zmin) * sz, (z_lims[1] + 1 - self.zmin) * sz),
                    widths=widths,
                )

            return fig

        else:
            # Points mode: points sit at their physical coordinates and are
            # rotated about the centre of the data box, in the same sense as
            # the image panels.
            geoms = {plane: self._panel_geometry(plane) for plane in ('xy', 'zy', 'xz')}
            cx, cy, cz = self._box_centre_phys

            def _rot_bounds(w1, w2, angle):
                if angle == 0: return w1, w2
                rad = np.radians(angle)
                cos_a, sin_a = abs(np.cos(rad)), abs(np.sin(rad))
                return w1 * cos_a + w2 * sin_a, w1 * sin_a + w2 * cos_a

            # Physical extents of the rotated panels
            w_x_xy, w_y_xy = _rot_bounds(widths[0], widths[1], rot_z)
            w_x_xz, w_z_xz = _rot_bounds(widths[0], widths[2], rot_y)
            w_z_zy, w_y_zy = _rot_bounds(widths[2], widths[1], rot_x)

            col1_w = max(w_x_xy, w_x_xz)
            col2_w = w_z_zy
            row1_h = max(w_y_xy, w_y_zy)
            row2_h = w_z_xz

            figW, figH = self.figsize if self.figsize is not None else (10, 10)
            gap_in = 1.0 / 16.0
            margin_in = 0.05

            fontsize_pt = max(10, min(24, figH * 72 * 0.035))
            if self.channel_label_fontsize_pt is not None:
                channel_label_fontsize_pt = self.channel_label_fontsize_pt
            else:
                channel_label_fontsize_pt = fontsize_pt

            hl_in = (0.10 + (channel_label_fontsize_pt / 72.0)) if channel_labels is not None else 0.0
            num_v_gaps = 2 if channel_labels is not None else 1

            avail_w_in = figW - gap_in - 2.0 * margin_in
            avail_h_in = figH - num_v_gaps * gap_in - 2.0 * margin_in - hl_in

            scale = min(avail_w_in / max(col1_w + col2_w, 1e-6), avail_h_in / max(row1_h + row2_h, 1e-6))

            w1_in = col1_w * scale
            w2_in = col2_w * scale
            h1_in = row1_h * scale
            h2_in = row2_h * scale

            block_w_in = w1_in + gap_in + w2_in
            block_h_in = h1_in + gap_in + h2_in + (hl_in + gap_in if channel_labels is not None else 0.0)

            left_margin_in = (figW - block_w_in) / 2.0
            bottom_margin_in = (figH - block_h_in) / 2.0

            x0_frac = left_margin_in / figW
            w1_frac = w1_in / figW
            gap_w_frac = gap_in / figW
            w2_frac = w2_in / figW

            x_col1 = x0_frac
            x_col2 = x0_frac + w1_frac + gap_w_frac

            y0_frac = bottom_margin_in / figH
            h2_frac = h2_in / figH
            gap_h_frac = gap_in / figH
            h1_frac = h1_in / figH
            hl_frac = hl_in / figH

            y_row2 = y0_frac
            y_row1 = y0_frac + h2_frac + gap_h_frac

            # Create the figure at the size the layout was computed for
            fig_bg = 'white' if self.blending == 'minimum' else 'none'
            fig = Figure(figsize=(figW, figH), facecolor=fig_bg) if not plt.get_fignums() else plt.figure(figsize=(figW, figH), facecolor=fig_bg)

            axLabels = None
            if channel_labels is not None:
                y_labels = y_row1 + h1_frac + gap_h_frac
                axLabels = fig.add_axes([x_col1, y_labels, w1_frac, hl_frac])
                axXY = fig.add_axes([x_col1, y_row1, w1_frac, h1_frac])
                axZY = fig.add_axes([x_col2, y_row1, w2_frac, h1_frac])
                axXZ = fig.add_axes([x_col1, y_row2, w1_frac, h2_frac])
                axBar = fig.add_axes([x_col2, y_row2, w2_frac, h2_frac])

                axLabels.patch.set_visible(False)
                axLabels.set_xticks([])
                axLabels.set_yticks([])
                for spine in axLabels.spines.values():
                    spine.set_visible(False)

                bar_linewidth = max(1.0, channel_label_fontsize_pt * 0.15)
                axLabels.plot([0, 1], [0, 0], transform=axLabels.transAxes, color=(0.85, 0.85, 0.85), linewidth=bar_linewidth, clip_on=False)

                n_labels = len(channel_labels)
                if n_labels > 0:
                    color_list = self._label_colors()
                    if len(color_list) < n_labels:
                        color_list = color_list * (n_labels // len(color_list) + 1)

                    from matplotlib.offsetbox import TextArea, HPacker, AnchoredOffsetbox

                    text_areas = []
                    for i, label in enumerate(channel_labels):
                        GUI_CHANNEL_COLOR = get_gui_channel_color(color_list[i])
                        ta = TextArea(label, textprops=dict(color=GUI_CHANNEL_COLOR, fontsize=channel_label_fontsize_pt, fontweight='bold'))
                        text_areas.append(ta)

                    packer = HPacker(children=text_areas, align="center", pad=0, sep=10)
                    anchored_box = AnchoredOffsetbox(
                        loc='lower center', child=packer, pad=0.0, frameon=False, borderpad=0.0,
                        bbox_to_anchor=(0.5, 0.2), bbox_transform=axLabels.transAxes
                    )
                    axLabels.add_artist(anchored_box)
            else:
                axXY = fig.add_axes([x_col1, y_row1, w1_frac, h1_frac])
                axZY = fig.add_axes([x_col2, y_row1, w2_frac, h1_frac])
                axXZ = fig.add_axes([x_col1, y_row2, w1_frac, h2_frac])
                axBar = fig.add_axes([x_col2, y_row2, w2_frac, h2_frac])

            fig.axXY = axXY
            fig.axZY = axZY
            fig.axXZ = axXZ
            fig.axBar = axBar
            fig.axLabels = axLabels

            for ax in (axXY, axZY, axXZ, axBar):
                if ax is not axBar and self.subplot_bg is not None:
                    ax.set_facecolor(self.subplot_bg)
                else:
                    ax.patch.set_visible(False)
                ax.set_xticks([])
                ax.set_yticks([])
                for spine in ax.spines.values():
                    spine.set_visible(False)

            def _scatter_planes(Xi, Yi, Zi, **kw):
                mZ, mY, mX = _slab_masks(Xi, Yi, Zi)

                def _sub(m):
                    return {k: (v[m] if isinstance(v, np.ndarray) and v.ndim >= 1 and len(v) == len(Xi) else v) for k, v in kw.items()}

                if mZ.any():
                    u, v = geoms['xy'].forward(Xi[mZ] * sx, Yi[mZ] * sy)
                    axXY.scatter(u, v, s=self.point_size, alpha=self.alpha, linewidths=0, **_sub(mZ))
                if mY.any():
                    u, v = geoms['xz'].forward(Xi[mY] * sx, Zi[mY] * sz)
                    axXZ.scatter(u, v, s=self.point_size, alpha=self.alpha, linewidths=0, **_sub(mY))
                if mX.any():
                    u, v = geoms['zy'].forward(Zi[mX] * sz, Yi[mX] * sy)
                    axZY.scatter(u, v, s=self.point_size, alpha=self.alpha, linewidths=0, **_sub(mX))

            if self.mode == 'cont_single':
                vals = self.cont_single
                c_use = self.colors_use[0]
                if is_colormap(c_use):
                    cmap = matplotlib.colormaps[c_use]
                elif self.blending == 'minimum':
                    cmap = white_to(resolve_color(c_use))
                else:
                    cmap = black_to(resolve_color(c_use))

                vmin_c = np.nanmin(vals) if vmin_resolved[0] is None else vmin_resolved[0]
                vmax_c = np.nanmax(vals) if vmax_resolved[0] is None else vmax_resolved[0]
                norm = matplotlib.colors.Normalize(vmin=vmin_c, vmax=vmax_c)
                _scatter_planes(self.X_arr, self.Y_arr, self.Z_arr, c=vals, cmap=cmap, norm=norm)

            elif self.mode == 'cont_multi':
                cols = blend_colors(self.cont_multi, self.colors_use, vmin=vmin_resolved, vmax=vmax_resolved, gamma=gamma_resolved, soft_clip=True, blending=self.blending)
                _scatter_planes(self.X_arr, self.Y_arr, self.Z_arr, c=cols)

            else:
                if self.mode == 'single':
                    idx_lists_local = [np.arange(self.N)]
                elif self.mode == 'ids':
                    idx_lists_local = [np.nonzero(self.ch_ids == c)[0] for c in range(self.C)]
                else:
                    idx_lists_local = self.idx_lists

                for c, idxs in enumerate(idx_lists_local):
                    if idxs.size == 0: continue
                    col = [self.colors_rgb[c % len(self.colors_rgb)]]
                    _scatter_planes(self.X_arr[idxs], self.Y_arr[idxs], self.Z_arr[idxs], c=col)

            # Axis limits: the rotated data box, centred on the rotation centre
            axXY.set_xlim([cx - w_x_xy / 2, cx + w_x_xy / 2])
            axXY.set_ylim([cy + w_y_xy / 2, cy - w_y_xy / 2])

            axXZ.set_xlim([cx - w_x_xz / 2, cx + w_x_xz / 2])
            axXZ.set_ylim([cz + w_z_xz / 2, cz - w_z_xz / 2])

            axZY.set_xlim([cz - w_z_zy / 2, cz + w_z_zy / 2])
            axZY.set_ylim([cy + w_y_zy / 2, cy - w_y_zy / 2])

            if self.show_crosshair:
                _draw_slab_crosshairs(
                    {'xy': axXY, 'zy': axZY, 'xz': axXZ}, geoms,
                    x_edges=((x_lims[0] - 0.5) * sx, (x_lims[1] + 0.5) * sx),
                    y_edges=((y_lims[0] - 0.5) * sy, (y_lims[1] + 0.5) * sy),
                    z_edges=((z_lims[0] - 0.5) * sz, (z_lims[1] + 0.5) * sz),
                    widths=widths,
                    origin=(bx0 * sx, by0 * sy, bz0 * sz),
                )

            # Scale bar (kept opaque), measured against the drawn XY width
            fig.patch.set_alpha(1.0)
            _add_scale_bar(axXY, axBar, w_x_xy, self._pixel_sizes_given, (figW, figH), unit=self._length_unit,
                           color='black' if self.blending == 'minimum' else 'white')

            # FORCE MATPLOTLIB TRANSFORMS BEFORE RETURN <<<
            fig.canvas.draw()
            return fig


def show_zyx_max_slice_interactive(
    im,
    pixel_sizes=None, sxy=None, sz=None,
    figsize=None, colormap=None,
    vmin=None, vmax=None,
    gamma=1, figsize_scale=1,
    show_crosshair=True, sync_on_hover=True,
    colors=None, opacity=None,
    slabs_position=None, x_s=None, y_s=None, z_s=None,
    slabs_thickness=None, x_t=None, y_t=None, z_t=None,
    rotate_view=None, channel_labels=None, channel_label_fontsize_pt=None,
    blending=None, projection=None, attenuation=0.05, bit_depth=None,
):
    """
    Interactive 3D slice viewer using AnyWidget.

    Inspired by show_zyx_max_slice_interactive in tnia_plotting_3d.py (ipywidgets version).

    Parameters
    ----------
    blending : str, optional
        Channel compositing: 'additive', 'maximum', 'screen' or 'minimum'
        (white background with white->colour or inverted colormaps). None
        keeps the default. Keyword only; not in the GUI.
    projection : str, optional
        Slab projection: 'mip' (default), 'minip', 'average' or
        'attenuated_mip' (napari's rendering names). Keyword only.
    attenuation : float, optional
        Attenuation per voxel for 'attenuated_mip' (default 0.05).
    bit_depth : None, 'auto', int, 'dtype', 'data' or list, optional
        Range of the channel histograms. By default the detector bit depth is
        inferred from the data (the smallest of 8, 10, 12, 14, 16, ... bits
        holding the maximum, e.g. 0..4095 for 12-bit data stored as uint16).
        An int (e.g. 12) enforces a bit depth, 'dtype' uses the full dtype
        range, 'data' the data range; a list sets it per channel.
    rotate_view : float or tuple of floats, optional
        Rotates the 2D projected views purely for visualization.
        If a single float is provided, it rotates the XY projection (in degrees).
        If a tuple of three floats is provided `(Z, Y, X)`, it rotates the XY, XZ, and ZY projections independently.
        Note: This only rotates the 2D projected views to avoid overhead. Slicing still occurs along the original unrotated axes.
        For true 3D rotation before slicing, pre-rotate the 3D volume using e.g., `scipy.ndimage.rotate` before passing it to this function.

    Notes:
        - When `vmax` is not explicitly provided (or its box is cleared in the GUI), it defaults to
          the 99.9th percentile of each channel's finite values, so a few hot pixels do not set the
          display range (the maximum when the signal covers less than 0.1% of the voxels; 1.0 for an
          all-NaN channel); `vmin` defaults to 0.
        - Interactive widgets compute a 128-bin histogram per channel in the Python backend (excluding NaNs for floats)
          and synchronize it with the JS frontend via a `histograms_data` traitlet. The frontend renders this on a `<canvas>`
          underneath the channel controls, overlaid with a curve reflecting the current `vmin`, `vmax`, and `gamma` settings.
    """
    if colors is not None:
        warnings.warn("The 'colors' parameter is deprecated and will be removed. Use 'colormap' instead.", DeprecationWarning, stacklevel=2)
        if colormap is None:
            colormap = colors

    if sxy is not None or sz is not None:
        warnings.warn("The 'sxy' and 'sz' parameters are deprecated. Use 'pixel_sizes' instead.", DeprecationWarning, stacklevel=2)
        if pixel_sizes is None:
            _sxy = sxy if sxy is not None else 1.0
            _sz = sz if sz is not None else 1.0
            pixel_sizes = (_sz, _sxy, _sxy)

    # The widget parses pixel_sizes again and warns about missing axes once
    pz, py, px = _parse_zyx_tuple_or_dict(pixel_sizes, default_val=1.0, warn=False)

    if any(x is not None for x in [x_s, y_s, z_s]):
        warnings.warn("The 'x_s', 'y_s', 'z_s' parameters are deprecated. Use 'slabs_position' instead.", DeprecationWarning, stacklevel=2)
        if slabs_position is None:
            slabs_position = (z_s, y_s, x_s)

    if any(x is not None for x in [x_t, y_t, z_t]):
        warnings.warn("The 'x_t', 'y_t', 'z_t' parameters are deprecated. Use 'slabs_thickness' instead.", DeprecationWarning, stacklevel=2)
        if slabs_thickness is None:
            slabs_thickness = (z_t, y_t, x_t)

    z_t, y_t, x_t = _parse_zyx_tuple_or_dict(slabs_thickness, default_val=None)
    z_s, y_s, x_s = _parse_zyx_tuple_or_dict(slabs_position, default_val=None)

    if isinstance(im, list):
        if im[0].ndim == 2:
            im = [img[np.newaxis, ...] for img in im]
    elif im.ndim == 2:
        im = im[np.newaxis, ...]
    im_shape = (im[0].shape if isinstance(im, list) else im.shape)
    Z, Y, X = im_shape

    # Calculate physical layout dimensions (microns)
    phys_w = X * px + Z * pz
    phys_h = Y * py + Z * pz
    if channel_labels is not None:
        phys_h += phys_h * 0.05

    if figsize is None:
        divisor = max(phys_w / 8.0, phys_h / 8.0)
        w, h = float(phys_w / divisor), float(phys_h / divisor)
        figsize = (w * figsize_scale, h * figsize_scale)
    elif figsize_scale != 1.0:
        figsize = (figsize[0] * figsize_scale, figsize[1] * figsize_scale)

    def _default_t(n): return max(1, n // 64)
    if x_t is None: x_t = _default_t(X) * px
    if y_t is None: y_t = _default_t(Y) * py
    if z_t is None: z_t = _default_t(Z) * pz

    # Defaults for s are handled in init (midpoint)
    if x_s is None: x_s = (X // 2) * px
    if y_s is None: y_s = (Y // 2) * py
    if z_s is None: z_s = (Z // 2) * pz

    # Override for max projection if thickness exceeds shape
    if x_t >= X * px:
        x_t = max(1, X // 2) * px
        x_s = (X // 2) * px
    if y_t >= Y * py:
        y_t = max(1, Y // 2) * py
        y_s = (Y // 2) * py
    if z_t >= Z * pz:
        z_t = max(1, Z // 2) * pz
        z_s = (Z // 2) * pz

    w = TNIASliceWidget(
        im, pixel_sizes=pixel_sizes, figsize=figsize, colormap=colormap if colormap is not None else colors,
        vmin=vmin, vmax=vmax, gamma=gamma, opacity=opacity, show_crosshair=show_crosshair, sync_on_hover=sync_on_hover,
        slabs_position=(z_s, y_s, x_s), slabs_thickness=(z_t, y_t, x_t), rotate_view=rotate_view, channel_labels=channel_labels,
        channel_label_fontsize_pt=channel_label_fontsize_pt,
        blending=blending, projection=projection, attenuation=attenuation,
        bit_depth=bit_depth,
    )
    return w

def show_zyx_max_slice_interactive_point_annotator(
    im,
    pixel_sizes=None, sxy=None, sz=None,
    figsize=None, colormap=None,
    vmin=None, vmax=None,
    gamma=1, figsize_scale=1,
    show_crosshair=True, sync_on_hover=True,
    colors=None, opacity=None,
    point_size_scale=0.01,
    annotate=False,
    slabs_position=None, x_s=None, y_s=None, z_s=None,
    slabs_thickness=None, x_t=None, y_t=None, z_t=None,
    rotate_view=None, channel_labels=None, channel_label_fontsize_pt=None,
    blending=None, projection=None, attenuation=0.05, bit_depth=None,
):
    """
    Interactive 3D slice viewer with point annotation using AnyWidget.
    Features the same visualization as show_zyx_max_slice_interactive, but adds:
    - Point annotation toggle
    - Left-click on any projection to add or delete points.
    Returns a widget instance `w`. The list of annotated points is accessible via `w.points`.

    Parameters
    ----------
    blending : str, optional
        Channel compositing: 'additive', 'maximum', 'screen' or 'minimum'
        (white background with white->colour or inverted colormaps). None
        keeps the default. Keyword only; not in the GUI.
    projection : str, optional
        Slab projection: 'mip' (default), 'minip', 'average' or
        'attenuated_mip' (napari's rendering names). Keyword only.
    attenuation : float, optional
        Attenuation per voxel for 'attenuated_mip' (default 0.05).
    bit_depth : None, 'auto', int, 'dtype', 'data' or list, optional
        Range of the channel histograms. By default the detector bit depth is
        inferred from the data (the smallest of 8, 10, 12, 14, 16, ... bits
        holding the maximum, e.g. 0..4095 for 12-bit data stored as uint16).
        An int (e.g. 12) enforces a bit depth, 'dtype' uses the full dtype
        range, 'data' the data range; a list sets it per channel.
    rotate_view : float or tuple of floats, optional
        Rotates the 2D projected views purely for visualization.
        If a single float is provided, it rotates the XY projection (in degrees).
        If a tuple of three floats is provided `(Z, Y, X)`, it rotates the XY, XZ, and ZY projections independently.
        Note: This only rotates the 2D projected views to avoid overhead. Slicing still occurs along the original unrotated axes.
        For true 3D rotation before slicing, pre-rotate the 3D volume using e.g., `scipy.ndimage.rotate` before passing it to this function.
    """
    if colors is not None:
        warnings.warn("The 'colors' parameter is deprecated and will be removed. Use 'colormap' instead.", DeprecationWarning, stacklevel=2)
        if colormap is None:
            colormap = colors

    if sxy is not None or sz is not None:
        warnings.warn("The 'sxy' and 'sz' parameters are deprecated. Use 'pixel_sizes' instead.", DeprecationWarning, stacklevel=2)
        if pixel_sizes is None:
            _sxy = sxy if sxy is not None else 1.0
            _sz = sz if sz is not None else 1.0
            pixel_sizes = (_sz, _sxy, _sxy)

    # The widget parses pixel_sizes again and warns about missing axes once
    pz, py, px = _parse_zyx_tuple_or_dict(pixel_sizes, default_val=1.0, warn=False)

    if any(x is not None for x in [x_s, y_s, z_s]):
        warnings.warn("The 'x_s', 'y_s', 'z_s' parameters are deprecated. Use 'slabs_position' instead.", DeprecationWarning, stacklevel=2)
        if slabs_position is None:
            slabs_position = (z_s, y_s, x_s)

    if any(x is not None for x in [x_t, y_t, z_t]):
        warnings.warn("The 'x_t', 'y_t', 'z_t' parameters are deprecated. Use 'slabs_thickness' instead.", DeprecationWarning, stacklevel=2)
        if slabs_thickness is None:
            slabs_thickness = (z_t, y_t, x_t)

    z_t, y_t, x_t = _parse_zyx_tuple_or_dict(slabs_thickness, default_val=None)
    z_s, y_s, x_s = _parse_zyx_tuple_or_dict(slabs_position, default_val=None)

    if isinstance(im, list):
        if im[0].ndim == 2:
            im = [img[np.newaxis, ...] for img in im]
    elif im.ndim == 2:
        im = im[np.newaxis, ...]
    im_shape = (im[0].shape if isinstance(im, list) else im.shape)
    Z, Y, X = im_shape

    phys_w = X * px + Z * pz
    phys_h = Y * py + Z * pz
    if channel_labels is not None:
        phys_h += phys_h * 0.05

    if figsize is None:
        divisor = max(phys_w / 8.0, phys_h / 8.0)
        w, h = float(phys_w / divisor), float(phys_h / divisor)
        figsize = (w * figsize_scale, h * figsize_scale)
    elif figsize_scale != 1.0:
        figsize = (figsize[0] * figsize_scale, figsize[1] * figsize_scale)

    def _default_t(n): return max(1, n // 64)
    if x_t is None: x_t = _default_t(X) * px
    if y_t is None: y_t = _default_t(Y) * py
    if z_t is None: z_t = _default_t(Z) * pz

    if x_s is None: x_s = (X // 2) * px
    if y_s is None: y_s = (Y // 2) * py
    if z_s is None: z_s = (Z // 2) * pz

    if x_t >= X * px:
        x_t = max(1, X // 2) * px
        x_s = (X // 2) * px
    if y_t >= Y * py:
        y_t = max(1, Y // 2) * py
        y_s = (Y // 2) * py
    if z_t >= Z * pz:
        z_t = max(1, Z // 2) * pz
        z_s = (Z // 2) * pz

    w = TNIAAnnotatorWidget(
        im, pixel_sizes=pixel_sizes, figsize=figsize, colormap=colormap if colormap is not None else colors,
        vmin=vmin, vmax=vmax, gamma=gamma, opacity=opacity, show_crosshair=show_crosshair, sync_on_hover=sync_on_hover,
        point_size_scale=point_size_scale, annotate=annotate,
        slabs_position=(z_s, y_s, x_s), slabs_thickness=(z_t, y_t, x_t), rotate_view=rotate_view, channel_labels=channel_labels,
        channel_label_fontsize_pt=channel_label_fontsize_pt,
        blending=blending, projection=projection, attenuation=attenuation,
        bit_depth=bit_depth,
    )
    return w

def show_zyx_max_scatter_interactive(
    points,
    channels=None,
    pixel_sizes=None, sxy=None, sz=None,
    render=None,
    bins=512,
    point_size=4, alpha=0.6,
    colormap=None, colors=None, opacity=None,
    gamma=1, vmin=None, vmax=None,
    figsize=None, figsize_scale=1.0,
    show_crosshair=True, sync_on_hover=True,
    subplot_bg=None,
    slabs_position=None, x_s=None, y_s=None, z_s=None,
    slabs_thickness=None, x_t=None, y_t=None, z_t=None,
    rotate_view=None, channel_labels=None, channel_label_fontsize_pt=None,
    blending=None,
):
    """
    Shows interactive sliders for XY, XZ, and YZ projection of 3D point coordinates.

    Parameters
    ----------
    blending : str, optional
        Channel compositing: 'additive' (default), 'maximum', 'screen' or
        'minimum' (white canvas; each channel from white to its colour).
        Keyword only; not in the GUI.
    subplot_bg : str, optional
        Panel background; defaults to black ('white' with blending='minimum').
    rotate_view : float or tuple of floats, optional
        Rotates the 2D projected views purely for visualization.
        If a single float is provided, it rotates the XY projection (in degrees).
        If a tuple of three floats is provided `(Z, Y, X)`, it rotates the XY, XZ, and ZY projections independently.
        Note: This only rotates the 2D projected views to avoid overhead. Slicing still occurs along the original unrotated axes.
        For true 3D rotation before slicing, pre-rotate the 3D volume using e.g., `scipy.ndimage.rotate` before passing it to this function.

    Notes:
        - When hiding axes to maintain custom subplot backgrounds (e.g. `subplot_bg`), the code
          manually hides ticks and spines instead of using `ax.axis('off')`, as `ax.axis('off')`
          inadvertently disables the background patch in matplotlib.
        - When `vmax` is not explicitly provided, it defaults to the largest finite value of each
          channel (1.0 for an all-NaN channel); `vmin` defaults to 0.
        - The function dynamically determines its rendering mode: if `render=None`, it defaults to
          `'points'` for point counts under 10,000, and `'density'` for larger datasets to optimize interactive performance.
    """
    if colors is not None:
        warnings.warn("The 'colors' parameter is deprecated and will be removed. Use 'colormap' instead.", DeprecationWarning, stacklevel=2)
        if colormap is None:
            colormap = colors

    if sxy is not None or sz is not None:
        warnings.warn("The 'sxy' and 'sz' parameters are deprecated. Use 'pixel_sizes' instead.", DeprecationWarning, stacklevel=2)
        if pixel_sizes is None:
            _sxy = sxy if sxy is not None else 1.0
            _sz = sz if sz is not None else 1.0
            pixel_sizes = (_sz, _sxy, _sxy)

    # The widget parses pixel_sizes again and warns about missing axes once
    pz, py, px = _parse_zyx_tuple_or_dict(pixel_sizes, default_val=1.0, warn=False)

    if any(x is not None for x in [x_s, y_s, z_s]):
        warnings.warn("The 'x_s', 'y_s', 'z_s' parameters are deprecated. Use 'slabs_position' instead.", DeprecationWarning, stacklevel=2)
        if slabs_position is None:
            slabs_position = (z_s, y_s, x_s)

    if any(x is not None for x in [x_t, y_t, z_t]):
        warnings.warn("The 'x_t', 'y_t', 'z_t' parameters are deprecated. Use 'slabs_thickness' instead.", DeprecationWarning, stacklevel=2)
        if slabs_thickness is None:
            slabs_thickness = (z_t, y_t, x_t)

    z_t, y_t, x_t = _parse_zyx_tuple_or_dict(slabs_thickness, default_val=None)
    z_s, y_s, x_s = _parse_zyx_tuple_or_dict(slabs_position, default_val=None)

    if isinstance(points, (tuple, list)) and len(points) == 3:
        # points is a tuple or list of 3 arrays: (Z, Y, X)
        Z, Y, X = points[0], points[1], points[2]
        X = np.asarray(X)
        Y = np.asarray(Y)
        Z = np.asarray(Z)
    else:
        points = np.asarray(points)
        if points.ndim == 2 and points.shape[1] == 3:
            # points shape is (N, 3), assume Z, Y, X
            Z, Y, X = points[:, 0], points[:, 1], points[:, 2]
        elif points.ndim == 2 and points.shape[0] == 3:
            # points shape is (3, N), assume Z, Y, X
            Z, Y, X = points[0], points[1], points[2]
        elif points.ndim == 1 and len(points) == 3:
            # array of 3 list-like objects
            Z, Y, X = points[0], points[1], points[2]
            X = np.asarray(X)
            Y = np.asarray(Y)
            Z = np.asarray(Z)
        else:
            raise ValueError("points must be an array of shape (N, 3) representing (Z, Y, X) or a tuple/list of 3 arrays (Z, Y, X).")

    X, Y, Z, channels = _finite_points(X, Y, Z, channels)

    if render is None:
        if len(X) < 10000:
            render = 'points'
        else:
            render = 'density'


    (xmin, xmax), (ymin, ymax), (zmin, zmax) = (_int_bounds(a) for a in (X, Y, Z))

    XN = xmax - xmin + 1
    YN = ymax - ymin + 1
    ZN = zmax - zmin + 1
    z_xy_ratio = (pz / px) if px != pz else 1

    if figsize is None:
        width_px  = XN + ZN * z_xy_ratio
        height_px = YN + ZN * z_xy_ratio
        divisor = max(width_px / 8, height_px / 8)
        w, h = float(width_px / divisor), float(height_px / divisor)
        figsize = (w * figsize_scale, h * figsize_scale)
    elif figsize_scale != 1.0:
        figsize = (figsize[0] * figsize_scale, figsize[1] * figsize_scale)

    def _default_t(n): return max(1, int(n // 64))
    Xdim = int(np.ceil(XN)); Ydim = int(np.ceil(YN)); Zdim = int(np.ceil(ZN))

    if x_t is None: x_t = _default_t(Xdim)
    if y_t is None: y_t = _default_t(Ydim)
    if z_t is None: z_t = _default_t(Zdim)

    # Note: s inputs to scatter are in data coords (min-max range)
    # The Widget expects 0-Dim range?
    # Wait, my logic in TNIAScatterWidget._render adds xmin to x_s.
    # So x_s inside the widget is 0-based offset.
    # But x_s PASSED here is likely data coord?
    # Original code:
    # x_center_default = int(np.round((xmin + xmax) * 0.5))
    # x_s0 = _clip(int(x_s if x_s is not None else x_center_default), x_lo0, x_hi0)
    # So original input x_s is data coordinate.

    # Merge individual args and tuple arg before offsetting
    z_s_in, y_s_in, x_s_in = _parse_zyx_tuple_or_dict(slabs_position, default_val=None)
    x_s = x_s_in if x_s is None else x_s
    y_s = y_s_in if y_s is None else y_s
    z_s = z_s_in if z_s is None else z_s

    # So if x_s is provided, I need to subtract xmin to get 0-based offset for the widget init.
    if x_s is not None: x_s = int(x_s - xmin)
    if y_s is not None: y_s = int(y_s - ymin)
    if z_s is not None: z_s = int(z_s - zmin)
    z_t_in, y_t_in, x_t_in = _parse_zyx_tuple_or_dict(slabs_thickness, default_val=None)
    x_t = x_t_in if x_t is None else x_t
    y_t = y_t_in if y_t is None else y_t
    z_t = z_t_in if z_t is None else z_t

    w = TNIAScatterWidget(
        X, Y, Z,
        channels=channels, pixel_sizes=pixel_sizes, render=render, bins=bins,
        point_size=point_size, alpha=alpha, colormap=colormap if colormap is not None else colors, opacity=opacity,
        gamma=gamma, vmin=vmin, vmax=vmax, figsize=figsize, show_crosshair=show_crosshair, sync_on_hover=sync_on_hover,
        subplot_bg=subplot_bg,
        slabs_position=(z_s, y_s, x_s), slabs_thickness=(z_t, y_t, x_t),
        rotate_view=rotate_view, channel_labels=channel_labels, channel_label_fontsize_pt=channel_label_fontsize_pt,
        blending=blending,
    )
    w.X_arr_phys = w.X_arr * px
    w.Y_arr_phys = w.Y_arr * py
    w.Z_arr_phys = w.Z_arr * pz
    w.x_min_phys = xmin * px
    w.x_max_phys = xmax * px
    w.y_min_phys = ymin * py
    w.y_max_phys = ymax * py
    w.z_min_phys = zmin * pz
    w.z_max_phys = zmax * pz
    return w

class IsoScatterWidget(anywidget.AnyWidget):
    _esm = _ASSET_DIR.joinpath("iso_scatter.js").read_text()

    image_data = traitlets.Unicode().tag(sync=True)
    elev = traitlets.Float(30).tag(sync=True)
    azim = traitlets.Float(-60).tag(sync=True)
    save_filename = traitlets.Unicode("iso_scatter.svg").tag(sync=True)
    save_trigger = traitlets.Int(0).tag(sync=True)

    def __init__(self, X, Y, Z, color=None, sxy=1, sz=1, figsize=(12, 10),
                 point_size=5, alpha=0.6, cmap='viridis', max_points=10000,
                 title=None, pixel_sizes=None, channel_labels=None, seed=0):
        super().__init__()

        # Store ORIGINAL Data
        self.X_orig = np.asarray(X)
        self.Y_orig = np.asarray(Y)
        self.Z_orig = np.asarray(Z)

        # Determine color mode and convert to numpy array immediately
        self.is_continuous = False
        self.is_categorical = False

        # Ensure color is numpy array
        if color is not None:
             self.color = np.asarray(color)
        else:
             self.color = None

        # Handle empty data
        if len(self.X_orig) == 0:
             self.cx, self.cy, self.cz = 0, 0, 0
             self.max_radius = 1.0
             pz, py, px = _parse_zyx_tuple_or_dict(pixel_sizes, default_val=1.0)
             self.sx = px
             self.sy = py
             self.sz = pz
             self.figsize = figsize
             self.point_size = point_size
             self.alpha = alpha
             self.cmap = cmap
             self.title = title
             # Initialize rendering observers even if empty
             self.observe(self._render_wrapper, names=['elev', 'azim'])
             self.observe(self._save_svg, names='save_trigger')
             self._render_wrapper(None)
             return

        # Subsample if needed
        if len(self.X_orig) > max_points:
            # Local generator: reproducible, and the caller's global stream is untouched
            idx = np.random.default_rng(seed).choice(len(self.X_orig), max_points, replace=False)
            self.X_orig = self.X_orig[idx]
            self.Y_orig = self.Y_orig[idx]
            self.Z_orig = self.Z_orig[idx]
            if self.color is not None:
                 self.color = self.color[idx]

        if pixel_sizes is None:
            pixel_sizes = (sz, sxy, sxy)
        pz, py, px = _parse_zyx_tuple_or_dict(pixel_sizes, default_val=1.0)
        self.sx = px
        self.sy = py
        self.sz = pz
        self.channel_labels_input = channel_labels
        self.figsize = figsize
        self.point_size = point_size
        self.alpha = alpha
        self.cmap = cmap
        self.title = title

        # Calculate Centroid and Fixed Bounds for Rotation
        self.cx = (self.X_orig.min() + self.X_orig.max()) / 2
        self.cy = (self.Y_orig.min() + self.Y_orig.max()) / 2
        self.cz = (self.Z_orig.min() + self.Z_orig.max()) / 2

        # Calculate max radius from centroid (in the same physical units as _render)
        dx = (self.X_orig - self.cx) * self.sx
        dy = (self.Y_orig - self.cy) * self.sy
        dz = (self.Z_orig - self.cz) * self.sz
        dists = np.sqrt(dx**2 + dy**2 + dz**2)
        self.max_radius = dists.max() * 1.05 # 5% buffer

        # Analyze color types (after subsampling)
        if self.color is not None:
            if np.issubdtype(self.color.dtype, np.number):
                 self.is_continuous = True
            else:
                 self.is_categorical = True
                 # Map categories to colors
                 self.unique_cats = np.unique(self.color)
                 n_cats = len(self.unique_cats)

                 # Use a distinct colormap for categorical
                 # We'll generate a color mapping dictionary
                 # Use matplotlib 'tab10' or 'tab20' or 'viridis' if too many
                 base_cmap = matplotlib.colormaps['tab20' if n_cats > 10 else 'tab10']
                 self.cat_color_map = {cat: base_cmap(i % base_cmap.N) for i, cat in enumerate(self.unique_cats)}
                 self.c_mapped = [self.cat_color_map[c] for c in self.color]

        self.observe(self._render_wrapper, names=['elev', 'azim'])
        self.observe(self._save_svg, names='save_trigger')

        # Initial render
        self._render_wrapper(None)

    def _render_wrapper(self, change):
        fig = self._render()
        if fig:
            buf = io.BytesIO()
            fig.savefig(buf, format='png', bbox_inches='tight', dpi=100)
            self.image_data = base64.b64encode(buf.getvalue()).decode('utf-8')
            plt.close(fig)

    def _save_svg(self, change):
        fig = self._render()
        if fig:
            try:
                fig.savefig(self.save_filename, format='svg', dpi=300, bbox_inches='tight')
                print(f"Saved to {self.save_filename}")
            except Exception as e:
                print(f"Error saving file: {e}")
            finally:
                plt.close(fig)

    def _get_rotation_matrix(self, elev_deg, azim_deg):
        # Convert to radians
        elev = np.radians(elev_deg)
        azim = np.radians(azim_deg)

        # Rotation around Z (Azimuth)
        Rz = np.array([
            [np.cos(azim), -np.sin(azim), 0],
            [np.sin(azim),  np.cos(azim), 0],
            [0,             0,            1]
        ])

        # Rotation around X (Elevation) - or Y?
        # Usually Elevation is tilting up/down.
        # If Z is up, X is right, Y is forward (or similar).
        # Rotation around X tilts Y and Z.
        Rx = np.array([
            [1, 0,             0],
            [0, np.cos(elev), -np.sin(elev)],
            [0, np.sin(elev),  np.cos(elev)]
        ])

        # Combined Rotation
        return Rx @ Rz

    def _render(self):
        fig = plt.figure(figsize=self.figsize, facecolor='white')

        # Layout: 3 Rows, 2 Columns
        # Row 0 (Span 2): 3D Scatter
        # Row 1 (0): Side View (Y-Z)
        # Row 1 (1): Front View (X-Z)
        # Row 2 (0): Top View (X-Y)
        # Row 2 (1): Legend
        gs = gridspec.GridSpec(3, 2, width_ratios=[1, 1], height_ratios=[1.5, 1, 1], figure=fig)

        # Handle Empty Data
        if self.X_orig.size == 0:
            fig.text(0.5, 0.5, "No Data", ha='center', va='center')
            return fig

        # 1. Apply Rotation to Data
        # We need to center the data first to rotate around centroid
        X_c = (self.X_orig - self.cx) * self.sx
        Y_c = (self.Y_orig - self.cy) * self.sy
        Z_c = (self.Z_orig - self.cz) * self.sz

        # Stack
        points = np.stack([X_c, Y_c, Z_c], axis=1) # N x 3

        # Get Rotation Matrix
        R = self._get_rotation_matrix(self.elev, self.azim)

        points_rot = points @ R.T # (3x3 @ 3xN).T -> N x 3

        Xs, Ys, Zs = points_rot[:, 0], points_rot[:, 1], points_rot[:, 2]

        # Common scatter args
        scatter_kwargs = {
            's': self.point_size,
            'alpha': self.alpha,
        }

        if self.is_continuous:
            scatter_kwargs['c'] = self.color
            scatter_kwargs['cmap'] = self.cmap
        elif self.is_categorical:
            scatter_kwargs['c'] = self.c_mapped
        else:
            scatter_kwargs['c'] = 'gray'

        # Global Limits
        lim = self.max_radius
        # Limits: [-lim, lim]

        # --- 3D Plot (Row 0, Span 2) ---
        ax3d = fig.add_subplot(gs[0, :], projection='3d')
        p3d = ax3d.scatter(Xs, Ys, Zs, **scatter_kwargs)

        # Fix Camera
        ax3d.view_init(elev=20, azim=-45)

        ax3d.set_xlim([-lim, lim])
        ax3d.set_ylim([-lim, lim])
        ax3d.set_zlim([-lim, lim])
        ax3d.set_box_aspect((1, 1, 1))
        ax3d.set_xlabel('X')
        ax3d.set_ylabel('Y')
        ax3d.set_zlabel('Z')

        # --- Side Projection (Row 1, Left) ---
        # Z vs Y (Y on horizontal, Z on vertical)
        ax_yz = fig.add_subplot(gs[1, 0])
        ax_yz.scatter(Ys, Zs, **scatter_kwargs)
        ax_yz.set_aspect('equal')
        ax_yz.set_xlim([-lim, lim])
        ax_yz.set_ylim([-lim, lim])
        ax_yz.set_xlabel('Y')
        ax_yz.set_ylabel('Z')
        ax_yz.set_title("Side View (Y-Z)")
        ax_yz.grid(True, linestyle=':', alpha=0.6)

        # --- Front Projection (Row 1, Right) ---
        # Z vs X (X on horizontal, Z on vertical)
        ax_xz = fig.add_subplot(gs[1, 1])
        ax_xz.scatter(Xs, Zs, **scatter_kwargs)
        ax_xz.set_aspect('equal')
        ax_xz.set_xlim([-lim, lim])
        ax_xz.set_ylim([-lim, lim])
        ax_xz.set_xlabel('X')
        ax_xz.set_ylabel('Z')
        ax_xz.set_title("Front View (X-Z)")
        ax_xz.grid(True, linestyle=':', alpha=0.6)

        # --- Top Projection (Row 2, Left) ---
        # Y vs X (X horizontal, Y vertical)
        ax_yx = fig.add_subplot(gs[2, 0])
        ax_yx.scatter(Xs, Ys, **scatter_kwargs)
        ax_yx.set_aspect('equal')
        ax_yx.set_xlim([-lim, lim])
        ax_yx.set_ylim([-lim, lim])
        ax_yx.set_xlabel('X')
        ax_yx.set_ylabel('Y')
        ax_yx.set_title("Top View (X-Y)")
        ax_yx.grid(True, linestyle=':', alpha=0.6)

        # --- Legend (Row 2, Right) ---
        ax_leg = fig.add_subplot(gs[2, 1])
        ax_leg.axis('off')

        if self.is_continuous:
            # Safely add colorbar only if collection exists
            if hasattr(p3d, 'cmap'):
                 cbar = fig.colorbar(p3d, ax=ax_leg, fraction=0.8, pad=0.05, aspect=20)
                 cbar.set_label('Value')
        elif self.is_categorical:
            handles = [
                matplotlib.lines.Line2D([0], [0], marker='o', color='w',
                                        markerfacecolor=self.cat_color_map[cat],
                                        markersize=10, label=str(cat))
                for cat in self.unique_cats
            ]
            ax_leg.legend(handles=handles, loc='center', title="Categories", frameon=False)

        if self.title:
            fig.suptitle(self.title, fontsize=16)

        fig.tight_layout()
        return fig

def show_iso_scatter(
    X, Y, Z,
    color=None,
    sxy=1, sz=1,
    figsize=(10, 8),
    point_size=5,
    alpha=0.6,
    cmap='viridis',
    max_points=10000,
    title=None,
    pixel_sizes=None,
    seed=0,
):
    """
    Displays an interactive isometric scatter plot widget.

    Parameters
    ----------
    X, Y, Z : array-like
        Coordinates of points.
    color : array-like, optional
        Color values (continuous or categorical).
    sxy, sz : float
        Scaling factors for XY and Z dimensions (used when ``pixel_sizes`` is None).
    pixel_sizes : tuple or dict, optional
        (Z, Y, X) pixel sizes, or a dict with 'Z', 'Y', 'X' keys. Takes
        precedence over ``sxy``/``sz``.
    figsize : tuple
        Size of the rendered figure.
    point_size : int
        Size of scatter points.
    alpha : float
        Transparency of points.
    cmap : str
        Colormap for continuous data.
    max_points : int
        Maximum number of points to render (random subsampling applied if exceeded).
    title : str, optional
        Plot title.
    seed : int or None
        Seed of the subsampling (default 0, reproducible; None for a fresh draw).
    """
    return IsoScatterWidget(
        X, Y, Z,
        color=color,
        sxy=sxy,
        sz=sz,
        figsize=figsize,
        point_size=point_size,
        alpha=alpha,
        cmap=cmap,
        max_points=max_points,
        title=title,
        pixel_sizes=pixel_sizes,
        seed=seed,
    )
